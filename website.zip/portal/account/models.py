import os
import shutil
from typing import Iterable, Optional
from django.db import models
from django.dispatch import receiver
from django.db.models.signals import post_save, pre_delete, post_delete
from django.core.files.storage import default_storage
import secrets
import string
from django.utils.text import slugify
from adminpanal.models import Station


# Create your models here.
class UserType(models.Model):
    type = models.CharField(max_length=254)
    add_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.type


# Custom upload path function
def upload_user_image(instance, filename):
    # Generate a folder name using the station's name (slugified)
    user_slug = slugify(f"{instance.id}-{instance.email}")
    # Construct the upload path
    upload_path = os.path.join('files', 'Users', user_slug, filename)
    return upload_path


class UserAccount(models.Model):
    first_name = models.CharField(max_length=254)
    last_name = models.CharField(max_length=254)
    email = models.CharField(max_length=254)
    password = models.CharField(max_length=254)
    role = models.ForeignKey(UserType, on_delete=models.CASCADE, related_name='role')
    image = models.FileField(upload_to=upload_user_image, null=True, blank=True)
    add_date = models.DateTimeField(auto_now_add=True)
    first_login = models.BooleanField(default=True)
    is_locked = models.BooleanField(default=False)
    attempts = models.PositiveBigIntegerField(default=0)

    def __str__(self):
        return f"{self.first_name} {self.last_name}"


@receiver(pre_delete, sender=UserAccount)
def UserAccount_delete_profile_image(sender, instance, **kwargs):
    """
    Signal handler to delete all related FileHandler objects and their associated files.
    """
    if instance.image:
        # Get the path to the image file
        file_path = instance.image.path
        # Get the directory containing the image
        folder_path = os.path.dirname(file_path)
        # Check if the image file exists and delete it
        if default_storage.exists(file_path):
            default_storage.delete(file_path)
        # Check if the folder exists and delete it
        if os.path.exists(folder_path):
            try:
                shutil.rmtree(folder_path)  # Delete the folder and all its contents
                print("User folder deleted successfully.")
            except Exception as e:
                print(f"Error deleting user folder: {e}")


class Token(models.Model):
    user = models.ForeignKey(UserAccount, on_delete=models.CASCADE, related_name='userToken')
    token = models.CharField(max_length=254)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.user.first_name

@receiver(post_save, sender=UserAccount)
def TokenAndUsernameCreate(sender, instance, created, **kwargs):
    if created:
        Token.objects.create(
            user=instance,
            token=generate_user_token()
        )

def generate_user_token(length=16):
    """Generate a random user token of specified length."""
    characters = string.ascii_letters + string.digits
    token = ''.join(secrets.choice(characters) for _ in range(length))
    return token


class UserSession(models.Model):
    user = models.ForeignKey(UserAccount, on_delete=models.CASCADE, related_name='userSession')
    key = models.BooleanField() # 1 for login 0 for logout
    timestamp = models.DateTimeField(auto_now_add=True)
    
    
class UserOTP(models.Model):
    user = models.ForeignKey(UserAccount, on_delete=models.CASCADE, related_name='userOTP')
    key = models.CharField(max_length=50)
    timeout = models.DateTimeField()
    timestamp = models.DateTimeField(auto_now_add=True)


class UserGroup(models.Model):
    name = models.CharField(max_length=254)
    users = models.ManyToManyField(UserAccount)
    stations = models.ManyToManyField(Station)
    creator = models.ForeignKey(UserAccount, on_delete=models.CASCADE, related_name='groupcreator')
    timestamp = models.DateTimeField(auto_now_add=True)


user_permission = [
    ('a', 'Add'),
    ('c', 'Change'),
    ('d', 'Delete'),
    ('r', 'Read'),
]

class UserLog(models.Model):
    user = models.ForeignKey(UserAccount, on_delete=models.CASCADE, related_name='userlog')
    action = models.CharField(max_length=10, choices=user_permission)
    table = models.CharField(max_length=50)
    description = models.CharField(max_length=254)
    timestamp = models.DateTimeField(auto_now_add=True)
    
