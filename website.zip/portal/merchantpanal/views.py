from datetime import datetime, timedelta
import json
from django.http import HttpResponseRedirect, JsonResponse
from django.shortcuts import render

from adminpanal.models import *
from .decorators import is_merchant_login
from account.models import *
from .models import *
from django.core.paginator import Paginator
from django.db.models.functions import TruncDate, TruncMonth
from django.db.models import Count, Case, When, IntegerField, Sum, F
# Create your views here.


@is_merchant_login
def InitView(request):
    return HttpResponseRedirect('/merchantpanal/dashboard/')


@is_merchant_login
def DashboardView(request):
    merchant_obj = Token.objects.get(
        token=request.session.get('merchant_token')).user
    context = {
        'user': merchant_obj,
    }
    return render(request, 'merchantpanal/MerchantDashboard.html', context)


@is_merchant_login
def DashboardProductAllApi(request):
    merchant_obj = Token.objects.get(
        token=request.session.get('merchant_token')).user
    if request.method == "GET":
        stations = UserGroup.objects.get(users=merchant_obj).stations.all()
        # Fetch the products linked to the stations in the group
        products = Product.objects.filter(
            NozzleProduct__station__in=stations  # `nozzleproduct` is the related_name from Product to Nozzle
        ).distinct()
        product_list = [
            {
                "name": product.name,
                "price": product.price,
            }
            for product in products
        ]
        return JsonResponse(data=product_list, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)


@is_merchant_login
def DashboardTotalsApi(request):
    merchant_obj = Token.objects.get(
        token=request.session.get('merchant_token')).user
    if request.method == "GET":
        merchant_group = UserGroup.objects.get(users=merchant_obj)
        
        total_transactions = Transaction.objects.filter(
            station__in=merchant_group.stations.all()
        ).distinct().count()
        total_users = merchant_group.users.count()
        total_stations = merchant_group.stations.count()
        total_poses = Pos.objects.filter(
            station__in=merchant_group.stations.all()
        ).distinct().count()
        totals_list = {
            "total_transactions": total_transactions,
            "total_users": total_users,
            "total_stations": total_stations,
            "total_poses": total_poses,
        }
        return JsonResponse(data=totals_list, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)


@is_merchant_login
def DashboardStationsAllApi(request):
    merchant_obj = Token.objects.get(
        token=request.session.get('merchant_token')).user
    if request.method == "GET":
        stations = UserGroup.objects.get(users=merchant_obj).stations.select_related('fusion').all()
        stations_list = [
            {
                "name": station.fusion.station_name,
                "lat": station.lat,
                "lng": station.long,
            }
            for station in stations
        ]
        return JsonResponse(data=stations_list, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)


@is_merchant_login
def DashboardStationsStatusApi(request):
    merchant_obj = Token.objects.get(
        token=request.session.get('merchant_token')).user
    if request.method == "GET":
        stations = UserGroup.objects.get(users=merchant_obj).stations.select_related('fusion').all()
        
        offline_threshold = datetime.now() - timedelta(minutes=15)
        
        counts = stations.aggregate(
            online=Count(Case(
                When(last_connection__gte=offline_threshold, then=1),
                output_field=IntegerField(),
            )),
            offline=Count(Case(
                When(last_connection__lt=offline_threshold, then=1),
                output_field=IntegerField(),
            )),
        )

        online_stations_count = counts['online']
        offline_stations_count = counts['offline']

        print(f"Online stations: {online_stations_count}")
        print(f"Offline stations: {offline_stations_count}")
        
        data = {
            'series': [
                counts['online'],
                counts['offline'],
            ],
            'labels': [
                'online',
                'offline'
            ],
        }
        return JsonResponse(data=data, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)

@is_merchant_login
def DashboardPOSesStatusApi(request):
    merchant_obj = Token.objects.get(
        token=request.session.get('merchant_token')).user
    if request.method == "GET":
        stations = UserGroup.objects.get(users=merchant_obj).stations.all()
        poses = Pos.objects.select_related('station__fusion').filter(
            station__in=stations
        ).distinct()
        
        offline_threshold = datetime.now() - timedelta(minutes=15)
        
        counts = poses.aggregate(
            online=Count(Case(
                When(last_connection__gte=offline_threshold, then=1),
                output_field=IntegerField(),
            )),
            offline=Count(Case(
                When(last_connection__lt=offline_threshold, then=1),
                output_field=IntegerField(),
            )),
        )

        online_poses_count = counts['online']
        offline_poses_count = counts['offline']

        print(f"Online poses: {online_poses_count}")
        print(f"Offline poses: {offline_poses_count}")
        
        data = {
            'series': [
                counts['online'],
                counts['offline'],
            ],
            'labels': [
                'online',
                'offline'
            ],
        }
        return JsonResponse(data=data, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)



# def DashboardStationsTopThreeApi(request):
#     if request.method == "GET":
#         # Get today's and yesterday's date range
#         now = datetime.now()
#         start_of_today = datetime(now.year, now.month, now.day)
#         start_of_yesterday = start_of_today - timedelta(days=1)
#         end_of_yesterday = start_of_today - timedelta(seconds=1)

#         # Fetch sales data for today
#         today_sales = (
#             Transaction.objects.filter(date__gte=start_of_today)
#             .values('station__fusion__station_name')  # Group by station name
#             .annotate(total_sales_today=Sum('amount'))  # Sum sales for today
#         )

#         # Fetch sales data for yesterday
#         yesterday_sales = (
#             Transaction.objects.filter(date__range=(start_of_yesterday, end_of_yesterday))
#             .values('station__fusion__station_name')  # Group by station name
#             .annotate(total_sales_yesterday=Sum('amount'))  # Sum sales for yesterday
#         )

#         # Prepare a dictionary for quick lookup of yesterday's sales
#         yesterday_sales_dict = {
#             sale['station__fusion__station_name']: sale['total_sales_yesterday'] for sale in yesterday_sales
#         }

#         # Calculate the percentage change and prepare the result
#         results = []
#         for sale in today_sales:
#             station_name = sale['station__fusion__station_name']
#             sales_today = sale['total_sales_today']
#             sales_yesterday = yesterday_sales_dict.get(station_name, 0)
            
#             # Calculate percentage change and cap it at 100%
#             if sales_yesterday > 0:
#                 percent_change = ((sales_today - sales_yesterday) / sales_yesterday) * 100
#                 percent_change = min(percent_change, 100)  # Cap percentage at 100%
#             else:
#                 percent_change = 0.0  # If no sales yesterday, set to 0%

#             results.append({
#                 'station_name': station_name,
#                 'sales': sales_today,
#                 'percent': round(percent_change, 2),  # Round to 2 decimal places
#             })

#         # Sort by sales descending and get the top 3
#         top_three_stations = sorted(results, key=lambda x: x['sales'], reverse=True)[:3]
#         print(top_three_stations)
#         return JsonResponse(data=top_three_stations, safe=False)
#     return JsonResponse(data={'status': 'No Get'}, safe=False)
@is_merchant_login
def DashboardStationsTopThreeApi(request):
    merchant_obj = Token.objects.get(
        token=request.session.get('merchant_token')).user
    if request.method == "GET":
        stations = UserGroup.objects.get(users=merchant_obj).stations.all()
        # Get today's and yesterday's date range
        now = datetime.now()
        start_of_today = datetime(now.year, now.month, now.day)
        start_of_yesterday = start_of_today - timedelta(days=1)
        end_of_yesterday = start_of_today - timedelta(seconds=1)

        # Fetch sales data for today
        today_sales = (
            Transaction.objects
            .filter(station__in=stations)
            .filter(date__gte=start_of_today)
            .values('station__fusion__station_name')  # Group by station name
            .annotate(total_sales_today=Sum('amount'))  # Sum sales for today
        )

        # Fetch sales data for yesterday
        yesterday_sales = (
            Transaction.objects
            .filter(station__in=stations)
            .filter(date__range=(start_of_yesterday, end_of_yesterday))
            .values('station__fusion__station_name')  # Group by station name
            .annotate(total_sales_yesterday=Sum('amount'))  # Sum sales for yesterday
        )

        # Prepare a dictionary for quick lookup of yesterday's sales
        yesterday_sales_dict = {
            sale['station__fusion__station_name']: sale['total_sales_yesterday'] for sale in yesterday_sales
        }

        # Calculate the percentage change and prepare the result
        results = []
        for sale in today_sales:
            station_name = sale['station__fusion__station_name']
            sales_today = sale['total_sales_today']
            sales_yesterday = yesterday_sales_dict.get(station_name, 0)

            # Calculate percentage change
            if sales_yesterday > 0:
                percent_change = ((sales_today - sales_yesterday) / sales_yesterday) * 100
            else:
                percent_change = 100.0  # If no sales yesterday, assume 100% growth

            # Only include stations with non-negative percentage change
            if percent_change >= 0:
                results.append({
                    'station_name': station_name,
                    'sales': sales_today,
                    'percentage': round(percent_change, 2),  # Round to 2 decimal places
                })

        # Sort by sales descending and get the top 3
        top_three_stations = sorted(results, key=lambda x: x['sales'], reverse=True)[:3]

        return JsonResponse(data=top_three_stations, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)






def POSTransactionsApi(request):
    if request.method == "POST":
        data = json.loads(request.body)
        # print(data)
        try:
            # print('seq_no = ', data.get('seq_no'))
            # print('fusion_sale = ', data.get('fusion_sale'))
            # print('volume = ', data.get('volume'))
            # print('unit_price = ', data.get('unit_price'))
            # print('amount = ', data.get('amount'))
            # print('unit_measure = ', data.get('unit_measure'))
            # print('tips = ', data.get('tips'))
            # print('date = ', data.get('date'))
            # print('payment_type = ', data.get('payment_type'))
            # print('is_taxed = ', data.get('is_taxed'))
            # print('pos = ', data.get('pos'))
            # print('product = ', data.get('product'))
            # print('nozzle = ', data.get('nozzle'))
            # print('pump = ', data.get('pump'))
            # print('station = ', data.get('station'))
            station_obj = Station.objects.select_related(
                'fusion').get(fusion__station_code=data.get('station'))
            pump_obj = Pump.objects.get(
                number=data.get('pump'), station=station_obj)
            nozzle_obj = Nozzle.objects.select_related('product').get(
                number=data.get('nozzle'), pump=pump_obj, station=station_obj)
            product_obj = nozzle_obj.product.name
            pos_obj = Pos.objects.get(android_id=data.get(
                'pos'), pumps=pump_obj, station=station_obj)

            Transaction.objects.create(
                seq_no=data.get('seq_no'),
                fusion_sale=data.get('fusion_sale'),
                volume=data.get('volume'),
                unit_price=data.get('unit_price'),
                amount=data.get('amount'),
                unit_measure=data.get('unit_measure'),
                tips=data.get('tips'),
                date=data.get('date'),
                payment_type=data.get('payment_type'),
                is_taxed=data.get('is_taxed'),
                pos=pos_obj,
                product=nozzle_obj.product,
                nozzle=nozzle_obj,
                pump=pump_obj,
                station=station_obj,
            )

            print('station_obj = ', station_obj)
            print('pump_obj = ', pump_obj)
            print('nozzle_obj = ', nozzle_obj)
            print('product_obj = ', product_obj)
            print('pos_obj = ', pos_obj)
            return JsonResponse(data={'status': 'added successfully'}, safe=False)
        except Exception as ex:
            print('exception', ex)
            return JsonResponse(data={'status': 'error', 'message': ex}, safe=False)
    return JsonResponse(data={'status': 'No Post request'}, safe=False)


@is_merchant_login
def SalesAllView(request):
    merchant_obj = Token.objects.get(
        token=request.session.get('merchant_token')).user
    # products = Product.objects.all()
    context = {
        'user': merchant_obj,
        # 'products': products,
    }
    return render(request, 'merchantpanal/MerchantSalesAll.html', context)

@is_merchant_login
def SalesAllViewApi(request):
    merchant_obj = Token.objects.get(
        token=request.session.get('merchant_token')).user
    if request.method == "GET":
        page = int(request.GET.get('page', 1))  # Default to page 1
        size = int(request.GET.get('size', 10))  # Default to 10 items per page
        stations_ids = UserGroup.objects.filter(users=merchant_obj).values_list('stations', flat=True)
        transactions = Transaction.objects.select_related(
            'station', 'pump', 'nozzle', 'product').filter(station_id__in=stations_ids)
        paginator = Paginator(transactions, size)
        current_page = paginator.page(
            page) if paginator.num_pages >= page else paginator.page(1)

        data = [
            {
                'id': trx.id,
                'seq_no': trx.seq_no,
                'fusion_sale': trx.fusion_sale,
                'volume': trx.volume,
                'unit_price': trx.unit_price,
                'amount': trx.amount,
                'unit_measure': trx.unit_measure,
                'tips': trx.tips,
                'date': trx.date.strftime("%Y-%m-%d %H:%M:%S"),
                'payment_type': trx.payment_type,
                'is_taxed': trx.is_taxed,
                'pos': trx.pos.android_id,
                'product': trx.product.name,
                'nozzle': f'Nozzle {trx.nozzle.number}',
                'pump': f'Pump {trx.pump.number}',
                'station': f'{trx.station.fusion.station_code}-{trx.station.fusion.station_name}',
                'timestamp': trx.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
            }
            for trx in current_page.object_list
        ]

        return JsonResponse({
            'data': data,
            'last_page': paginator.num_pages
        }, safe=False)
    return JsonResponse({'status': 'No Get'}, safe=False)


@is_merchant_login
def SalesDailyView(request):
    merchant_obj = Token.objects.get(
        token=request.session.get('merchant_token')).user
    context = {
        'user': merchant_obj,
    }
    return render(request, 'merchantpanal/MerchantSalesDaily.html', context)

@is_merchant_login
def SalesDailyViewApi(request):
    merchant_obj = Token.objects.get(
        token=request.session.get('merchant_token')).user
    if request.method == "GET":
        page = int(request.GET.get('page', 1))  # Default to page 1
        size = int(request.GET.get('size', 10))  # Default to 10 items per page
        stations_ids = UserGroup.objects.filter(users=merchant_obj).values_list('stations', flat=True)
        transactions_summary = (
            Transaction.objects
            .filter(station_id__in=stations_ids)
            # Truncate datetime to date
            .annotate(transaction_date=TruncDate('date'))
            # Group by truncated date and product
            .values('transaction_date', 'product__name', 'product__price', 'station__fusion__station_code')
            .annotate(
                transaction_count=Count('id'),  # Count transactions
                total_volume=Sum('volume'),  # Sum of volume
                total_amount=Sum('amount'),  # Sum of amount
                total_tips=Sum('tips')  # Sum of amount
            )
            # Order by date and product
            .order_by('transaction_date', 'product__name')
        )
        
        paginator = Paginator(transactions_summary, size)
        current_page = paginator.page(
            page) if paginator.num_pages >= page else paginator.page(1)

        data = [
            {
                'station': summary['station__fusion__station_code'],
                'date': summary['transaction_date'].strftime("%Y-%m-%d"),
                'product': summary['product__name'],
                'price': summary['product__price'],
                'transactions': summary['transaction_count'],
                'volume': summary['total_volume'],
                'money': summary['total_amount'],
                'tips': summary['total_tips'],
            }
            for summary in current_page.object_list
        ]

        return JsonResponse({
            'data': data,
            'last_page': paginator.num_pages
        }, safe=False)
    return JsonResponse({'status': 'No Get'}, safe=False)


@is_merchant_login
def SalesMonthlyView(request):
    merchant_obj = Token.objects.get(
        token=request.session.get('merchant_token')).user
    # products = Product.objects.all()
    context = {
        'user': merchant_obj,
        # 'products': products,
    }
    return render(request, 'merchantpanal/MerchantSalesMonthly.html', context)

@is_merchant_login
def SalesMonthlyViewApi(request):
    merchant_obj = Token.objects.get(
        token=request.session.get('merchant_token')).user
    if request.method == "GET":
        page = int(request.GET.get('page', 1))  # Default to page 1
        size = int(request.GET.get('size', 10))  # Default to 10 items per page
        stations_ids = UserGroup.objects.filter(users=merchant_obj).values_list('stations', flat=True)
        transactions_summary = (
            Transaction.objects
            .filter(station_id__in=stations_ids)
            # Truncate datetime to date
            .annotate(transaction_date=TruncMonth('date'))
            # Group by truncated date and product
            .values('transaction_date', 'product__name', 'product__price', 'station__fusion__station_code')
            .annotate(
                transaction_count=Count('id'),  # Count transactions
                total_volume=Sum('volume'),  # Sum of volume
                total_amount=Sum('amount'),  # Sum of amount
                total_tips=Sum('tips')  # Sum of amount
            )
            # Order by date and product
            .order_by('transaction_date', 'product__name')
        )
        
        paginator = Paginator(transactions_summary, size)
        current_page = paginator.page(
            page) if paginator.num_pages >= page else paginator.page(1)

        data = [
            {
                'station': summary['station__fusion__station_code'],
                'date': summary['transaction_date'].strftime("%Y-%m"),
                'product': summary['product__name'],
                'price': summary['product__price'],
                'transactions': summary['transaction_count'],
                'volume': summary['total_volume'],
                'money': summary['total_amount'],
                'tips': summary['total_tips'],
            }
            for summary in current_page.object_list
        ]

        return JsonResponse({
            'data': data,
            'last_page': paginator.num_pages
        }, safe=False)
    return JsonResponse({'status': 'No Get'}, safe=False)
