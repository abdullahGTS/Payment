from django.db import models
from adminpanal.models import *
# Create your models here.


class Transaction(models.Model):
    seq_no = models.PositiveBigIntegerField()
    fusion_sale = models.PositiveBigIntegerField()
    volume = models.FloatField()
    unit_price = models.FloatField()
    amount = models.FloatField()
    unit_measure = models.CharField(max_length=50)
    tips = models.FloatField()
    date = models.DateTimeField()
    payment_type = models.CharField(max_length=254)
    is_taxed = models.BooleanField(default=False)
    pos = models.ForeignKey(Pos, on_delete=models.CASCADE, related_name='TransactionPos')
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='TransactionProduct')
    nozzle = models.ForeignKey(Nozzle, on_delete=models.CASCADE, related_name='TransactionNozzle')
    pump = models.ForeignKey(Pump, on_delete=models.CASCADE, related_name='TransactionPump')
    station = models.ForeignKey(Station, on_delete=models.CASCADE, related_name='TransactionStation')
    timestamp = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f'Transaction {self.seq_no}'
    