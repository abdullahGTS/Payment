from django.urls import path
from .views import *

urlpatterns = [
    path('', InitView, name='InitView'),
    path('dashboard/', DashboardView, name='DashboardView'),
    path('dashboard/product/all/api/', DashboardProductAllApi, name='DashboardProductAllApi'),
    path('dashboard/totals/api/', DashboardTotalsApi, name='DashboardTotalsApi'),
    path('dashboard/stations/all/api/', DashboardStationsAllApi, name='DashboardStationsAllApi'),
    path('dashboard/stations/status/api/', DashboardStationsStatusApi, name='DashboardStationsStatusApi'),
    path('dashboard/poses/status/api/', DashboardPOSesStatusApi, name='DashboardPOSesStatusApi'),
    path('dashboard/stations/top/three/api/', DashboardStationsTopThreeApi, name='DashboardStationsTopThreeApi'),
    
    path('pos/transactions/api/', POSTransactionsApi, name='POSTransactionsApi'),
    
    path('sales/all/', SalesAllView, name='SalesAllView'),
    path('sales/all/view/api/', SalesAllViewApi, name='SalesAllViewApi'),
    
    path('sales/daily/', SalesDailyView, name='SalesDailyView'),
    path('sales/daily/view/api/', SalesDailyViewApi, name='SalesDailyViewApi'),
    
    path('sales/monthly/', SalesMonthlyView, name='SalesMonthlyView'),
    path('sales/monthly/view/api/', SalesMonthlyViewApi, name='SalesMonthlyViewApi'),
]