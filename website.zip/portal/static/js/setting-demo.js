// "use strict";

// // Setting Color

// $(window).resize(function () {
//     $(window).width();
// });

// getCheckmark();

// $(".changeBodyBackgroundFullColor").on("click", function () {
//     if ($(this).attr("data-color") == "default") {
//         $("body").removeAttr("data-background-full");
//     } else {
//         $("body").attr("data-background-full", $(this).attr("data-color"));
//     }

//     $(this).parent().find(".changeBodyBackgroundFullColor").removeClass("selected");
//     $(this).addClass("selected");
//     layoutsColors();
//     getCheckmark();
// });

// $(".changeLogoHeaderColor").on("click", function () {
//     if ($(this).attr("data-color") == "default") {
//         $(".logo-header").removeAttr("data-background-color");
//     } else {
//         $(".logo-header").attr("data-background-color", $(this).attr("data-color"));
//     }

//     $(this).parent().find(".changeLogoHeaderColor").removeClass("selected");
//     $(this).addClass("selected");
//     customCheckColor();
//     layoutsColors();
//     getCheckmark();
// });

// $(".changeTopBarColor").on("click", function () {
//     if ($(this).attr("data-color") == "default") {
//         $(".main-header .navbar-header").removeAttr("data-background-color");
//     } else {
//         $(".main-header .navbar-header").attr("data-background-color", $(this).attr("data-color"));
//     }

//     $(this).parent().find(".changeTopBarColor").removeClass("selected");
//     $(this).addClass("selected");
//     layoutsColors();
//     getCheckmark();
// });

// $(".changeSideBarColor").on("click", function () {
//     if ($(this).attr("data-color") == "default") {
//         $(".sidebar").removeAttr("data-background-color");
//     } else {
//         $(".sidebar").attr("data-background-color", $(this).attr("data-color"));
//     }

//     $(this).parent().find(".changeSideBarColor").removeClass("selected");
//     $(this).addClass("selected");
//     layoutsColors();
//     getCheckmark();
// });

// $(".changeBackgroundColor").on("click", function () {
//     $("body").removeAttr("data-background-color");
//     $("body").attr("data-background-color", $(this).attr("data-color"));
//     $(this).parent().find(".changeBackgroundColor").removeClass("selected");
//     $(this).addClass("selected");
//     getCheckmark();
// });

// function customCheckColor() {
//     var logoHeader = $(".logo-header").attr("data-background-color");
//     if (logoHeader !== "white") {
//         $(".logo-header .navbar-brand").attr("src", "/static/img/gts-logo.png");
//     } else {
//         $(".logo-header .navbar-brand").attr("src", "/static/img/gts-logo-dark.png");
//     }
// }

// var toggle_customSidebar = false,
//     custom_open = 0;

// if (!toggle_customSidebar) {
//     var toggle = $(".custom-template .custom-toggle");

//     toggle.on("click", function () {
//         if (custom_open == 1) {
//             $(".custom-template").removeClass("open");
//             toggle.removeClass("toggled");
//             custom_open = 0;
//         } else {
//             $(".custom-template").addClass("open");
//             toggle.addClass("toggled");
//             custom_open = 1;
//         }
//     });
//     toggle_customSidebar = true;
// }

// function getCheckmark() {
//     var checkmark = `<i class="gg-check"></i>`;
//     $(".btnSwitch").find("button").empty();
//     $(".btnSwitch").find("button.selected").append(checkmark);
// }


// "use strict";

// // Function to save theme settings in local storage
// function saveThemePreference(key, value) {
//     localStorage.setItem(key, value);
// }

// // Function to load theme settings from local storage
// function loadThemePreference() {
//     const bodyBackgroundFull = localStorage.getItem("bodyBackgroundFull");
//     const logoHeaderColor = localStorage.getItem("logoHeaderColor");
//     const topBarColor = localStorage.getItem("topBarColor");
//     const sideBarColor = localStorage.getItem("sideBarColor");
//     const backgroundColor = localStorage.getItem("backgroundColor");

//     if (bodyBackgroundFull) $("body").attr("data-background-full", bodyBackgroundFull);
//     if (logoHeaderColor) $(".logo-header").attr("data-background-color", logoHeaderColor);
//     if (topBarColor) $(".main-header .navbar-header").attr("data-background-color", topBarColor);
//     if (sideBarColor) $(".sidebar").attr("data-background-color", sideBarColor);
//     if (backgroundColor) $("body").attr("data-background-color", backgroundColor);
// }

// // Initialize theme on page load
// $(document).ready(function () {
//     loadThemePreference();
//     getCheckmark(); // Update the checkmark UI
//     customCheckColor(); // Adjust logo if necessary
// });

// // Setting Color
// $(window).resize(function () {
//     $(window).width();
// });

// $(".changeBodyBackgroundFullColor").on("click", function () {
//     const color = $(this).attr("data-color");
//     if (color === "default") {
//         $("body").removeAttr("data-background-full");
//         localStorage.removeItem("bodyBackgroundFull");
//     } else {
//         $("body").attr("data-background-full", color);
//         saveThemePreference("bodyBackgroundFull", color);
//     }

//     $(this).parent().find(".changeBodyBackgroundFullColor").removeClass("selected");
//     $(this).addClass("selected");
//     layoutsColors();
//     getCheckmark();
// });

// // Similar functions for other elements
// $(".changeLogoHeaderColor").on("click", function () {
//     const color = $(this).attr("data-color");
//     if (color === "default") {
//         $(".logo-header").removeAttr("data-background-color");
//         localStorage.removeItem("logoHeaderColor");
//     } else {
//         $(".logo-header").attr("data-background-color", color);
//         saveThemePreference("logoHeaderColor", color);
//     }

//     $(this).parent().find(".changeLogoHeaderColor").removeClass("selected");
//     $(this).addClass("selected");
//     customCheckColor();
//     layoutsColors();
//     getCheckmark();
// });

// $(".changeTopBarColor").on("click", function () {
//     const color = $(this).attr("data-color");
//     if (color === "default") {
//         $(".main-header .navbar-header").removeAttr("data-background-color");
//         localStorage.removeItem("topBarColor");
//     } else {
//         $(".main-header .navbar-header").attr("data-background-color", color);
//         saveThemePreference("topBarColor", color);
//     }

//     $(this).parent().find(".changeTopBarColor").removeClass("selected");
//     $(this).addClass("selected");
//     layoutsColors();
//     getCheckmark();
// });

// $(".changeSideBarColor").on("click", function () {
//     const color = $(this).attr("data-color");
//     if (color === "default") {
//         $(".sidebar").removeAttr("data-background-color");
//         localStorage.removeItem("sideBarColor");
//     } else {
//         $(".sidebar").attr("data-background-color", color);
//         saveThemePreference("sideBarColor", color);
//     }

//     $(this).parent().find(".changeSideBarColor").removeClass("selected");
//     $(this).addClass("selected");
//     layoutsColors();
//     getCheckmark();
// });

// $(".changeBackgroundColor").on("click", function () {
//     const color = $(this).attr("data-color");
//     $("body").attr("data-background-color", color);
//     saveThemePreference("backgroundColor", color);

//     $(this).parent().find(".changeBackgroundColor").removeClass("selected");
//     $(this).addClass("selected");
//     getCheckmark();
// });

// function customCheckColor() {
//     var logoHeader = $(".logo-header").attr("data-background-color");
//     if (logoHeader !== "white") {
//         $(".logo-header .navbar-brand").attr("src", "/static/img/gts-logo.png");
//     } else {
//         $(".logo-header .navbar-brand").attr("src", "/static/img/gts-logo-dark.png");
//     }
// }

// var toggle_customSidebar = false,
//     custom_open = 0;

// if (!toggle_customSidebar) {
//     var toggle = $(".custom-template .custom-toggle");

//     toggle.on("click", function () {
//         if (custom_open == 1) {
//             $(".custom-template").removeClass("open");
//             toggle.removeClass("toggled");
//             custom_open = 0;
//         } else {
//             $(".custom-template").addClass("open");
//             toggle.addClass("toggled");
//             custom_open = 1;
//         }
//     });
//     toggle_customSidebar = true;
// }

// function getCheckmark() {
//     var checkmark = `<i class="gg-check"></i>`;
//     $(".btnSwitch").find("button").empty();
//     $(".btnSwitch").find("button.selected").append(checkmark);
// }


"use strict";

// Function to save theme settings in local storage
function saveThemePreference(key, value) {
    localStorage.setItem(key, value);
}

// Function to load theme settings from local storage
function loadThemePreference() {
    const bodyBackgroundFull = localStorage.getItem("bodyBackgroundFull");
    const logoHeaderColor = localStorage.getItem("logoHeaderColor");
    const topBarColor = localStorage.getItem("topBarColor");
    const sideBarColor = localStorage.getItem("sideBarColor");
    // const loaderColor = localStorage.getItem("loaderColor");

    if (bodyBackgroundFull) $("body").attr("data-background-full", bodyBackgroundFull);
    if (logoHeaderColor) {
        $(".logo-header").attr("data-background-color", logoHeaderColor);
        setSelectedButton(".changeLogoHeaderColor", logoHeaderColor);
    }
    if (topBarColor) {
        $(".main-header .navbar-header").attr("data-background-color", topBarColor);
        setSelectedButton(".changeTopBarColor", topBarColor);
    }
    if (sideBarColor) {
        $(".sidebar").attr("data-background-color", sideBarColor);
        setSelectedButton(".changeSideBarColor", sideBarColor);
    }
    // if (loaderColor) {
    //     $(".loader-container").attr("data-background-color", loaderColor);
    //     setSelectedButton(".changeLoaderColor", loaderColor);
    // }
}

// Utility function to set the selected button and add a check mark
function setSelectedButton(selector, color) {
    $(selector).removeClass("selected").find("i").remove(); // Remove old selection
    const selectedButton = $(`${selector}[data-color="${color}"]`);
    selectedButton.addClass("selected").append('<i class="gg-check"></i>');
}

// Initialize theme on page load
$(document).ready(function () {
    loadThemePreference();
    customCheckColor();
});

// Setting Color
$(window).resize(function () {
    $(window).width();
});

$(".changeBodyBackgroundFullColor").on("click", function () {
    const color = $(this).attr("data-color");
    if (color === "default") {
        $("body").removeAttr("data-background-full");
        localStorage.removeItem("bodyBackgroundFull");
    } else {
        $("body").attr("data-background-full", color);
        saveThemePreference("bodyBackgroundFull", color);
    }

    $(this).parent().find(".changeBodyBackgroundFullColor").removeClass("selected").find("i").remove();
    $(this).addClass("selected").append('<i class="gg-check"></i>');
});

$(".changeLogoHeaderColor").on("click", function () {
    const color = $(this).attr("data-color");
    if (color === "default") {
        $(".logo-header").removeAttr("data-background-color");
        localStorage.removeItem("logoHeaderColor");
    } else {
        $(".logo-header").attr("data-background-color", color);
        saveThemePreference("logoHeaderColor", color);
    }

    setSelectedButton(".changeLogoHeaderColor", color);
    customCheckColor();
});

$(".changeTopBarColor").on("click", function () {
    const color = $(this).attr("data-color");
    if (color === "default") {
        $(".main-header .navbar-header").removeAttr("data-background-color");
        localStorage.removeItem("topBarColor");
    } else {
        $(".main-header .navbar-header").attr("data-background-color", color);
        saveThemePreference("topBarColor", color);
    }

    setSelectedButton(".changeTopBarColor", color);
});

$(".changeSideBarColor").on("click", function () {
    const color = $(this).attr("data-color");
    if (color === "default") {
        $(".sidebar").removeAttr("data-background-color");
        localStorage.removeItem("sideBarColor");
    } else {
        $(".sidebar").attr("data-background-color", color);
        saveThemePreference("sideBarColor", color);
    }

    setSelectedButton(".changeSideBarColor", color);
});

// $(".changeLoaderColor").on("click", function () {
//     const color = $(this).attr("data-color");
//     if (color === "default") {
//         $(".loader-container").removeAttr("data-background-color");
//         localStorage.removeItem("loaderColor");
//     } else {
//         $(".loader-container").attr("data-background-color", color);
//         saveThemePreference("loaderColor", color);
//     }

//     setSelectedButton(".changeLoaderColor", color);
// });

// Function to update logo based on the selected color
function customCheckColor() {
    const logoHeader = $(".logo-header").attr("data-background-color");
    $(".logo-header .navbar-brand").attr("src", logoHeader !== "white" ? "/static/img/gts-logo.png" : "/static/img/gts-logo-dark.png");
}

// Sidebar toggle functionality
var toggle_customSidebar = false,
    custom_open = 0;

if (!toggle_customSidebar) {
    const toggle = $(".custom-template .custom-toggle");

    toggle.on("click", function () {
        if (custom_open == 1) {
            $(".custom-template").removeClass("open");
            toggle.removeClass("toggled");
            custom_open = 0;
        } else {
            $(".custom-template").addClass("open");
            toggle.addClass("toggled");
            custom_open = 1;
        }
    });
    toggle_customSidebar = true;
}
