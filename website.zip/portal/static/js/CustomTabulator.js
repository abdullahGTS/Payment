//define column header menu as column visibility toggle
var headerMenu = function () {
    var menu = [];
    var columns = this.getColumns();

    for (let column of columns) {

        //create checkbox element using font awesome icons
        let icon = document.createElement("i");
        icon.classList.add("fas");
        icon.classList.add(column.isVisible() ? "fa-check-square" : "fa-square");

        //build label
        let label = document.createElement("span");
        let title = document.createElement("span");

        title.textContent = " " + column.getDefinition().title;

        label.appendChild(icon);
        label.appendChild(title);

        //create menu item
        menu.push({
            label: label,
            action: function (e) {
                //prevent menu closing
                e.stopPropagation();

                //toggle current column visibility
                column.toggle();

                //change menu item icon
                if (column.isVisible()) {
                    icon.classList.remove("fa-square");
                    icon.classList.add("fa-check-square");
                } else {
                    icon.classList.remove("fa-check-square");
                    icon.classList.add("fa-square");
                }
            }
        });
    }

    return menu;
};

//Define variables for input elements
var fieldEl = document.getElementById("filter_field");
var typeEl = document.getElementById("filter_type");
var valueEl = document.getElementById("filter_value");

//Define variables for input elements
var fieldSEl = document.getElementById("sort_field");
var dirEl = document.getElementById("sort_direction");

//Trigger setFilter function with correct parameters
function updateFilter() {
    var filterVal = fieldEl.options[fieldEl.selectedIndex].value;
    var typeVal = typeEl.options[typeEl.selectedIndex].value;

    var filter = filterVal;

    if (filterVal) {
        table.setFilter(filter, typeVal, valueEl.value);
    }
}

//Update filters on value change
document.getElementById("filter_field").addEventListener("change", updateFilter);
document.getElementById("filter_type").addEventListener("change", updateFilter);
document.getElementById("filter_value").addEventListener("keyup", updateFilter);

//Clear filters on "Clear Filters" button click
document.getElementById("filter_clear").addEventListener("click", function () {
    fieldEl.value = "";
    typeEl.value = "";
    valueEl.value = "";

    table.clearFilter();
});

var table2 = new Tabulator("#example-table-theme", {
    layout: "fitColumns",          // Fit columns to the table width
    responsiveLayout: "hide",       // Hide columns that don’t fit
    height: window.innerHeight / 2,
    printAsHtml: true,
    printStyled: true,
    // autoColumns:true,
    // printRowRange: "all",
    // textDirection: "rtl",
    printHeader: `
    <div class="row mt-4 mb-4">
        <div class="col-12 d-flex justify-content-center align-items-center">
            <h1>Products Table</h1>
        </div>
    </div>
    <hr>
    `,
    printFooter: `
    <div class="row mt-4">
        <div class="col-12 d-flex justify-content-center align-items-center">
            <img src='/static/img/gts-logo.png' alt='gts-logo' style="width: 50%;height: 100%;" />
        </div>
    </div>
    `,
    // clipboard: true,
    // clipboardPasteAction: "replace",
    // resizableRows: true,
    // resizableRowGuide: true,
    // resizableColumnGuide: true,
    // movableColumns: true,
    ajaxURL: "http://127.0.0.1:8000/adminpanal/product/view/api/",
    ajaxParams: { page: 1, size: 10 },  // Start with page 1 and size 3
    progressiveLoad: "scroll",      // Enable progressive loading with scroll
    placeholder: "No Product Data",
    selectableRows: true, //make rows selectable
    // addRowPos: "top",
    // history: true,
    paginationSize: 10,
    columnDefaults: {
        tooltip: true,
    },
    langs: {
        "ar-eg": { //French language definition
            "columns": {
                "id": "مسلسل",
                "number": "الرقم",
                "name": "الاسم",
                "price": "السعر",
                "timestamp": "تاريخ الانشاء",
            },
        }
    },
    columns: [
        { title: "ID", field: "id", hozAlign: "center", sorter: "number", headerMenu: headerMenu },
        { title: "Number", field: "number", hozAlign: "center", sorter: "number", headerMenu: headerMenu },
        { title: "Name", field: "name", hozAlign: "center", sorter: "string", headerMenu: headerMenu },
        { title: "Price", field: "price", hozAlign: "center", sorter: "number", headerMenu: headerMenu },
        { title: "Timestamp", field: "timestamp", hozAlign: "center", sorter: "datetime", headerMenu: headerMenu },
    ],
});
//Trigger sort when "Trigger Sort" button is clicked
document.getElementById("sort_trigger").addEventListener("click", function () {
    table.setSort(fieldSEl.options[fieldSEl.selectedIndex].value, dirEl.options[dirEl.selectedIndex].value);
});
table.on("rowSelectionChanged", function (data, rows) {
    document.getElementById("select_stats").innerHTML = data.length;
});
//select row on "select all" button click
document.getElementById("select_all").addEventListener("click", function () {
    table.selectRow();
});
//deselect row on "deselect all" button click
document.getElementById("deselect_all").addEventListener("click", function () {
    table.deselectRow();
});
//Add row on "Add Row" button click
document.getElementById("add_row").addEventListener("click", function () {
    table.addRow({});
});
//Delete row on "Delete Row" button click
document.getElementById("del_row").addEventListener("click", function () {
    table.deleteRow(1);
});
//Clear table on "Empty the table" button click
document.getElementById("clear").addEventListener("click", function () {
    table.clearData()
});
//Reset table contents on "Reset the table" button click
document.getElementById("reset").addEventListener("click", function () {
    table.setData("http://127.0.0.1:8000/adminpanal/product/view/api/", { page: 1, size: 10 });
});

//trigger download of data.csv file
document.getElementById("download_csv").addEventListener("click", function () {
    table.download("csv", "data.csv");
});

//trigger download of data.json file
document.getElementById("download_json").addEventListener("click", function () {
    table.download("json", "data.json");
});

//trigger download of data.xlsx file
document.getElementById("download_xlsx").addEventListener("click", function () {
    table.download("xlsx", "data.xlsx", { sheetName: "My Data" });
});

//trigger download of data.pdf file
document.getElementById("download_pdf").addEventListener("click", function () {
    table.download("pdf", "data.pdf", {
        orientation: "portrait", //set page orientation to portrait
        title: "Example Report", //add title to report
    });
});

//trigger download of data.html file
document.getElementById("download_html").addEventListener("click", function () {
    table.download("html", "data.html", { style: true });
});

//print button
document.getElementById("print_table").addEventListener("click", function () {
    // Get the selected print range from the dropdown
    var selectedRange = document.getElementById("print_range").value;
    console.log(selectedRange);
    // Update printRowRange on the table instance
    table.options.printRowRange = selectedRange;
    // Print the table using the selected printRowRange
    table.print(false, true);
});

//set locale to French
document.getElementById("lang_arabic").addEventListener("click", function () {
    table.setLocale("ar-eg");
    document.getElementById("example-table-theme").setAttribute("dir", "rtl");
});
//set default locale
document.getElementById("lang_default").addEventListener("click", function () {
    table.setLocale("");
    document.getElementById("example-table-theme").setAttribute("dir", "ltr");
});