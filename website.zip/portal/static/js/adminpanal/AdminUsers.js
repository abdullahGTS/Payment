// document.getElementById('upload_btn').addEventListener('click', ()=>{
//     // Get references to the DOM elements
//     const ppInput = document.getElementById("pp_input");
//     const newAvatar = document.getElementById("new_avater");
//     const defaultAvatar = document.getElementById("default_avater");
//     const avatarImg = newAvatar.querySelector(".avatar-img");
//     ppInput.click();

//     // Handle the file input change event
//     ppInput.addEventListener("change", function () {
//         const file = this.files[0];
        
//         if (file) {
//             // Create a URL for the selected file and update the img src
//             const reader = new FileReader();
//             reader.onload = function (e) {
//                 avatarImg.src = e.target.result;
//                 avatarImg.alt = file.name;
//                 newAvatar.classList.remove("d-none"); // Show the image container
//                 defaultAvatar.classList.add('d-none'); // Hide the SVG
//             };
//             reader.readAsDataURL(file);
//         }
//     });
// });

document.getElementById('upload_btn').addEventListener('click', () => {
    // Get references to the DOM elements
    const ppInput = document.getElementById("pp_input");
    const newAvatar = document.getElementById("new_avater");
    const defaultAvatar = document.getElementById("default_avater");
    const avatarImg = newAvatar.querySelector(".avatar-img");
    ppInput.click();

    // Handle the file input change event
    ppInput.addEventListener("change", function () {
        const file = this.files[0];

        if (file) {
            // Check the file size (in bytes)
            const maxSize = 5 * 1024 * 1024; // 2 MB in bytes

            if (file.size > maxSize) {
                ppInput.value = '';
                $.notify({
                    icon: 'fas fa-user',
                    title: 'Validation Error',
                    message: 'Image size exceeds 5 MB. Please select a smaller image.',
                }, {
                    type: 'danger',
                    placement: {
                        from: "top",
                        align: "right"
                    },
                    time: 1000,
                });
                return; // Exit the function if the file is too large
            }

            // Create a URL for the selected file and update the img src
            const reader = new FileReader();
            reader.onload = function (e) {
                avatarImg.src = e.target.result;
                avatarImg.alt = file.name;
                newAvatar.classList.remove("d-none"); // Show the image container
                defaultAvatar.classList.add('d-none'); // Hide the SVG
            };
            reader.readAsDataURL(file);
        }
    });
});


document.getElementById('delete_btn').addEventListener('click', () => {
    // Get references to the DOM elements
    const ppInput = document.getElementById("pp_input");
    const newAvatar = document.getElementById("new_avater");
    const defaultAvatar = document.getElementById("default_avater");
    const avatarImg = newAvatar.querySelector(".avatar-img");
    ppInput.value = '';
    avatarImg.src = '';
    avatarImg.alt = '';
    newAvatar.classList.add("d-none"); // Show the image container
    defaultAvatar.classList.remove('d-none'); // Hide the SVG
});


document.getElementById('view_password').addEventListener('click', () => {
    // console.log(e.target);
    var password = document.getElementById('password');
    if (password.type == 'text') {
        password.type = 'password';
        document.querySelector('#view_password i').classList.replace('fa-eye-slash', 'fa-eye');
    } else {
        password.type = 'text';
        document.querySelector('#view_password i').classList.replace('fa-eye', 'fa-eye-slash');
    }
});


document.getElementById('default_password').addEventListener('click', () => {
    // console.log(e.target);
    var password = document.getElementById('password');
    password.value = "qwerty123456";
});


document.getElementById('submitUser').addEventListener('click', () => {
    var pp_input = document.getElementById('pp_input');
    var first_name = document.getElementById('first_name');
    var last_name = document.getElementById('last_name');
    var email = document.getElementById('email');
    var password = document.getElementById('password');
    var role = document.getElementById('role');
    var first_login = document.getElementById('first_login');
    var is_locked = document.getElementById('is_locked');
    var flag = true;

    if (first_name.value == '') {
        let parentFormGroup = $('#first_name').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $.notify({
            icon: 'fas fa-id-card',
            title: 'Validation Error',
            message: 'Please enter a valid first name.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        var firstNamePattern = /^[A-Za-z]{2,}$/;
        // Test the input value against the pattern
        if (!firstNamePattern.test(first_name.value)) {
            let parentFormGroup = $('#first_name').closest('.form-group');
            parentFormGroup.addClass('has-error');
            $.notify({
                icon: 'fas fa-id-card',
                title: 'Validation Error',
                message: 'First name must be at least 2 characters long and contain only letters.',
            },{
                type: 'danger',
                placement: {
                    from: "top",
                    align: "right"
                },
                time: 1000,
            });
            flag = false;
        }else{
            let parentFormGroup = $('#first_name').closest('.form-group');
            parentFormGroup.removeClass('has-error');
        }
    }
    if (last_name.value == '') {
        let parentFormGroup = $('#last_name').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $.notify({
            icon: 'fas fa-id-card',
            title: 'Validation Error',
            message: 'Please enter a valid last name.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        var lastNamePattern = /^[A-Za-z]{2,}$/;
        // Test the input value against the pattern
        if (!lastNamePattern.test(last_name.value)) {
            let parentFormGroup = $('#last_name').closest('.form-group');
            parentFormGroup.addClass('has-error');
            $.notify({
                icon: 'fas fa-id-card',
                title: 'Validation Error',
                message: 'Last name must be at least 2 characters long and contain only letters.',
            },{
                type: 'danger',
                placement: {
                    from: "top",
                    align: "right"
                },
                time: 1000,
            });
            flag = false;
        }else{
            let parentFormGroup = $('#last_name').closest('.form-group');
            parentFormGroup.removeClass('has-error');
        }
    }
    if (email.value == '') {
        let parentFormGroup = $('#email').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $.notify({
            icon: 'fas fa-envelope',
            title: 'Validation Error',
            message: 'Please enter a valid email.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        // Define the pattern for a basic email format
        var emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        // Test the input value against the pattern
        if (!emailPattern.test(email.value)) {
            let parentFormGroup = $('#email').closest('.form-group');
            parentFormGroup.addClass('has-error');
            $.notify({
                icon: 'fas fa-envelope',
                title: 'Validation Error',
                message: 'Email is invalid. Please enter a valid email address, e.g., user@example.com.',
            },{
                type: 'danger',
                placement: {
                    from: "top",
                    align: "right"
                },
                time: 1000,
            });
            flag = false;
        }else{
            let parentFormGroup = $('#email').closest('.form-group');
            parentFormGroup.removeClass('has-error');
        }
    }
    if (password.value == '') {
        let parentFormGroup = $('#password').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $.notify({
            icon: 'fas fa-lock',
            title: 'Validation Error',
            message: 'Please enter a valid password.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        // Define the pattern for a basic email format
        var passwordPattern = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;
        // Test the input value against the pattern
        if (!passwordPattern.test(password.value)) {
            let parentFormGroup = $('#password').closest('.form-group');
            parentFormGroup.addClass('has-error');
            $.notify({
                icon: 'fas fa-lock',
                title: 'Validation Error',
                message: 'Password must be at least 8 characters long and contain a mix of letters and numbers.',
            },{
                type: 'danger',
                placement: {
                    from: "top",
                    align: "right"
                },
                time: 1000,
            });
            flag = false;
        }else{
            let parentFormGroup = $('#password').closest('.form-group');
            parentFormGroup.removeClass('has-error');
        }
    }
    if (role.value == '') {
        let parentFormGroup = $('#role').closest('.form-group');
        parentFormGroup.addClass('has-error');
        // Add Class
        $('#role').selectpicker('setStyle', 'border-danger', 'add');
        $.notify({
            icon: 'fas fa-user-tie',
            title: 'Validation Error',
            message: 'Please choose a role.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        let parentFormGroup = $('#role').closest('.form-group');
        parentFormGroup.removeClass('has-error');
        // Add Class
        $('#role').selectpicker('setStyle', 'border-danger', 'remove');
        $('#role').selectpicker('setStyle', 'border-gray', 'add');
    }

    if (flag) {
        // Create FormData object
        const formData = new FormData();
        // Append files to FormData
        formData.append(`profile_picture`, pp_input.files[0]);
        formData.append(`first_name`, first_name.value);
        formData.append(`last_name`, last_name.value);
        formData.append(`email`, email.value);
        formData.append(`password`, password.value);
        formData.append(`role`, role.value);
        formData.append(`first_login`, first_login.checked);
        formData.append(`is_locked`, is_locked.checked);

        $.ajax({
            url: '/adminpanal/users/add/api/',
            type: 'POST',
            dataType: 'json', // Set the content type if sending JSON data
            data: formData, // Convert data to JSON string if sending JSON
            processData: false,  // Don't process the data
            contentType: false,  // Don't set content type
            headers: {
                'X-CSRFToken': document.getElementById('csrfToken').value,
            },
            success: function (t) {
                // console.log(t);
                if (t.status == 'exists') {
                    // $.notify({
                    //     icon: 'fas fa-droplet',
                    //     title: 'Submittion Error',
                    //     message: 'Product number already exists.',
                    // }, {
                    //     type: 'danger',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Submittion Error!", "E-Mail already exists.", {
                        icon: "error",
                        buttons: false,
                        timer: 2000
                    });
                }
                if (t.status == 'No Post') {
                    // $.notify({
                    //     icon: 'fas fa-gears',
                    //     title: 'Technical Error',
                    //     message: 'You have to contact with your administrator.',
                    // }, {
                    //     type: 'danger',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Technical Error!", "You have to contact with your administrator.", {
                        icon: "error",
                        buttons: false,
                        timer: 2000
                    });
                }
                if (t.status == 'added') {
                    // $.notify({
                    //     icon: 'fas fa-droplet',
                    //     title: 'Submittion Successfully',
                    //     message: 'The product has been submitted successfully.',
                    // }, {
                    //     type: 'success',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Thank you", "The User has been submitted successfully.", {
                        icon: "success",
                        buttons: false,
                        timer: 2000
                    });
                    document.getElementById('resetUser').click();
                    getAllUsers();
                    document.getElementById("reset").click();
                }

            },
        });
    }
});

// function submitProduct(){
//     product_num = document.getElementById('product_num');
//     product_name = document.getElementById('product_name');
//     product_price = document.getElementById('product_price');
//     if(product_num.value == ''){
//         product_num.classList.add('bg-danger', 'text-white');
//     }else if(product_name.value == ''){
//         product_name.classList.add('bg-danger', 'text-white');
//     }else if(product_price.value == ''){
//         product_price.classList.add('bg-danger', 'text-white');
//     }else{
//         document.getElementById('miniloader').classList.remove('d-none');
//         $.ajax({
//             url: "/adminpanal/product/add/api/",
//             method: "GET",
//             dataType: "json",
//             data: {
//                 'product_num': product_num.value,
//                 'product_name': product_name.value,
//                 'product_price': product_price.value,
//             },
//             success: function (t) {
//                 console.log(t);
//                 if(t.status == 'exists'){
//                     document.getElementById('error_msg').innerHTML = 'Product Already Exists!';
//                     document.getElementById('error_msg').classList.add('text-danger');
//                     document.getElementById('error_msg').classList.remove('d-none');
//                     document.getElementById('miniloader').classList.add('d-none');
//                     setTimeout(()=>{
//                         document.getElementById('error_msg').innerHTML = '';
//                         document.getElementById('error_msg').classList.remove('text-danger');
//                         document.getElementById('error_msg').classList.add('d-none');
//                     },3000);
//                 }


//                 if(t.status == 'No Get'){
//                     document.getElementById('error_msg').innerHTML = 'Technical Error!';
//                     document.getElementById('error_msg').classList.add('text-danger');
//                     document.getElementById('error_msg').classList.remove('d-none');

//                     setTimeout(()=>{
//                         document.getElementById('error_msg').innerHTML = '';
//                         document.getElementById('error_msg').classList.remove('text-danger');
//                         document.getElementById('error_msg').classList.add('d-none');
//                     },3000);
//                 }


//                 if(t.status == 'added'){
//                     document.getElementById('error_msg').innerHTML = 'Product is added successfully.';
//                     document.getElementById('error_msg').classList.add('text-success');
//                     document.getElementById('error_msg').classList.remove('d-none');

//                     product_num.classList.remove('bg-danger', 'text-white');
//                     product_name.classList.remove('bg-danger', 'text-white');
//                     product_price.classList.remove('bg-danger', 'text-white');
//                     product_num.value = '';
//                     product_name.value = '';
//                     product_price.value = '';

//                     var e = $("#productTbl");
//                     e.bootstrapTable("showLoading");
//                     e.bootstrapTable("append",{
//                         'id':t.id,
//                         'number':t.number,
//                         'name':t.name,
//                         'price':t.price,
//                         'timestamp':t.timestamp,
//                         'actions': `<button class="btn btn-dark w-100" onclick="deleteProduct('${t.id}')">Delete</button>`,
//                     });
//                     e.bootstrapTable("refresh");
//                     e.bootstrapTable("hideLoading");
//                     document.getElementById('miniloader').classList.add('d-none');
//                     document.getElementById('products_num').innerHTML = parseInt(document.getElementById('products_num').innerHTML) + 1;

//                     setTimeout(()=>{
//                         document.getElementById('error_msg').innerHTML = '';
//                         document.getElementById('error_msg').classList.remove('text-danger');
//                         document.getElementById('error_msg').classList.add('d-none');
//                     },3000);
//                 }

//             },
//         });
//     }
// }

document.getElementById('resetUser').addEventListener('click', () => {
    document.getElementById('new_avater').classList.add('d-none');
    document.querySelector('#new_avater .avatar-img').src = '';
    document.querySelector('#new_avater .avatar-img').alt = '';
    document.getElementById('default_avater').classList.remove('d-none');
    document.getElementById('first_name').value = '';
    document.getElementById('last_name').value = '';
    document.getElementById('email').value = '';
    document.getElementById('password').value = '';
    document.querySelector('#view_password i').classList.replace('fa-eye-slash', 'fa-eye');
    $('#role').selectpicker('val', '');
    $('#role').selectpicker('refresh');
    document.getElementById('first_login').checked = true;
    document.getElementById('is_locked').checked = false;
    // Loop over each element and remove the 'has-error' class if it exists
    document.querySelectorAll('.form-group').forEach((formGroup) => {
        if (formGroup.classList.contains('has-error')) {
            formGroup.classList.remove('has-error');
        }
    });
    $('#role').selectpicker('setStyle', 'border-danger', 'remove');
    $('#role').selectpicker('setStyle', 'border-gray', 'add');
    document.getElementById('pp_input').value = '';
});

//define column header menu as column visibility toggle
var headerMenu = function () {
    var menu = [];
    var columns = this.getColumns();

    for (let column of columns) {

        //create checkbox element using font awesome icons
        let icon = document.createElement("i");
        icon.classList.add("fas");
        icon.classList.add(column.isVisible() ? "fa-check-square" : "fa-square");

        //build label
        let label = document.createElement("span");
        let title = document.createElement("span");

        title.textContent = " " + column.getDefinition().title;

        label.appendChild(icon);
        label.appendChild(title);

        //create menu item
        menu.push({
            label: label,
            action: function (e) {
                //prevent menu closing
                e.stopPropagation();

                //toggle current column visibility
                column.toggle();

                //change menu item icon
                if (column.isVisible()) {
                    icon.classList.remove("fa-square");
                    icon.classList.add("fa-check-square");
                } else {
                    icon.classList.remove("fa-check-square");
                    icon.classList.add("fa-square");
                }
            }
        });
    }

    return menu;
};

//Define variables for input elements
var fieldSEl = document.getElementById("sort_field");
var dirEl = document.getElementById("sort_direction");

//Define variables for input elements
var fieldEl = document.getElementById("filter_field");
var typeEl = document.getElementById("filter_type");
var valueEl = document.getElementById("filter_value");


//Trigger setFilter function with correct parameters
function updateFilter() {
    var filterVal = fieldEl.options[fieldEl.selectedIndex].value;
    var typeVal = typeEl.options[typeEl.selectedIndex].value;

    var filter = filterVal;

    if (filterVal) {
        table.setFilter(filter, typeVal, valueEl.value);
    }
}

//Update filters on value change
document.getElementById("filter_field").addEventListener("change", updateFilter);
document.getElementById("filter_type").addEventListener("change", updateFilter);
document.getElementById("filter_value").addEventListener("keyup", updateFilter);

//Clear filters on "Clear Filters" button click
document.getElementById("filter_clear").addEventListener("click", function () {
    fieldEl.value = "";
    typeEl.value = "";
    valueEl.value = "";

    table.clearFilter();
});

// Define column configurations with headerMenu
function defaultColumns() {
    return [
        { title: "ID", field: "id", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
        { title: "Image", field: "image", hozAlign: "start", headerMenu: headerMenu, formatter: function (cell, formatterParams) {
            // Get the image URL from the cell data
            var imgUrl = cell.getValue();
            return `<a href="${imgUrl}" class="avatar avatar-xs" target="_blank">
                        <img src="${imgUrl}" class="avatar-img rounded-circle" alt="Profile Image" />
                    </a>`;
                }
        },
        { title: "First Name", field: "first_name", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
        { title: "Last Name", field: "last_name", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
        { title: "E-Mail", field: "email", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
        { title: "Role", field: "role", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
        {
            title: "Add Date", field: "add_date", hozAlign: "start", sorter: "datetime", sorterParams: {
                format: "yyyy-MM-dd HH:mm:ss",
                alignEmptyValues: "top",
            }, headerMenu: headerMenu
        },
        { title: "First Login", field: "first_login", hozAlign: "start", sorter: "boolean", formatter:"tickCross", headerMenu: headerMenu },
        { title: "Is Locked", field: "is_locked", hozAlign: "start", sorter: "boolean", formatter:"tickCross", headerMenu: headerMenu },
        // { title: "Attempts", field: "attempts", hozAlign: "start", sorter: "number", formatter:"star", headerMenu: headerMenu, formatterParams: {
        //     stars: 5,
        //     color: "#f25961",
        //     },
        // },
        {
            title: "Attempts",
            field: "attempts",
            hozAlign: "start",
            sorter: "number",
            formatter: function (cell, formatterParams) {
                const value = cell.getValue(); // Number of stars
                const maxStars = formatterParams.stars || 5;
                const color = formatterParams.color || "#f25961";
                
                let stars = "";
                for (let i = 0; i < maxStars; i++) {
                    stars += `<span style="color: ${i < value ? color : "#ccc"};font-weight: bold">x</span>`;
                }
                return stars;
            },
            formatterParams: {
                stars: 5, // Number of stars
                color: "#f25961", // Color of the stars
            },
            headerMenu: headerMenu
        }
    ];
}

// Initial Table Configuration Function
function createTable() {
    return new Tabulator("#users_table", {
        layout: "fitColumns",          // Fit columns to the table width
        responsiveLayout: "hide",       // Hide columns that don’t fit
        height: window.innerHeight / 2,
        printAsHtml: true,
        printStyled: true,
        textDirection: "ltr",
        printHeader: `
        <div class="row mt-4 mb-4">
            <div class="col-12 d-flex justify-content-center align-items-center">
                <h1>Users Table</h1>
            </div>
        </div>
        <hr>
        `,
        printFooter: `
        <div class="row mt-4">
            <div class="col-12 d-flex justify-content-center align-items-center">
                <img src='/static/img/gts-logo.png' alt='gts-logo' style="width: 50%;height: 100%;" />
            </div>
        </div>
        `,
        ajaxURL: "http://127.0.0.1:8000/adminpanal/users/view/api/",
        ajaxParams: { page: 1, size: 10 },
        progressiveLoad: "scroll",
        placeholder: "No Users Data",
        selectableRows: true,
        paginationSize: 10,
        columnDefaults: {
            tooltip: true,
        },
        langs: {
            "ar-eg": {
                "columns": {
                    "id": "مسلسل",
                    "first_name": "الاسم الاول",
                    "last_name": "الاسم الاخير",
                    "email": "البريد",
                    "role": "الوظيفة",
                    "image": "الصورة",
                    "add_date": "تاريخ الانشاء",
                    "first_login": "",
                    "is_locked": "مغلق",
                    "attempts": "محاولات الدخول الفاشلة",
                },
            }
        },
        columns: defaultColumns(),
    });
}

var table = createTable();

window.addEventListener('resize', function(){
    table.redraw(true); //trigger full rerender including all data and rows
});

// var table = new Tabulator("#users_table", {
//     layout: "fitColumns",          // Fit columns to the table width
//     responsiveLayout: "hide",       // Hide columns that don’t fit
//     height: window.innerHeight / 2,
//     printAsHtml: true,
//     printStyled: true,
//     // autoColumns:true,
//     // printRowRange: "all",
//     // textDirection: "rtl",
//     printHeader: `
//     <div class="row mt-4 mb-4">
//         <div class="col-12 d-flex justify-content-center align-items-center">
//             <h1>Products Table</h1>
//         </div>
//     </div>
//     <hr>
//     `,
//     printFooter: `
//     <div class="row mt-4">
//         <div class="col-12 d-flex justify-content-center align-items-center">
//             <img src='/static/img/gts-logo.png' alt='gts-logo' style="width: 50%;height: 100%;" />
//         </div>
//     </div>
//     `,
//     // clipboard: true,
//     // clipboardPasteAction: "replace",
//     // resizableRows: true,
//     // resizableRowGuide: true,
//     // resizableColumnGuide: true,
//     // movableColumns: true,
//     ajaxURL: "http://127.0.0.1:8000/adminpanal/product/view/api/",
//     ajaxParams: { page: 1, size: 10 },  // Start with page 1 and size 3
//     progressiveLoad: "scroll",      // Enable progressive loading with scroll
//     placeholder: "No Product Data",
//     selectableRows: true, //make rows selectable
//     // addRowPos: "top",
//     // history: true,
//     paginationSize: 10,
//     columnDefaults: {
//         tooltip: true,
//     },
//     langs: {
//         "ar-eg": { //French language definition
//             "columns": {
//                 "id": "مسلسل",
//                 "number": "الرقم",
//                 "name": "الاسم",
//                 "price": "السعر",
//                 "timestamp": "تاريخ الانشاء",
//             },
//         }
//     },
//     columns: [
//         { title: "ID", field: "id", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
//         { title: "Number", field: "number", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
//         { title: "Name", field: "name", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
//         { title: "Price", field: "price", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
//         { title: "Timestamp", field: "timestamp", hozAlign: "start", sorter: "datetime", headerMenu: headerMenu },
//     ],
// });

//Trigger sort when "Trigger Sort" button is clicked
document.getElementById("sort_trigger").addEventListener("click", function () {
    table.setSort(fieldSEl.options[fieldSEl.selectedIndex].value, dirEl.options[dirEl.selectedIndex].value);
});

document.getElementById("sort_reset").addEventListener("click", function () {
    table.setSort("id", "asc");
});

table.on("rowSelectionChanged", function (data, rows) {
    document.getElementById("select_stats").innerHTML = data.length;
});

//select row on "select all" button click
document.getElementById("select_all").addEventListener("click", function () {
    table.selectRow();
});

//deselect row on "deselect all" button click
document.getElementById("deselect_all").addEventListener("click", function () {
    table.deselectRow();
});

//Delete row on "Delete Row" button click
document.getElementById("del_row").addEventListener("click", function () {
    var rowid = document.getElementById('row_delete');
    if (rowid.value == '') {
        $.notify({
            icon: 'fas fa-trash',
            title: 'Validation Error',
            message: 'Please enter a valid row number.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
    } else {
        table.deleteRow(parseInt(rowid.value));
        rowid.value = '';
    }
});

//Clear table on "Empty the table" button click
document.getElementById("clear").addEventListener("click", function () {
    table.clearData()
});

//Reset table contents on "Reset the table" button click
document.getElementById("reset").addEventListener("click", function () {
    // table.setData("http://127.0.0.1:8000/adminpanal/product/view/api/", { page: 1, size: 10 });
    // Destroy current instance of the table
    table.destroy();
    // Recreate table with initial settings
    table = createTable();
});

document.getElementById('download_btn').addEventListener('click', () => {
    var file_name = document.getElementById('file_name');
    var download_type = document.getElementById('download_type');
    var flag = true;
    if (file_name.value == '') {
        $.notify({
            icon: 'fas fa-font',
            title: 'Validation Error',
            message: 'Please enter a valid file name.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (download_type.value == '') {
        $.notify({
            icon: 'fas fa-gear',
            title: 'Validation Error',
            message: 'Please choose a download type.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }

    if (flag) {
        if (download_type.value == 'csv') table.download("csv", `${file_name.value}.csv`);
        if (download_type.value == 'json') table.download("json", `${file_name.value}.json`);
        if (download_type.value == 'xlsx') table.download("xlsx", `${file_name.value}.xlsx`, { sheetName: file_name.value });
        if (download_type.value == 'pdf') {
            table.download("pdf", `${file_name.value}.pdf`, {
                orientation: "portrait", //set page orientation to portrait
                title: "Users Data", //add title to report
            });
        }
        if (download_type.value == 'html') table.download("html", `${file_name.value}.html`, { style: true });
    }
});

//print button
document.getElementById("print_table").addEventListener("click", function () {
    // Get the selected print range from the dropdown
    var selectedRange = document.getElementById("print_range").value;
    console.log(selectedRange);
    // Update printRowRange on the table instance
    table.options.printRowRange = selectedRange;
    // Print the table using the selected printRowRange
    table.print(false, true);
});


//set locale to French
document.getElementById("lang_arabic").addEventListener("click", function () {
    table.setLocale("ar-eg");
    table.setColumns(defaultColumns());  // Reload columns to apply headerMenu
    // document.getElementById("users_table").setAttribute("dir", "rtl");
});

//set default locale
document.getElementById("lang_default").addEventListener("click", function () {
    table.setLocale("");
    table.setColumns(defaultColumns());  // Reload columns to apply headerMenu
    // document.getElementById("users_table").setAttribute("dir", "ltr");
});

function getAllRoles() {
    $.ajax({
        url: "/adminpanal/users/roles/api/",
        method: "GET",
        dataType: "json",
        data: {},
        success: function (t) {
            console.log(t);
            const select = document.getElementById("role");
            const e_select = document.getElementById("e_role");

            // Clear any existing options (optional)
            select.innerHTML = '<option value="" selected disabled>Choose a role...</option>';
            e_select.innerHTML = '<option value="" selected disabled>Choose a role...</option>';

            // Add new options
            t.forEach(role => {
                const option1 = document.createElement("option");
                option1.value = role.id;
                option1.textContent = role.type;
                select.appendChild(option1);

                const option2 = document.createElement("option");
                option2.value = role.id;
                option2.textContent = role.type;
                e_select.appendChild(option2);
            });

            // Refresh selectpicker to apply changes
            $('#role').selectpicker('refresh');
            $('#e_role').selectpicker('refresh');
        },
    });
}

function getAllUsers() {
    $.ajax({
        url: "/adminpanal/users/all/api/",
        method: "GET",
        dataType: "json",
        data: {},
        success: function (t) {
            console.log(t);
            const select = document.getElementById("users_edit_list");
            const del_select = document.getElementById("users_list");

            // Clear any existing options (optional)
            select.innerHTML = '<option value="" selected disabled>Choose user to edit...</option>';
            del_select.innerHTML = '';

            // Add new options
            t.forEach(user => {
                const option1 = document.createElement("option");
                option1.value = user.id;
                option1.textContent = `${user.first_name} ${user.last_name}@${user.role}`;
                option1.setAttribute("data-subtext", `${user.email}`);
                select.appendChild(option1);

                const option2 = document.createElement("option");
                option2.value = user.id;
                option2.textContent = `${user.first_name} ${user.last_name}@${user.role}`;
                option2.setAttribute("data-subtext", `${user.email}`);
                del_select.appendChild(option2);
            });

            // Refresh selectpicker to apply changes
            $('#users_edit_list').selectpicker('refresh');
            $('#users_list').selectpicker('refresh');
        },
    });
}

$(function () {
    getAllRoles();
    getAllUsers();
});

document.getElementById('users_edit_list').addEventListener('change', (event)=>{
    console.log(event.target.value);
    document.querySelector('#pre_e_first_name i').className = 'spinner-border';
    document.querySelector('#pre_e_last_name i').className = 'spinner-border';
    document.querySelector('#pre_e_email i').className = 'spinner-border';
    document.querySelector('#pre_e_role i').className = 'spinner-border';
    $.ajax({
        url: "/adminpanal/users/single/api/",
        method: "GET",
        dataType: "json",
        data: {
            'user_id': event.target.value,
        },
        success: function (t) {
            console.log(t);
            document.getElementById('e_first_name').value = t.first_name;
            document.getElementById('e_first_name').removeAttribute('disabled');
            document.getElementById('e_last_name').value = t.last_name;
            document.getElementById('e_last_name').removeAttribute('disabled');
            document.getElementById('e_email').value = t.email;
            document.getElementById('e_email').removeAttribute('disabled');
            $('#e_role').selectpicker('val', `${t.role}`);
            document.getElementById('e_role').removeAttribute('disabled');
            $('#e_role').selectpicker('refresh');
            document.getElementById('e_first_login').checked = t.first_login;
            document.getElementById('e_first_login').removeAttribute('disabled');
            document.getElementById('e_is_locked').checked = t.is_locked;
            document.getElementById('e_is_locked').removeAttribute('disabled');

            const e_newAvatar = document.getElementById("e_new_avater");
            const e_defaultAvatar = document.getElementById("e_default_avater");
            const e_avatarImg = e_newAvatar.querySelector(".avatar-img");
            if(t.imageUrl != '' && t.imageAlt != ''){
                e_avatarImg.src = t.imageUrl;
                e_avatarImg.alt = t.imageAlt;
                e_newAvatar.classList.remove("d-none"); // Show the image container
                e_defaultAvatar.classList.add('d-none'); // Hide the SVG
                document.getElementById('e_pp_delete_flag').value = 'current';
            }else{
                e_avatarImg.src = '';
                e_avatarImg.alt = '';
                e_newAvatar.classList.add("d-none"); // Show the image container
                e_defaultAvatar.classList.remove('d-none'); // Hide the SVG
                document.getElementById('e_pp_delete_flag').value = 'current';
            }

            document.getElementById('e_delete_btn').removeAttribute('disabled');
            document.getElementById('e_upload_btn').removeAttribute('disabled');
            document.querySelector('#pre_e_first_name i').className = 'fas fa-id-card';
            document.querySelector('#pre_e_last_name i').className = 'fas fa-id-card';
            document.querySelector('#pre_e_email i').className = 'fas fa-envelope';
            document.querySelector('#pre_e_role i').className = 'fas fa-user-tie';
        },
    });
});

document.getElementById('e_upload_btn').addEventListener('click', () => {
    // Get references to the DOM elements
    const e_ppInput = document.getElementById("e_pp_input");
    const e_newAvatar = document.getElementById("e_new_avater");
    const e_defaultAvatar = document.getElementById("e_default_avater");
    const e_avatarImg = e_newAvatar.querySelector(".avatar-img");
    e_ppInput.click();

    // Handle the file input change event
    e_ppInput.addEventListener("change", function () {
        const file = this.files[0];

        if (file) {
            // Check the file size (in bytes)
            const maxSize = 5 * 1024 * 1024; // 2 MB in bytes

            if (file.size > maxSize) {
                e_ppInput.value = '';
                $.notify({
                    icon: 'fas fa-user',
                    title: 'Validation Error',
                    message: 'Image size exceeds 5 MB. Please select a smaller image.',
                }, {
                    type: 'danger',
                    placement: {
                        from: "top",
                        align: "right"
                    },
                    time: 1000,
                });
                return; // Exit the function if the file is too large
            }

            // Create a URL for the selected file and update the img src
            const reader = new FileReader();
            reader.onload = function (e) {
                e_avatarImg.src = e.target.result;
                e_avatarImg.alt = file.name;
                e_newAvatar.classList.remove("d-none"); // Show the image container
                e_defaultAvatar.classList.add('d-none'); // Hide the SVG
            };
            reader.readAsDataURL(file);
            document.getElementById('e_pp_delete_flag').value = 'new';
        }
    });
});

document.getElementById('e_delete_btn').addEventListener('click', () => {
    // Get references to the DOM elements
    const e_ppInput = document.getElementById("e_pp_input");
    const e_newAvatar = document.getElementById("e_new_avater");
    const e_defaultAvatar = document.getElementById("e_default_avater");
    const e_avatarImg = e_newAvatar.querySelector(".avatar-img");
    e_ppInput.value = '';
    e_avatarImg.src = '';
    e_avatarImg.alt = '';
    e_newAvatar.classList.add("d-none"); // Show the image container
    e_defaultAvatar.classList.remove('d-none'); // Hide the SVG
    document.getElementById('e_pp_delete_flag').value = 'avater';
});

document.getElementById('submitEditUser').addEventListener('click', () => {
    var users_edit_list = document.getElementById('users_edit_list');
    var e_pp_input = document.getElementById('e_pp_input');
    var e_first_name = document.getElementById('e_first_name');
    var e_last_name = document.getElementById('e_last_name');
    var e_email = document.getElementById('e_email');
    var e_role = document.getElementById('e_role');
    var e_first_login = document.getElementById('e_first_login');
    var e_is_locked = document.getElementById('e_is_locked');
    var e_pp_delete_flag = document.getElementById('e_pp_delete_flag');
    var flag = true;

    if (e_first_name.value == '') {
        let parentFormGroup = $('#e_first_name').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $.notify({
            icon: 'fas fa-id-card',
            title: 'Validation Error',
            message: 'Please enter a valid first name.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        var firstNamePattern = /^[A-Za-z]{2,}$/;
        // Test the input value against the pattern
        if (!firstNamePattern.test(e_first_name.value)) {
            let parentFormGroup = $('#e_first_name').closest('.form-group');
            parentFormGroup.addClass('has-error');
            $.notify({
                icon: 'fas fa-id-card',
                title: 'Validation Error',
                message: 'First name must be at least 2 characters long and contain only letters.',
            },{
                type: 'danger',
                placement: {
                    from: "top",
                    align: "right"
                },
                time: 1000,
            });
            flag = false;
        }else{
            let parentFormGroup = $('#e_first_name').closest('.form-group');
            parentFormGroup.removeClass('has-error');
        }
    }
    if (e_last_name.value == '') {
        let parentFormGroup = $('#e_last_name').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $.notify({
            icon: 'fas fa-id-card',
            title: 'Validation Error',
            message: 'Please enter a valid last name.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        var lastNamePattern = /^[A-Za-z]{2,}$/;
        // Test the input value against the pattern
        if (!lastNamePattern.test(e_last_name.value)) {
            let parentFormGroup = $('#e_last_name').closest('.form-group');
            parentFormGroup.addClass('has-error');
            $.notify({
                icon: 'fas fa-id-card',
                title: 'Validation Error',
                message: 'Last name must be at least 2 characters long and contain only letters.',
            },{
                type: 'danger',
                placement: {
                    from: "top",
                    align: "right"
                },
                time: 1000,
            });
            flag = false;
        }else{
            let parentFormGroup = $('#e_last_name').closest('.form-group');
            parentFormGroup.removeClass('has-error');
        }
    }
    if (e_email.value == '') {
        let parentFormGroup = $('#e_email').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $.notify({
            icon: 'fas fa-envelope',
            title: 'Validation Error',
            message: 'Please enter a valid email.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        // Define the pattern for a basic email format
        var emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        // Test the input value against the pattern
        if (!emailPattern.test(e_email.value)) {
            let parentFormGroup = $('#e_email').closest('.form-group');
            parentFormGroup.addClass('has-error');
            $.notify({
                icon: 'fas fa-envelope',
                title: 'Validation Error',
                message: 'Email is invalid. Please enter a valid email address, e.g., user@example.com.',
            },{
                type: 'danger',
                placement: {
                    from: "top",
                    align: "right"
                },
                time: 1000,
            });
            flag = false;
        }else{
            let parentFormGroup = $('#e_email').closest('.form-group');
            parentFormGroup.removeClass('has-error');
        }
    }
    if (e_role.value == '') {
        let parentFormGroup = $('#e_role').closest('.form-group');
        parentFormGroup.addClass('has-error');
        // Add Class
        $('#e_role').selectpicker('setStyle', 'border-danger', 'add');
        $.notify({
            icon: 'fas fa-user-tie',
            title: 'Validation Error',
            message: 'Please choose a role.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        let parentFormGroup = $('#e_role').closest('.form-group');
        parentFormGroup.removeClass('has-error');
        // Add Class
        $('#e_role').selectpicker('setStyle', 'border-danger', 'remove');
        $('#e_role').selectpicker('setStyle', 'border-gray', 'add');
    }

    if (flag) {
        // Create FormData object
        const formData = new FormData();
        // Append files to FormData
        console.log(e_pp_input.files[0]);
        formData.append(`user_id`, users_edit_list.value);
        formData.append(`e_profile_picture`, e_pp_input.files[0]);
        formData.append(`e_first_name`, e_first_name.value);
        formData.append(`e_last_name`, e_last_name.value);
        formData.append(`e_email`, e_email.value);
        formData.append(`e_role`, e_role.value);
        formData.append(`e_first_login`, e_first_login.checked);
        formData.append(`e_is_locked`, e_is_locked.checked);
        formData.append(`e_pp_delete_flag`, e_pp_delete_flag.value);

        $.ajax({
            url: '/adminpanal/users/edit/api/',
            type: 'POST',
            dataType: 'json', // Set the content type if sending JSON data
            data: formData, // Convert data to JSON string if sending JSON
            processData: false,  // Don't process the data
            contentType: false,  // Don't set content type
            headers: {
                'X-CSRFToken': document.getElementById('csrfToken').value,
            },
            success: function (t) {
                // console.log(t);
                if (t.status == 'exists') {
                    // $.notify({
                    //     icon: 'fas fa-droplet',
                    //     title: 'Submittion Error',
                    //     message: 'Product number already exists.',
                    // }, {
                    //     type: 'danger',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Submittion Error!", "E-Mail already exists.", {
                        icon: "error",
                        buttons: false,
                        timer: 2000
                    });
                }
                if (t.status == 'user_error') {
                    // $.notify({
                    //     icon: 'fas fa-droplet',
                    //     title: 'Submittion Error',
                    //     message: 'Product number already exists.',
                    // }, {
                    //     type: 'danger',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Sorry!", "Can't edit the selected user.", {
                        icon: "error",
                        buttons: false,
                        timer: 2000
                    });
                }
                if (t.status == 'No Post') {
                    // $.notify({
                    //     icon: 'fas fa-gears',
                    //     title: 'Technical Error',
                    //     message: 'You have to contact with your administrator.',
                    // }, {
                    //     type: 'danger',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Technical Error!", "You have to contact with your administrator.", {
                        icon: "error",
                        buttons: false,
                        timer: 2000
                    });
                }
                if (t.status == 'updated') {
                    // $.notify({
                    //     icon: 'fas fa-droplet',
                    //     title: 'Submittion Successfully',
                    //     message: 'The product has been submitted successfully.',
                    // }, {
                    //     type: 'success',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Thank you", "The User has been submitted successfully.", {
                        icon: "success",
                        buttons: false,
                        timer: 2000
                    });
                    document.getElementById('resetEditUser').click();
                    // getAllProducts();
                    document.getElementById("reset").click();
                }

            },
        });
    }
});

document.getElementById('resetEditUser').addEventListener('click', () => {
    $('#users_edit_list').selectpicker('val', '');
    document.getElementById('e_first_name').value = '';
    document.getElementById('e_first_name').setAttribute('disabled', 'true');
    document.getElementById('e_last_name').value = '';
    document.getElementById('e_last_name').setAttribute('disabled', 'true');
    document.getElementById('e_email').value = '';
    document.getElementById('e_email').setAttribute('disabled', 'true');
    $('#e_role').selectpicker('val', '');
    document.getElementById('e_role').setAttribute('disabled', 'true');
    $('#e_role').selectpicker('refresh');
    document.getElementById('e_first_login').checked = false;
    document.getElementById('e_first_login').setAttribute('disabled', 'true');
    document.getElementById('e_is_locked').checked = false;
    document.getElementById('e_is_locked').setAttribute('disabled', 'true');

    const e_newAvatar = document.getElementById("e_new_avater");
    const e_defaultAvatar = document.getElementById("e_default_avater");
    const e_avatarImg = e_newAvatar.querySelector(".avatar-img");
    e_avatarImg.src = '';
    e_avatarImg.alt = '';
    e_newAvatar.classList.add("d-none"); // Show the image container
    e_defaultAvatar.classList.remove('d-none'); // Hide the SVG
    document.getElementById('e_delete_btn').setAttribute('disabled', 'true');
    document.getElementById('e_upload_btn').setAttribute('disabled', 'true');

    // Loop over each element and remove the 'has-error' class if it exists
    document.querySelectorAll('.form-group').forEach((formGroup) => {
        if (formGroup.classList.contains('has-error')) {
            formGroup.classList.remove('has-error');
        }
    });
    $('#e_role').selectpicker('setStyle', 'border-danger', 'remove');
    $('#e_role').selectpicker('setStyle', 'border-gray', 'add');
    document.getElementById('e_pp_delete_flag').value = '';
    document.getElementById('e_pp_input').value = '';
});

document.getElementById('submitDeleteUser').addEventListener('click', () => {
    var users_list = document.getElementById('users_list');
    var flag = true;
    // Get the selected options as an array of values
    const selectedValues = Array.from(users_list.selectedOptions).map(option => option.value);
    console.log(selectedValues);
    if (selectedValues.length == 0) {
        $.notify({
            icon: 'fas fa-trash',
            title: 'Validation Error',
            message: 'Please choose at least one user to delete.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (flag) {
        // Create FormData object
        const formData = new FormData();
        // Append values to FormData
        // formData.append('f_st_codes', selectedValues);
        selectedValues.forEach((id, index) => {
            formData.append('users_ids', id);
        });
        $.ajax({
            url: "/adminpanal/users/delete/api/",
            type: 'POST',
            dataType: "json",
            processData: false,  // Don't process the data
            contentType: false,  // Don't set content type
            data: formData,
            headers: {
                'X-CSRFToken': document.getElementById('csrfToken').value,
            },
            success: function (response) {
                // console.log(t);
                // if (response.status == 'delete_exists') {
                //     var spans = ``;
                //     if (response.ids) {
                //         response.ids.forEach((id) => {
                //             console.log(id);
                //             spans += `<span class="m-1 col-1">${id}</span>`; // Adding each code inside a span with margin
                //         });
                //     } else {
                //         spans = "No Exists IDs.";
                //     }
                //     swal("Thank you", "The selected products has been deleted successfully.", {
                //         icon: "success",
                //         buttons: {
                //             confirm: {
                //                 text: "cannot delete IDs!",
                //                 className: "btn btn-success-dark",
                //             },
                //             cancel: {
                //                 visible: true,
                //                 className: "btn btn-danger",
                //             },
                //         },
                //     }).then((exists) => {
                //         if (exists) {
                //             swal({
                //                 title: "Cannot Delete Product IDs!",
                //                 content: {
                //                     element: "div",
                //                     attributes: {
                //                         innerHTML: spans,
                //                         className: "row" // Insert the concatenated HTML string
                //                     },
                //                 },
                //                 icon: "error",
                //                 buttons: {
                //                     confirm: {
                //                         className: "btn btn-danger",
                //                     },
                //                 },
                //             });
                //         } else {
                //             swal.close();
                //         }
                //     });
                // }
                // if (response.status == 'exists') {
                //     swal("Sorry!", "Can't delete the selected products, already linked with Nozzles.", {
                //         icon: "error",
                //         buttons: false,
                //         timer: 3000
                //     });
                // }
                if (response.status == 'deleted') {
                    swal("Thank you", "The selected users has been deleted successfully.", {
                        icon: "success",
                        buttons: false,
                        timer: 3000
                    });
                }
                if (response.status == 'No_Post') {
                    swal("Sorry!", "You have to send a request.", {
                        icon: "error",
                        buttons: false,
                        timer: 3000
                    });
                }
                getAllUsers();
                document.getElementById('resetDeleteUser').click();
                document.getElementById("reset").click();
            },
        });
    }
});

document.getElementById('resetDeleteUser').addEventListener('click', () => {
    $('#users_list').selectpicker('val', '');
});