let pond;

document.addEventListener('DOMContentLoaded', () => {
    // Get a reference to the file input element
    const inputElement = document.querySelector('.my-pond');
    FilePond.registerPlugin(
        FilePondPluginFileEncode,
        FilePondPluginFileValidateSize,
    );

    // Create a FilePond instance
    pond = FilePond.create(inputElement, {
        acceptedFileTypes: ['.xls', '.xlsx'],
        // allowMultiple: true,
        instantUpload: false,
        maxFileSize: '5MB', // Set the maximum file size to 5 MB
        onaddfile: (error, fileItem) => {
            if (error) {
                console.log('FilePond error:', error);
                $.notify({
                    icon: 'fas fa-file-circle-plus',
                    title: 'Validation Error',
                    message: 'Please upload a valid excel file.',
                }, {
                    type: 'danger',
                    placement: {
                        from: "top",
                        align: "right"
                    },
                    time: 1000,
                });
            } else {
                console.log('File added:', fileItem.file);
                const file = fileItem.file;
                var reader = new FileReader();
                reader.onload = function (event) {
                    // var data = new Uint8Array(event.target.result);
                    // var workbook = XLSX.read(data, {type: 'array'});
                    // var firstSheetName = workbook.SheetNames[0];
                    // var worksheet = workbook.Sheets[firstSheetName];
                    // var html = XLSX.utils.sheet_to_html(worksheet);
                    // document.getElementById('excelViewer').innerHTML = html;
                    var data = new Uint8Array(event.target.result);
                    var workbook = XLSX.read(data, { type: 'array' });
                    var firstSheetName = workbook.SheetNames[0];
                    var worksheet = workbook.Sheets[firstSheetName];

                    // Generate HTML with custom class and direction
                    var html = XLSX.utils.sheet_to_html(worksheet, { id: "excelTable" });
                    html = html.replace('<table', '<table class="excel-table"'); // Add custom class and set direction

                    document.getElementById('excelViewer').innerHTML = html;
                };
                reader.readAsArrayBuffer(file);
            }
        },
        onremovefile: (error, fileItem) => {
            if (error) {
                console.log('FilePond error:', error);
                $.notify({
                    icon: 'fas fa-file-circle-plus',
                    title: 'Validation Error',
                    message: 'Sorry, Can not delete the excel file.',
                }, {
                    type: 'danger',
                    placement: {
                        from: "top",
                        align: "right"
                    },
                    time: 1000,
                });
            } else {
                console.log('File removed:', fileItem.file);
                // Clear the XML viewer when a file is removed
                document.getElementById('excelViewer').innerHTML = `<div class="row preview">
                    <div class="col-12 d-flex justify-content-center align-items-center">
                        <h3 class="text-white">Excel File Preview</h3>
                    </div>
                </div>`;
            }
        }
    });
});


function ResetFusion() {
    document.getElementById('excelViewer').innerHTML = `<div class="row preview">
        <div class="col-12 d-flex justify-content-center align-items-center">
            <h3 class="text-white">Excel File Preview</h3>
        </div>
    </div>`;
    pond.removeFiles();
}


document.getElementById('submitFusionFile').addEventListener('click', () => {
    var files = pond.getFiles();
    var file_flag = true;
    if (files.length <= 0) {
        $.notify({
            icon: 'fas fa-file-circle-plus',
            title: 'Validation Error',
            message: 'Please upload a valid fusions file.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        file_flag = false;
    }

    if (file_flag) {
        // Create FormData object
        const formData = new FormData();
        // Append files to FormData
        files.forEach((file, index) => {
            console.log(file.file);
            formData.append(`filepond`, file.file);
        });

        $.ajax({
            url: '/adminpanal/fusion/add/file/api/',
            type: 'POST',
            dataType: 'json', // Set the content type if sending JSON data
            data: formData, // Convert data to JSON string if sending JSON
            processData: false,  // Don't process the data
            contentType: false,  // Don't set content type
            headers: {
                'X-CSRFToken': document.getElementById('csrfToken').value,
            },
            success: function (response) {
                // Handle the successful response
                console.log(response);
                if (response.status == 'new_exists') {
                    var spans = ``;
                    if (response.codes) {
                        response.codes.forEach((code) => {
                            console.log(code);
                            spans += `<span class="m-1 col">${code}</span>`; // Adding each code inside a span with margin
                        });
                    } else {
                        spans = "No Exists Codes.";
                    }
                    swal("Thank you", "The fusion excel sheet's new data has been submitted successfully.", {
                        icon: "success",
                        buttons: {
                            confirm: {
                                text: "View exist codes!",
                                className: "btn btn-success-dark",
                            },
                            cancel: {
                                visible: true,
                                className: "btn btn-danger",
                            },
                        },
                    }).then((exists) => {
                        if (exists) {
                            swal({
                                title: "Existing Station Codes!",
                                content: {
                                    element: "div",
                                    attributes: {
                                        innerHTML: spans,
                                        className:"row" // Insert the concatenated HTML string
                                    },
                                },
                                icon: "error",
                                buttons: {
                                    confirm: {
                                        className: "btn btn-danger",
                                    },
                                },
                            });
                        } else {
                            swal.close();
                        }
                    });
                    ResetFusion();
                    document.getElementById('reset').click();
                    getAllFusions();
                }
                if (response.status == 'exists') {
                    swal("Sorry!", "The fusion excel sheet's all data already exists.", {
                        icon: "error",
                        buttons: false,
                        timer: 3000
                    });
                    ResetFusion();
                }
                if (response.status == 'added') {
                    swal("Thank you", "The fusion excel sheet has submitted successfully.", {
                        icon: "success",
                        buttons: false,
                        timer: 3000
                    });
                    ResetFusion();
                    document.getElementById('reset').click();
                    getAllFusions();
                }
                if (response.status == 'invalid_excel') {
                    swal("Sorry!", "The fusion excel sheet you have submitted was invalid.", {
                        icon: "error",
                        buttons: false,
                        timer: 3000
                    });
                    ResetFusion();
                }
                if (response.status == 'No_Post_Files') {
                    swal("Sorry!", "You can not sent a request without attaching an excel file.", {
                        icon: "error",
                        buttons: false,
                        timer: 3000
                    });
                    ResetFusion();
                }
                if (response.status == 'No_Post_Request') {
                    swal("Sorry!", "You have to send a request.", {
                        icon: "error",
                        buttons: false,
                        timer: 3000
                    });
                    ResetFusion();
                }
            }
        });
    }
});

document.getElementById('submitFusion').addEventListener('click', () => {
    var station_code = document.getElementById('station_code');
    var station_name = document.getElementById('station_name');
    var fusion_ip = document.getElementById('fusion_ip');
    var fusion_port = document.getElementById('fusion_port');
    var flag = true;

    if (station_code.value == '') {
        // product_num.classList.add('bg-danger', 'text-white');
        $.notify({
            icon: 'fas fa-hashtag',
            title: 'Validation Error',
            message: 'Please enter a valid station code.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (station_name.value == '') {
        // product_name.classList.add('bg-danger', 'text-white');
        $.notify({
            icon: 'fas fa-pen',
            title: 'Validation Error',
            message: 'Please enter a valid station name.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (fusion_ip.value == '') {
        // product_price.classList.add('bg-danger', 'text-white');
        $.notify({
            icon: 'fas fa-wifi',
            title: 'Validation Error',
            message: 'Please enter a valid fusion ip.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (fusion_port.value == '') {
        // product_price.classList.add('bg-danger', 'text-white');
        $.notify({
            icon: 'fas fa-ethernet',
            title: 'Validation Error',
            message: 'Please enter a valid fusion port.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }

    if (flag) {
        // Create FormData object
        const formData = new FormData();
        // Append values to FormData
        formData.append('station_code', station_code.value);
        formData.append('station_name', station_name.value);
        formData.append('fusion_ip', fusion_ip.value);
        formData.append('fusion_port', fusion_port.value);

        $.ajax({
            url: '/adminpanal/fusion/add/api/',
            type: 'POST',
            dataType: 'json', // Set the content type if sending JSON data
            data: formData, // Convert data to JSON string if sending JSON
            processData: false,  // Don't process the data
            contentType: false,  // Don't set content type
            headers: {
                'X-CSRFToken': document.getElementById('csrfToken').value,
            },
            success: function (response) {
                // Handle the successful response
                console.log(response);
                if (response.status == 'exists') {
                    // $.notify({
                    //     icon: 'fas fa-hdd',
                    //     title: 'Submittion Error',
                    //     message: 'Sorry, The station data already exists.',
                    // }, {
                    //     type: 'danger',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Submittion Error!", "Sorry, The station data already exists.", {
                        icon: "error",
                        buttons: false,
                        timer: 3000
                    });
                    document.getElementById('resetFusion').click();
                }
                if (response.status == 'missing_data') {
                    // $.notify({
                    //     icon: 'fas fa-hdd',
                    //     title: 'Submittion Error',
                    //     message: 'Sorry, missing request data.',
                    // }, {
                    //     type: 'danger',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Submittion Error!", "Sorry, missing request data.", {
                        icon: "error",
                        buttons: false,
                        timer: 3000
                    });
                    document.getElementById('resetFusion').click();
                }
                if (response.status == 'added') {
                    // $.notify({
                    //     icon: 'fas fa-hdd',
                    //     title: 'Submittion Successfully',
                    //     message: 'The fusion has been submitted successfully.',
                    // }, {
                    //     type: 'success',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Submittion Successfully", "The fusion has been submitted successfully.", {
                        icon: "success",
                        buttons: false,
                        timer: 3000
                    });
                    document.getElementById('resetFusion').click();
                    document.getElementById("reset").click();
                }
            }
        });
    }
});


document.getElementById('resetFusion').addEventListener('click', () => {
    document.getElementById('station_code').value = '';
    document.getElementById('station_name').value = '';
    document.getElementById('fusion_ip').value = '';
    document.getElementById('fusion_port').value = '';
});

//define column header menu as column visibility toggle
var headerMenu = function () {
    var menu = [];
    var columns = this.getColumns();

    for (let column of columns) {

        //create checkbox element using font awesome icons
        let icon = document.createElement("i");
        icon.classList.add("fas");
        icon.classList.add(column.isVisible() ? "fa-check-square" : "fa-square");

        //build label
        let label = document.createElement("span");
        let title = document.createElement("span");

        title.textContent = " " + column.getDefinition().title;

        label.appendChild(icon);
        label.appendChild(title);

        //create menu item
        menu.push({
            label: label,
            action: function (e) {
                //prevent menu closing
                e.stopPropagation();

                //toggle current column visibility
                column.toggle();

                //change menu item icon
                if (column.isVisible()) {
                    icon.classList.remove("fa-square");
                    icon.classList.add("fa-check-square");
                } else {
                    icon.classList.remove("fa-check-square");
                    icon.classList.add("fa-square");
                }
            }
        });
    }

    return menu;
};

//Define variables for input elements
var fieldSEl = document.getElementById("sort_field");
var dirEl = document.getElementById("sort_direction");

//Define variables for input elements
var fieldEl = document.getElementById("filter_field");
var typeEl = document.getElementById("filter_type");
var valueEl = document.getElementById("filter_value");


//Trigger setFilter function with correct parameters
function updateFilter() {
    var filterVal = fieldEl.options[fieldEl.selectedIndex].value;
    var typeVal = typeEl.options[typeEl.selectedIndex].value;

    var filter = filterVal;

    if (filterVal) {
        table.setFilter(filter, typeVal, valueEl.value);
    }
}

//Update filters on value change
document.getElementById("filter_field").addEventListener("change", updateFilter);
document.getElementById("filter_type").addEventListener("change", updateFilter);
document.getElementById("filter_value").addEventListener("keyup", updateFilter);

//Clear filters on "Clear Filters" button click
document.getElementById("filter_clear").addEventListener("click", function () {
    fieldEl.value = "";
    typeEl.value = "";
    valueEl.value = "";

    table.clearFilter();
});

// Define column configurations with headerMenu
function defaultColumns() {
    return [
        { title: "ID", field: "id", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
        { title: "Station Code", field: "station_code", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
        { title: "Station Name", field: "station_name", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
        { title: "Fusion IP", field: "ip", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
        { title: "Fusion Port", field: "port", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
        { title: "Timestamp", field: "timestamp", hozAlign: "start", sorter: "datetime", sorterParams:{
            format:"yyyy-MM-dd HH:mm:ss",
            alignEmptyValues:"top",
        }, headerMenu: headerMenu },
    ];
}

// Initial Table Configuration Function
function createTable() {
    return new Tabulator("#fusion_table", {
        layout: "fitColumns",          // Fit columns to the table width
        responsiveLayout: "hide",       // Hide columns that don’t fit
        height: window.innerHeight / 2,
        // maxHeight: window.innerHeight / 2,
        printAsHtml: true,
        printStyled: true,
        textDirection: "ltr",
        printHeader: `
        <div class="row mt-4 mb-4">F
            <div class="col-12 d-flex justify-content-center align-items-center">
                <h1>Fusions Table</h1>
            </div>
        </div>
        <hr>
        `,
        printFooter: `
        <div class="row mt-4">
            <div class="col-12 d-flex justify-content-center align-items-center">
                <img src='/static/img/gts-logo.png' alt='gts-logo' style="width: 50%;height: 100%;" />
            </div>
        </div>
        `,
        ajaxURL: "http://127.0.0.1:8000/adminpanal/fusion/view/api/",
        ajaxParams: { page: 1, size: 10 },
        progressiveLoad: "scroll",
        placeholder: "No Product Data",
        selectableRows: true,
        paginationSize: 10,
        columnDefaults: {
            tooltip: true,
        },
        langs: {
            "ar-eg": {
                "columns": {
                    "id": "مسلسل",
                    "station_code": "كود المحطة",
                    "station_name": "اسم المحطة",
                    "ip": "العنوان",
                    "port": "المنفذ",
                    "timestamp": "تاريخ الانشاء",
                },
            }
        },
        columns: defaultColumns(),
    });
}

var table = createTable();

// var table = new Tabulator("#product_table", {
//     layout: "fitColumns",          // Fit columns to the table width
//     responsiveLayout: "hide",       // Hide columns that don’t fit
//     height: window.innerHeight / 2,
//     printAsHtml: true,
//     printStyled: true,
//     // autoColumns:true,
//     // printRowRange: "all",
//     // textDirection: "rtl",
//     printHeader: `
//     <div class="row mt-4 mb-4">
//         <div class="col-12 d-flex justify-content-center align-items-center">
//             <h1>Products Table</h1>
//         </div>
//     </div>
//     <hr>
//     `,
//     printFooter: `
//     <div class="row mt-4">
//         <div class="col-12 d-flex justify-content-center align-items-center">
//             <img src='/static/img/gts-logo.png' alt='gts-logo' style="width: 50%;height: 100%;" />
//         </div>
//     </div>
//     `,
//     // clipboard: true,
//     // clipboardPasteAction: "replace",
//     // resizableRows: true,
//     // resizableRowGuide: true,
//     // resizableColumnGuide: true,
//     // movableColumns: true,
//     ajaxURL: "http://127.0.0.1:8000/adminpanal/product/view/api/",
//     ajaxParams: { page: 1, size: 10 },  // Start with page 1 and size 3
//     progressiveLoad: "scroll",      // Enable progressive loading with scroll
//     placeholder: "No Product Data",
//     selectableRows: true, //make rows selectable
//     // addRowPos: "top",
//     // history: true,
//     paginationSize: 10,
//     columnDefaults: {
//         tooltip: true,
//     },
//     langs: {
//         "ar-eg": { //French language definition
//             "columns": {
//                 "id": "مسلسل",
//                 "number": "الرقم",
//                 "name": "الاسم",
//                 "price": "السعر",
//                 "timestamp": "تاريخ الانشاء",
//             },
//         }
//     },
//     columns: [
//         { title: "ID", field: "id", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
//         { title: "Number", field: "number", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
//         { title: "Name", field: "name", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
//         { title: "Price", field: "price", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
//         { title: "Timestamp", field: "timestamp", hozAlign: "start", sorter: "datetime", headerMenu: headerMenu },
//     ],
// });

//Trigger sort when "Trigger Sort" button is clicked
document.getElementById("sort_trigger").addEventListener("click", function () {
    table.setSort(fieldSEl.options[fieldSEl.selectedIndex].value, dirEl.options[dirEl.selectedIndex].value);
});

document.getElementById("sort_reset").addEventListener("click", function () {
    table.setSort("id", "asc");
});

table.on("rowSelectionChanged", function (data, rows) {
    document.getElementById("select_stats").innerHTML = data.length;
});

//select row on "select all" button click
document.getElementById("select_all").addEventListener("click", function () {
    table.selectRow();
});

//deselect row on "deselect all" button click
document.getElementById("deselect_all").addEventListener("click", function () {
    table.deselectRow();
});

//Delete row on "Delete Row" button click
document.getElementById("del_row").addEventListener("click", function () {
    var rowid = document.getElementById('row_delete');
    if (rowid.value == '') {
        $.notify({
            icon: 'fas fa-trash',
            title: 'Validation Error',
            message: 'Please enter a valid row number.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
    } else {
        table.deleteRow(parseInt(rowid.value));
        rowid.value = '';
    }
});

//Clear table on "Empty the table" button click
document.getElementById("clear").addEventListener("click", function () {
    table.clearData()
});

//Reset table contents on "Reset the table" button click
document.getElementById("reset").addEventListener("click", function () {
    // table.setData("http://127.0.0.1:8000/adminpanal/product/view/api/", { page: 1, size: 10 });
    // Destroy current instance of the table
    table.destroy();
    // Recreate table with initial settings
    table = createTable();
});

document.getElementById('download_btn').addEventListener('click', () => {
    var file_name = document.getElementById('file_name');
    var download_type = document.getElementById('download_type');
    var flag = true;
    if (file_name.value == '') {
        $.notify({
            icon: 'fas fa-font',
            title: 'Validation Error',
            message: 'Please enter a valid file name.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (download_type.value == '') {
        $.notify({
            icon: 'fas fa-gear',
            title: 'Validation Error',
            message: 'Please choose a download type.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }

    if (flag) {
        if (download_type.value == 'csv') table.download("csv", `${file_name.value}.csv`);
        if (download_type.value == 'json') table.download("json", `${file_name.value}.json`);
        if (download_type.value == 'xlsx') table.download("xlsx", `${file_name.value}.xlsx`, { sheetName: file_name.value });
        if (download_type.value == 'pdf') {
            table.download("pdf", `${file_name.value}.pdf`, {
                orientation: "portrait", //set page orientation to portrait
                title: "Fusions Data", //add title to report
            });
        }
        if (download_type.value == 'html') table.download("html", `${file_name.value}.html`, { style: true });
    }
});

//print button
document.getElementById("print_table").addEventListener("click", function () {
    // Get the selected print range from the dropdown
    var selectedRange = document.getElementById("print_range").value;
    console.log(selectedRange);
    // Update printRowRange on the table instance
    table.options.printRowRange = selectedRange;
    // Print the table using the selected printRowRange
    table.print(false, true);
});


//set locale to French
document.getElementById("lang_arabic").addEventListener("click", function () {
    table.setLocale("ar-eg");
    table.setColumns(defaultColumns());  // Reload columns to apply headerMenu
    // document.getElementById("product_table").setAttribute("dir", "rtl");
});

//set default locale
document.getElementById("lang_default").addEventListener("click", function () {
    table.setLocale("");
    table.setColumns(defaultColumns());  // Reload columns to apply headerMenu
    // document.getElementById("product_table").setAttribute("dir", "ltr");
});

function getAllFusions() {
    $.ajax({
        url: "/adminpanal/fusion/all/api/",
        method: "GET",
        dataType: "json",
        data: {},
        success: function (t) {
            // console.log(t);
            const select = document.getElementById("fusion_list");
            const editSelect = document.getElementById("fusion_edit_list");

            // Clear any existing options (optional)
            select.innerHTML = '';
            editSelect.innerHTML = '<option value="" selected disabled>Choose fusion...</option>';

            // Add new options
            t.forEach(fusion => {
                const option1 = document.createElement("option");
                option1.value = fusion.station_code;
                option1.textContent = `${fusion.station_code} - ${fusion.station_name}`;
                option1.setAttribute("data-subtext", `${fusion.ip} : ${fusion.port}`);
                select.appendChild(option1);

                const option2 = document.createElement("option");
                option2.value = fusion.id;
                option2.textContent = `${fusion.station_code} - ${fusion.station_name}`;
                option2.setAttribute("data-subtext", `${fusion.ip} : ${fusion.port}`);
                editSelect.appendChild(option2);
            });

            // Refresh selectpicker to apply changes
            $('.selectpicker').selectpicker('refresh');
        },
    });
}

$(function () {
    getAllFusions();
});


document.getElementById('fusion_edit_list').addEventListener('change', (event)=>{
    console.log(event.target.value);
    $.ajax({
        url: "/adminpanal/fusion/single/api/",
        method: "GET",
        dataType: "json",
        data: {
            'fusion_id': event.target.value,
        },
        success: function (t) {
            console.log(t);
            document.getElementById('e_station_code').value = t.station_code;
            document.getElementById('e_station_code').removeAttribute('readonly');
            document.getElementById('e_station_name').value = t.station_name;
            document.getElementById('e_station_name').removeAttribute('readonly');
            document.getElementById('e_fusion_ip').value = t.ip;
            document.getElementById('e_fusion_ip').removeAttribute('readonly');
            document.getElementById('e_fusion_port').value = t.port;
            document.getElementById('e_fusion_port').removeAttribute('readonly');
        },
    });
});

document.getElementById('submitEditFusion').addEventListener('click', () => {
    var fusion_edit_list = document.getElementById('fusion_edit_list');
    var e_station_code = document.getElementById('e_station_code');
    var e_station_name = document.getElementById('e_station_name');
    var e_fusion_ip = document.getElementById('e_fusion_ip');
    var e_fusion_port = document.getElementById('e_fusion_port');
    var flag = true;
    console.log(fusion_edit_list.value);
    if (fusion_edit_list.value == "") {
        $.notify({
            icon: 'fas fa-trash',
            title: 'Validation Error',
            message: 'Please choose a fusion to edit.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (e_station_code.value == "") {
        $.notify({
            icon: 'fas fa-trash',
            title: 'Validation Error',
            message: 'Please enter a valid station code.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (e_station_name.value == "") {
        $.notify({
            icon: 'fas fa-trash',
            title: 'Validation Error',
            message: 'Please enter a valid station name.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (e_fusion_ip.value == "") {
        $.notify({
            icon: 'fas fa-trash',
            title: 'Validation Error',
            message: 'Please enter a valid fusion ip.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (e_fusion_port.value == "") {
        $.notify({
            icon: 'fas fa-trash',
            title: 'Validation Error',
            message: 'Please enter a valid fusion port.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (flag) {
        // Create FormData object
        const formData = new FormData();
        // Append values to FormData
        formData.append('fusion_id', fusion_edit_list.value);
        formData.append('station_code', e_station_code.value);
        formData.append('station_name', e_station_name.value);
        formData.append('ip', e_fusion_ip.value);
        formData.append('port', e_fusion_port.value);
        $.ajax({
            url: "/adminpanal/fusion/edit/api/",
            type: 'POST',
            dataType: "json",
            processData: false,  // Don't process the data
            contentType: false,  // Don't set content type
            data: formData,
            headers: {
                'X-CSRFToken': document.getElementById('csrfToken').value,
            },
            success: function (response) {
                // console.log(t);
                if (response.status == 'exists') {
                    swal("Sorry!", "Can't edit a fusion with already existing values.", {
                        icon: "error",
                        buttons: false,
                        timer: 3000
                    });
                }
                if (response.status == 'error') {
                    swal("Sorry!", "Can't edit the selected fusion.", {
                        icon: "error",
                        buttons: false,
                        timer: 3000
                    });
                }
                if (response.status == 'updated') {
                    swal("Thank you", "The selected fusion has been updated successfully.", {
                        icon: "success",
                        buttons: false,
                        timer: 3000
                    });
                }
                if (response.status == 'No_Post') {
                    swal("Sorry!", "You have to send a request.", {
                        icon: "error",
                        buttons: false,
                        timer: 3000
                    });
                }
                getAllFusions();
                document.getElementById('resetEditFusion').click();
                document.getElementById("reset").click();
            },
        });
    }
});

document.getElementById('resetEditFusion').addEventListener('click', () => {
    $('#fusion_edit_list').selectpicker('val', '');
    document.getElementById('e_station_code').value = "";
    document.getElementById('e_station_code').setAttribute('readonly', 'true');
    document.getElementById('e_station_name').value = "";
    document.getElementById('e_station_name').setAttribute('readonly', 'true');
    document.getElementById('e_fusion_ip').value = "";
    document.getElementById('e_fusion_ip').setAttribute('readonly', 'true');
    document.getElementById('e_fusion_port').value = "";
    document.getElementById('e_fusion_port').setAttribute('readonly', 'true');
});


document.getElementById('submitDeleteFusion').addEventListener('click', () => {
    var fusion_select = document.getElementById('fusion_list');
    var flag = true;
    // Get the selected options as an array of values
    const selectedValues = Array.from(fusion_select.selectedOptions).map(option => option.value);
    console.log(selectedValues);
    if (selectedValues.length == 0) {
        $.notify({
            icon: 'fas fa-trash',
            title: 'Validation Error',
            message: 'Please choose at least a fusion to delete.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (flag) {
        // Create FormData object
        const formData = new FormData();
        // Append values to FormData
        // formData.append('f_st_codes', selectedValues);
        selectedValues.forEach((code, index) => {
            formData.append('f_st_codes', code);
        });
        $.ajax({
            url: "/adminpanal/fusion/delete/api/",
            type: 'POST',
            dataType: "json",
            processData: false,  // Don't process the data
            contentType: false,  // Don't set content type
            data: formData,
            headers: {
                'X-CSRFToken': document.getElementById('csrfToken').value,
            },
            success: function (response) {
                if (response.status == 'delete_exists') {
                    var spans = ``;
                    if (response.codes) {
                        response.codes.forEach((code) => {
                            console.log(code);
                            spans += `<span class="m-1 col-1">${code}</span>`; // Adding each code inside a span with margin
                        });
                    } else {
                        spans = "No Exists Codes.";
                    }
                    swal("Thank you", "The selected fusions has been deleted successfully.", {
                        icon: "success",
                        buttons: {
                            confirm: {
                                text: "cannot delete codes!",
                                className: "btn btn-success-dark",
                            },
                            cancel: {
                                visible: true,
                                className: "btn btn-danger",
                            },
                        },
                    }).then((exists) => {
                        if (exists) {
                            swal({
                                title: "Cannot Delete Station Codes!",
                                content: {
                                    element: "div",
                                    attributes: {
                                        innerHTML: spans,
                                        className:"row" // Insert the concatenated HTML string
                                    },
                                },
                                icon: "error",
                                buttons: {
                                    confirm: {
                                        className: "btn btn-danger",
                                    },
                                },
                            });
                        } else {
                            swal.close();
                        }
                    });
                }
                if (response.status == 'exists') {
                    swal("Sorry!", "Can't delete the selected fusions, already linked with stations.", {
                        icon: "error",
                        buttons: false,
                        timer: 3000
                    });
                }
                if (response.status == 'deleted') {
                    swal("Thank you", "The selected fusions has been deleted successfully.", {
                        icon: "success",
                        buttons: false,
                        timer: 3000
                    });
                }
                if (response.status == 'No_Post') {
                    swal("Sorry!", "You have to send a request.", {
                        icon: "error",
                        buttons: false,
                        timer: 3000
                    });
                }
                getAllFusions();
                $('#fusion_list').selectpicker('val', '');
                document.getElementById("reset").click();
            },
        });
    }
});

document.getElementById('resetDeleteFusion').addEventListener('click', () => {
    $('#fusion_list').selectpicker('val', '');
});