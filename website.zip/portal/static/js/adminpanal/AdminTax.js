document.getElementById('submitTax').addEventListener('click', () => {
    var groups_list = document.getElementById('groups_list');
    var rin = document.getElementById('rin');
    var companyTradeName = document.getElementById('companyTradeName');
    var branchCode = document.getElementById('branchCode');
    var branchAddress_country = document.getElementById('branchAddress_country');
    var branchAddress_governate = document.getElementById('branchAddress_governate');
    var branchAddress_regionCity = document.getElementById('branchAddress_regionCity');
    var branchAddress_street = document.getElementById('branchAddress_street');
    var branchAddress_buildingNumber = document.getElementById('branchAddress_buildingNumber');
    var deviceSerialNumber = document.getElementById('deviceSerialNumber');
    var syndicateLicenseNumber = document.getElementById('syndicateLicenseNumber');
    var activityCode = document.getElementById('activityCode');
    var flag = true;

    if (groups_list.value == '') {
        let parentFormGroup = $('#groups_list').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $('#groups_list').selectpicker('setStyle', 'border-danger', 'add');
        $.notify({
            icon: 'fas fa-people-group',
            title: 'Submission Error!',
            message: 'Please choose a valid group.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        let parentFormGroup = $('#groups_list').closest('.form-group');
        parentFormGroup.removeClass('has-error');
        $('#groups_list').selectpicker('setStyle', 'border-danger', 'remove');
        $('#groups_list').selectpicker('setStyle', 'border-gray', 'add');
    }
    if (rin.value == '') {
        let parentFormGroup = $('#rin').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $.notify({
            icon: 'fas fa-id-card',
            title: 'Submission Error!',
            message: 'Please enter a valid rin.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        let parentFormGroup = $('#rin').closest('.form-group');
        parentFormGroup.removeClass('has-error');
    }
    if (companyTradeName.value == '') {
        let parentFormGroup = $('#companyTradeName').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $.notify({
            icon: 'fas fa-id-card',
            title: 'Submission Error!',
            message: 'Please enter a valid company name.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        let parentFormGroup = $('#companyTradeName').closest('.form-group');
        parentFormGroup.removeClass('has-error');
    }
    if (branchCode.value == '') {
        let parentFormGroup = $('#branchCode').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $.notify({
            icon: 'fas fa-hashtag',
            title: 'Submission Error!',
            message: 'Please enter a valid branch code.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        let parentFormGroup = $('#branchCode').closest('.form-group');
        parentFormGroup.removeClass('has-error');
    }
    if (branchAddress_country.value == '') {
        let parentFormGroup = $('#branchAddress_country').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $.notify({
            icon: 'fas fa-hashtag',
            title: 'Submission Error!',
            message: 'Please enter a valid country.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        let parentFormGroup = $('#branchAddress_country').closest('.form-group');
        parentFormGroup.removeClass('has-error');
    }
    if (branchAddress_governate.value == '') {
        let parentFormGroup = $('#branchAddress_governate').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $.notify({
            icon: 'fas fa-location-dot',
            title: 'Submission Error!',
            message: 'Please enter a valid governorate.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        let parentFormGroup = $('#branchAddress_governate').closest('.form-group');
        parentFormGroup.removeClass('has-error');
    }
    if (branchAddress_regionCity.value == '') {
        let parentFormGroup = $('#branchAddress_regionCity').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $.notify({
            icon: 'fas fa-location-dot',
            title: 'Submission Error!',
            message: 'Please enter a valid region city.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        let parentFormGroup = $('#branchAddress_regionCity').closest('.form-group');
        parentFormGroup.removeClass('has-error');
    }
    if (branchAddress_street.value == '') {
        let parentFormGroup = $('#branchAddress_street').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $.notify({
            icon: 'fas fa-location-dot',
            title: 'Submission Error!',
            message: 'Please enter a valid street.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        let parentFormGroup = $('#branchAddress_street').closest('.form-group');
        parentFormGroup.removeClass('has-error');
    }
    if (branchAddress_buildingNumber.value == '') {
        let parentFormGroup = $('#branchAddress_buildingNumber').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $.notify({
            icon: 'fas fa-building',
            title: 'Submission Error!',
            message: 'Please enter a valid building number.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        let parentFormGroup = $('#branchAddress_buildingNumber').closest('.form-group');
        parentFormGroup.removeClass('has-error');
    }
    if (deviceSerialNumber.value == '') {
        let parentFormGroup = $('#deviceSerialNumber').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $.notify({
            icon: 'fas fa-barcode',
            title: 'Submission Error!',
            message: 'Please enter a valid serial number.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        let parentFormGroup = $('#deviceSerialNumber').closest('.form-group');
        parentFormGroup.removeClass('has-error');
    }
    if (activityCode.value == '') {
        let parentFormGroup = $('#activityCode').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $.notify({
            icon: 'fas fa-hashtag',
            title: 'Submission Error!',
            message: 'Please enter a valid activity code.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        let parentFormGroup = $('#activityCode').closest('.form-group');
        parentFormGroup.removeClass('has-error');
    }

    if (flag) {
        // Create FormData object
        const formData = new FormData();
        // Append values to FormData
        formData.append('groups_list', groups_list.value);
        formData.append('rin', rin.value);
        formData.append('companyTradeName', companyTradeName.value);
        formData.append('branchCode', branchCode.value);
        formData.append('branchAddress_country', branchAddress_country.value);
        formData.append('branchAddress_governate', branchAddress_governate.value);
        formData.append('branchAddress_regionCity', branchAddress_regionCity.value);
        formData.append('branchAddress_street', branchAddress_street.value);
        formData.append('branchAddress_buildingNumber', branchAddress_buildingNumber.value);
        formData.append('deviceSerialNumber', deviceSerialNumber.value);
        formData.append('syndicateLicenseNumber', syndicateLicenseNumber.value);
        formData.append('activityCode', activityCode.value);
        
        $.ajax({
            url: "/adminpanal/tax/add/api/",
            type: 'POST',
            dataType: "json",
            processData: false,  // Don't process the data
            contentType: false,  // Don't set content type
            data: formData,
            headers: {
                'X-CSRFToken': document.getElementById('csrfToken').value,
            },
            success: function (t) {
                // console.log(t);
                if (t.status == 'No Post') {
                    swal("Technical Error!", "You have to contact with your administrator.", {
                        icon: "error",
                        buttons: false,
                        timer: 2000
                    });
                }
                if (t.status == 'exists') {
                    swal("Submission Error!", "The pos has been submitted already.", {
                        icon: "error",
                        buttons: false,
                        timer: 2000
                    });
                }
                if (t.status == 'added') {
                    swal("Thank you", "The Seller has been submitted successfully.", {
                        icon: "success",
                        buttons: false,
                        timer: 2000
                    });
                    document.getElementById('resetTax').click();
                    document.getElementById("reset").click();
                }
            },
        });
    }
});


document.getElementById('resetTax').addEventListener('click', () => {
    $('#groups_list').selectpicker('val', '');
    $('#groups_list').selectpicker('refresh');
    document.getElementById('rin').value = '';
    document.getElementById('companyTradeName').value = '';
    document.getElementById('branchCode').value = '';
    document.getElementById('branchAddress_country').value = '';
    document.getElementById('branchAddress_governate').value = '';
    document.getElementById('branchAddress_regionCity').value = '';
    document.getElementById('branchAddress_street').value = '';
    document.getElementById('branchAddress_buildingNumber').value = '';
    document.getElementById('deviceSerialNumber').value = '';
    document.getElementById('syndicateLicenseNumber').value = '';
    document.getElementById('activityCode').value = '';

    $('#groups_list').closest('.form-group').removeClass('has-error');
    $('#groups_list').selectpicker('setStyle', 'border-danger', 'remove');
    $('#groups_list').selectpicker('setStyle', 'border-gray', 'add');
    $('#rin').closest('.form-group').removeClass('has-error');
    $('#companyTradeName').closest('.form-group').removeClass('has-error');
    $('#branchCode').closest('.form-group').removeClass('has-error');
    $('#branchAddress_country').closest('.form-group').removeClass('has-error');
    $('#branchAddress_governate').closest('.form-group').removeClass('has-error');
    $('#branchAddress_regionCity').closest('.form-group').removeClass('has-error');
    $('#branchAddress_street').closest('.form-group').removeClass('has-error');
    $('#branchAddress_buildingNumber').closest('.form-group').removeClass('has-error');
    $('#deviceSerialNumber').closest('.form-group').removeClass('has-error');
    $('#syndicateLicenseNumber').closest('.form-group').removeClass('has-error');
    $('#activityCode').closest('.form-group').removeClass('has-error');
});

//define column header menu as column visibility toggle
var headerMenu = function () {
    var menu = [];
    var columns = this.getColumns();

    for (let column of columns) {

        //create checkbox element using font awesome icons
        let icon = document.createElement("i");
        icon.classList.add("fas");
        icon.classList.add(column.isVisible() ? "fa-check-square" : "fa-square");

        //build label
        let label = document.createElement("span");
        let title = document.createElement("span");

        title.textContent = " " + column.getDefinition().title;

        label.appendChild(icon);
        label.appendChild(title);

        //create menu item
        menu.push({
            label: label,
            action: function (e) {
                //prevent menu closing
                e.stopPropagation();

                //toggle current column visibility
                column.toggle();

                //change menu item icon
                if (column.isVisible()) {
                    icon.classList.remove("fa-square");
                    icon.classList.add("fa-check-square");
                } else {
                    icon.classList.remove("fa-check-square");
                    icon.classList.add("fa-square");
                }
            }
        });
    }

    return menu;
};

//Define variables for input elements
var fieldSEl = document.getElementById("sort_field");
var dirEl = document.getElementById("sort_direction");

//Define variables for input elements
var fieldEl = document.getElementById("filter_field");
var typeEl = document.getElementById("filter_type");
var valueEl = document.getElementById("filter_value");


//Trigger setFilter function with correct parameters
function updateFilter() {
    var filterVal = fieldEl.options[fieldEl.selectedIndex].value;
    var typeVal = typeEl.options[typeEl.selectedIndex].value;

    var filter = filterVal;

    if (filterVal) {
        table.setFilter(filter, typeVal, valueEl.value);
    }
}

//Update filters on value change
document.getElementById("filter_field").addEventListener("change", updateFilter);
document.getElementById("filter_type").addEventListener("change", updateFilter);
document.getElementById("filter_value").addEventListener("keyup", updateFilter);

//Clear filters on "Clear Filters" button click
document.getElementById("filter_clear").addEventListener("click", function () {
    fieldEl.value = "";
    typeEl.value = "";
    valueEl.value = "";

    table.clearFilter();
});

// Define column configurations with headerMenu
function defaultColumns() {
    return [
        { title: "ID", field: "id", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
        { title: "Group", field: "group", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
        { title: "RIN", field: "rin", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
        { title: "Company", field: "companyTradeName", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
        { title: "Branch Code", field: "branchCode", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
        { title: "Country", field: "branchAddress_country", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
        { title: "Governorate", field: "branchAddress_governate", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
        { title: "Region City", field: "branchAddress_regionCity", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
        { title: "Street", field: "branchAddress_street", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
        { title: "Building Number", field: "branchAddress_buildingNumber", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
        { title: "Device Serial Number", field: "deviceSerialNumber", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
        { title: "Syndicate License Number", field: "syndicateLicenseNumber", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
        { title: "Activity Code", field: "activityCode", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
        {
            title: "Creation Date", field: "timestamp", hozAlign: "start", sorter: "datetime", sorterParams: {
                format: "yyyy-MM-dd HH:mm:ss",
                alignEmptyValues: "top",
            }, headerMenu: headerMenu
        },
    ];
}


// Initial Table Configuration Function
function createTable() {
    return new Tabulator("#tax_table", {
        layout: "fitColumns",          // Fit columns to the table width
        responsiveLayout: "hide",       // Hide columns that don’t fit
        height: window.innerHeight / 2,
        printAsHtml: true,
        printStyled: true,
        textDirection: "ltr",
        // groupBy: ["station_name", "status"],
        // groupStartOpen: true,
        // groupToggleElement: "header",
        // groupHeaderPrint: function(value, count, data, group){
        //     return value;
        // },
        // groupHeaderDownload: function(value, count, data, group){
        //     return value;
        // },
        // downloadRowRange: "all",
        printHeader: `
        <div class="row mt-4 mb-4">
            <div class="col-12 d-flex justify-content-center align-items-center">
                <h1>Tax Table</h1>
            </div>
        </div>
        <hr>`,
        printFooter: `
        <div class="row mt-4">
            <div class="col-12 d-flex justify-content-center align-items-center">
                <img src='/static/img/gts-logo.png' alt='gts-logo' style="width: 50%;height: 100%;" />
            </div>
        </div>
        `,
        ajaxURL: "http://127.0.0.1:8000/adminpanal/tax/view/api/",
        ajaxParams: { page: 1, size: 10 },
        progressiveLoad: "scroll",
        placeholder: "No Tax Data",
        // selectableRows: true,
        paginationSize: 10,
        columnDefaults: {
            tooltip: true,
        },
        langs: {
            "ar-eg": {
                "columns": {
                    "id": "مسلسل",
                    "group": "مجموعة",
                    "rin": "الرقم التعريفي",
                    "companyTradeName": "اسم الشركة",
                    "branchCode": "رمز الفرع",
                    "branchAddress_country": "البلد",
                    "branchAddress_governate": "المحافظة",
                    "branchAddress_regionCity": "المدينة",
                    "branchAddress_street": "الشارع",
                    "branchAddress_buildingNumber": "رقم المبنى",
                    "deviceSerialNumber": "الرقم التسلسلي للجهاز",
                    "syndicateLicenseNumber": "رقم الترخيص النقابي",
                    "activityCode": "رمز النشاط",
                    "timestamp": "تاريخ الإنشاء",
                },
            }
        },
        columns: defaultColumns(),
    });
}

var table = createTable();

// var table = new Tabulator("#pos_table", {
//     layout: "fitColumns",          // Fit columns to the table width
//     responsiveLayout: "hide",       // Hide columns that don’t fit
//     height: window.innerHeight / 2,
//     printAsHtml: true,
//     printStyled: true,
//     // autoColumns:true,
//     // printRowRange: "all",
//     // textDirection: "rtl",
//     printHeader: `
//     <div class="row mt-4 mb-4">
//         <div class="col-12 d-flex justify-content-center align-items-center">
//             <h1>Products Table</h1>
//         </div>
//     </div>
//     <hr>
//     `,
//     printFooter: `
//     <div class="row mt-4">
//         <div class="col-12 d-flex justify-content-center align-items-center">
//             <img src='/static/img/gts-logo.png' alt='gts-logo' style="width: 50%;height: 100%;" />
//         </div>
//     </div>
//     `,
//     // clipboard: true,
//     // clipboardPasteAction: "replace",
//     // resizableRows: true,
//     // resizableRowGuide: true,
//     // resizableColumnGuide: true,
//     // movableColumns: true,
//     ajaxURL: "http://127.0.0.1:8000/adminpanal/product/view/api/",
//     ajaxParams: { page: 1, size: 10 },  // Start with page 1 and size 3
//     progressiveLoad: "scroll",      // Enable progressive loading with scroll
//     placeholder: "No Product Data",
//     selectableRows: true, //make rows selectable
//     // addRowPos: "top",
//     // history: true,
//     paginationSize: 10,
//     columnDefaults: {
//         tooltip: true,
//     },
//     langs: {
//         "ar-eg": { //French language definition
//             "columns": {
//                 "id": "مسلسل",
//                 "number": "الرقم",
//                 "name": "الاسم",
//                 "price": "السعر",
//                 "timestamp": "تاريخ الانشاء",
//             },
//         }
//     },
//     columns: [
//         { title: "ID", field: "id", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
//         { title: "Number", field: "number", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
//         { title: "Name", field: "name", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
//         { title: "Price", field: "price", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
//         { title: "Timestamp", field: "timestamp", hozAlign: "start", sorter: "datetime", headerMenu: headerMenu },
//     ],
// });

//Trigger sort when "Trigger Sort" button is clicked
document.getElementById("sort_trigger").addEventListener("click", function () {
    table.setSort(fieldSEl.options[fieldSEl.selectedIndex].value, dirEl.options[dirEl.selectedIndex].value);
});

document.getElementById("sort_reset").addEventListener("click", function () {
    table.setSort("id", "asc");
});

table.on("rowSelectionChanged", function (data, rows) {
    document.getElementById("select_stats").innerHTML = data.length;
});

//select row on "select all" button click
document.getElementById("select_all").addEventListener("click", function () {
    table.selectRow();
});

//deselect row on "deselect all" button click
document.getElementById("deselect_all").addEventListener("click", function () {
    table.deselectRow();
});

//Delete row on "Delete Row" button click
document.getElementById("del_row").addEventListener("click", function () {
    var rowid = document.getElementById('row_delete');
    if (rowid.value == '') {
        $.notify({
            icon: 'fas fa-trash',
            title: 'Validation Error',
            message: 'Please enter a valid row number.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
    } else {
        table.deleteRow(parseInt(rowid.value));
        rowid.value = '';
    }
});

//Clear table on "Empty the table" button click
document.getElementById("clear").addEventListener("click", function () {
    table.clearData()
});

//Reset table contents on "Reset the table" button click
document.getElementById("reset").addEventListener("click", function () {
    // table.setData("http://127.0.0.1:8000/adminpanal/product/view/api/", { page: 1, size: 10 });
    // Destroy current instance of the table
    table.destroy();
    // Recreate table with initial settings
    table = createTable();
});

document.getElementById('download_btn').addEventListener('click', () => {
    var file_name = document.getElementById('file_name');
    var download_type = document.getElementById('download_type');
    var flag = true;
    if (file_name.value == '') {
        $.notify({
            icon: 'fas fa-font',
            title: 'Validation Error',
            message: 'Please enter a valid file name.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (download_type.value == '') {
        $.notify({
            icon: 'fas fa-gear',
            title: 'Validation Error',
            message: 'Please choose a download type.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }

    if (flag) {
        if (download_type.value == 'csv') table.download("csv", `${file_name.value}.csv`);
        if (download_type.value == 'json') table.download("json", `${file_name.value}.json`);
        if (download_type.value == 'xlsx') table.download("xlsx", `${file_name.value}.xlsx`, { sheetName: file_name.value });
        if (download_type.value == 'pdf') {
            table.download("pdf", `${file_name.value}.pdf`, {
                orientation: "portrait", //set page orientation to portrait
                title: "Tax Data", //add title to report
            });
        }
        if (download_type.value == 'html') table.download("html", `${file_name.value}.html`, { style: true });
    }
});

//print button
document.getElementById("print_table").addEventListener("click", function () {
    // Get the selected print range from the dropdown
    var selectedRange = document.getElementById("print_range").value;
    console.log(selectedRange);
    // Update printRowRange on the table instance
    table.options.printRowRange = selectedRange;
    // Print the table using the selected printRowRange
    table.print(false, true);
});


//set locale to French
document.getElementById("lang_arabic").addEventListener("click", function () {
    table.setLocale("ar-eg");
    table.setColumns(defaultColumns());  // Reload columns to apply headerMenu
    // document.getElementById("pos_table").setAttribute("dir", "rtl");
});

//set default locale
document.getElementById("lang_default").addEventListener("click", function () {
    table.setLocale("");
    table.setColumns(defaultColumns());  // Reload columns to apply headerMenu
    // document.getElementById("pos_table").setAttribute("dir", "ltr");
});


function getAllGroups() {
    $.ajax({
        url: "/adminpanal/tax/groups/all/api/",
        method: "GET",
        dataType: "json",
        data: {},
        success: function (t) {
            console.log(t);
            const select = document.getElementById("groups_list");
            const editSelect = document.getElementById("e_groups_list");
            // const deleteSelect = document.getElementById("d_groups_list");

            // Clear any existing options (optional)
            select.innerHTML = '<option value="" selected disabled>Choose group...</option>';
            editSelect.innerHTML = '<option value="" selected disabled>Choose group...</option>';
            // deleteSelect.innerHTML = '<option value="" selected disabled>Choose group...</option>';

            // Add new options
            t.forEach(group => {
                const option1 = document.createElement("option");
                option1.value = group.id;
                option1.textContent = group.name;
                select.appendChild(option1);

                const option2 = document.createElement("option");
                option2.value = group.id;
                option2.textContent = group.name;
                editSelect.appendChild(option2);

                // const option3 = document.createElement("option");
                // option3.value = station.id;
                // option3.textContent = `${station.station_code} - ${station.station_name}`;
                // deleteSelect.appendChild(option3);
            });

            // Refresh selectpicker to apply changes
            $('#groups_list').selectpicker('refresh');
            $('#e_groups_list').selectpicker('refresh');
            // $('#d_stations_list').selectpicker('refresh');
        },
    });
}

function getAllSellers() {
    $.ajax({
        url: "/adminpanal/tax/sellers/all/api/",
        method: "GET",
        dataType: "json",
        data: {},
        success: function (t) {
            console.log(t);
            const select = document.getElementById("sellers_list");
            const deleteSelect = document.getElementById("d_sellers_list");

            // Clear any existing options (optional)
            select.innerHTML = '<option value="" selected disabled>Choose seller...</option>';
            deleteSelect.innerHTML = '';

            // Add new options
            t.forEach(seller => {
                const option1 = document.createElement("option");
                option1.value = seller.id;
                option1.textContent = seller.rin;
                option1.setAttribute("data-subtext", seller.group);
                select.appendChild(option1);
                
                const option2 = document.createElement("option");
                option2.value = seller.id;
                option2.textContent = seller.rin;
                option2.setAttribute("data-subtext", seller.group);
                deleteSelect.appendChild(option2);
            });

            // Refresh selectpicker to apply changes
            $('#sellers_list').selectpicker('refresh');
            $('#d_sellers_list').selectpicker('refresh');
        },
    });
}


$(function () {
    getAllGroups();
    getAllSellers();
});


document.getElementById('sellers_list').addEventListener('change', (event)=>{
    document.querySelector('#pre_e_groups_list i').className = 'spinner-border';
    document.querySelector('#pre_e_rin i').className = 'spinner-border';
    document.querySelector('#pre_e_companyTradeName i').className = 'spinner-border';
    document.querySelector('#pre_e_branchCode i').className = 'spinner-border';
    document.querySelector('#pre_e_branchAddress_country i').className = 'spinner-border';
    document.querySelector('#pre_e_branchAddress_governate i').className = 'spinner-border';
    document.querySelector('#pre_e_branchAddress_regionCity i').className = 'spinner-border';
    document.querySelector('#pre_e_branchAddress_street i').className = 'spinner-border';
    document.querySelector('#pre_e_branchAddress_buildingNumber i').className = 'spinner-border';
    document.querySelector('#pre_e_deviceSerialNumber i').className = 'spinner-border';
    document.querySelector('#pre_e_syndicateLicenseNumber i').className = 'spinner-border';
    document.querySelector('#pre_e_activityCode i').className = 'spinner-border';

    $('#e_groups_list').selectpicker('val', '');
    $('#e_groups_list').attr('disabled', 'true');
    $('#e_groups_list').selectpicker('refresh');
    document.getElementById('e_rin').value = '';
    document.getElementById('e_rin').setAttribute('disabled', 'true');
    document.getElementById('e_companyTradeName').value = '';
    document.getElementById('e_companyTradeName').setAttribute('disabled', 'true');
    document.getElementById('e_branchCode').value = '';
    document.getElementById('e_branchCode').setAttribute('disabled', 'true');
    document.getElementById('e_branchAddress_country').value = '';
    document.getElementById('e_branchAddress_country').setAttribute('disabled', 'true');
    document.getElementById('e_branchAddress_governate').value = '';
    document.getElementById('e_branchAddress_governate').setAttribute('disabled', 'true');
    document.getElementById('e_branchAddress_regionCity').value = '';
    document.getElementById('e_branchAddress_regionCity').setAttribute('disabled', 'true');
    document.getElementById('e_branchAddress_street').value = '';
    document.getElementById('e_branchAddress_street').setAttribute('disabled', 'true');
    document.getElementById('e_branchAddress_buildingNumber').value = '';
    document.getElementById('e_branchAddress_buildingNumber').setAttribute('disabled', 'true');
    document.getElementById('e_deviceSerialNumber').value = '';
    document.getElementById('e_deviceSerialNumber').setAttribute('disabled', 'true');
    document.getElementById('e_syndicateLicenseNumber').value = '';
    document.getElementById('e_syndicateLicenseNumber').setAttribute('disabled', 'true');
    document.getElementById('e_activityCode').value = '';
    document.getElementById('e_activityCode').setAttribute('disabled', 'true');

    console.log(event.target.value);
    $.ajax({
        url: "/adminpanal/tax/sellers/single/api/",
        method: "GET",
        dataType: "json",
        data: {
            'seller_id': event.target.value,
        },
        success: function (t) {
            console.log(t);
            $('#e_groups_list').selectpicker('val', t.group);
            $('#e_groups_list').removeAttr('disabled');
            $('#e_groups_list').selectpicker('refresh');
            document.querySelector('#pre_e_groups_list i').className = 'fas fa-users';

            document.getElementById('e_rin').value = t.rin;
            document.getElementById('e_rin').removeAttribute('disabled');
            document.querySelector('#pre_e_rin i').className = 'fas fa-id-card';
            document.getElementById('e_companyTradeName').value = t.companyTradeName;
            document.getElementById('e_companyTradeName').removeAttribute('disabled');
            document.querySelector('#pre_e_companyTradeName i').className = 'fas fa-id-card';
            document.getElementById('e_branchCode').value = t.branchCode;
            document.getElementById('e_branchCode').removeAttribute('disabled');
            document.querySelector('#pre_e_branchCode i').className = 'fas fa-hashtag';
            document.getElementById('e_branchAddress_country').value = t.branchAddress_country;
            document.getElementById('e_branchAddress_country').removeAttribute('disabled');
            document.querySelector('#pre_e_branchAddress_country i').className = 'fas fa-location-dot';
            document.getElementById('e_branchAddress_governate').value = t.branchAddress_governate;
            document.getElementById('e_branchAddress_governate').removeAttribute('disabled');
            document.querySelector('#pre_e_branchAddress_governate i').className = 'fas fa-location-dot';
            document.getElementById('e_branchAddress_regionCity').value = t.branchAddress_regionCity;
            document.getElementById('e_branchAddress_regionCity').removeAttribute('disabled');
            document.querySelector('#pre_e_branchAddress_regionCity i').className = 'fas fa-location-dot';
            document.getElementById('e_branchAddress_street').value = t.branchAddress_street;
            document.getElementById('e_branchAddress_street').removeAttribute('disabled');
            document.querySelector('#pre_e_branchAddress_street i').className = 'fas fa-location-dot';
            document.getElementById('e_branchAddress_buildingNumber').value = t.branchAddress_buildingNumber;
            document.getElementById('e_branchAddress_buildingNumber').removeAttribute('disabled');
            document.querySelector('#pre_e_branchAddress_buildingNumber i').className = 'fas fa-building';
            document.getElementById('e_deviceSerialNumber').value = t.deviceSerialNumber;
            document.getElementById('e_deviceSerialNumber').removeAttribute('disabled');
            document.querySelector('#pre_e_deviceSerialNumber i').className = 'fas fa-barcode';
            document.getElementById('e_syndicateLicenseNumber').value = t.syndicateLicenseNumber;
            document.getElementById('e_syndicateLicenseNumber').removeAttribute('disabled');
            document.querySelector('#pre_e_syndicateLicenseNumber i').className = 'fas fa-id-card';
            document.getElementById('e_activityCode').value = t.activityCode;
            document.getElementById('e_activityCode').removeAttribute('disabled');
            document.querySelector('#pre_e_activityCode i').className = 'fas fa-hashtag';
        },
    });
});


document.getElementById('submitEditTax').addEventListener('click', () => {
    var sellers_list = document.getElementById('sellers_list');
    var e_groups_list = document.getElementById('e_groups_list');
    var e_rin = document.getElementById('e_rin');
    var e_companyTradeName = document.getElementById('e_companyTradeName');
    var e_branchCode = document.getElementById('e_branchCode');
    var e_branchAddress_country = document.getElementById('e_branchAddress_country');
    var e_branchAddress_governate = document.getElementById('e_branchAddress_governate');
    var e_branchAddress_regionCity = document.getElementById('e_branchAddress_regionCity');
    var e_branchAddress_street = document.getElementById('e_branchAddress_street');
    var e_branchAddress_buildingNumber = document.getElementById('e_branchAddress_buildingNumber');
    var e_deviceSerialNumber = document.getElementById('e_deviceSerialNumber');
    var e_syndicateLicenseNumber = document.getElementById('e_syndicateLicenseNumber');
    var e_activityCode = document.getElementById('e_activityCode');
    var flag = true;

    if (e_groups_list.value == '') {
        let parentFormGroup = $('#e_groups_list').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $('#e_groups_list').selectpicker('setStyle', 'border-danger', 'add');
        $.notify({
            icon: 'fas fa-people-group',
            title: 'Submission Error!',
            message: 'Please choose a valid group.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        let parentFormGroup = $('#e_groups_list').closest('.form-group');
        parentFormGroup.removeClass('has-error');
        $('#e_groups_list').selectpicker('setStyle', 'border-danger', 'remove');
        $('#e_groups_list').selectpicker('setStyle', 'border-gray', 'add');
    }
    if (e_rin.value == '') {
        let parentFormGroup = $('#e_rin').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $.notify({
            icon: 'fas fa-id-card',
            title: 'Submission Error!',
            message: 'Please enter a valid rin.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        let parentFormGroup = $('#e_rin').closest('.form-group');
        parentFormGroup.removeClass('has-error');
    }
    if (e_companyTradeName.value == '') {
        let parentFormGroup = $('#e_companyTradeName').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $.notify({
            icon: 'fas fa-id-card',
            title: 'Submission Error!',
            message: 'Please enter a valid company name.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        let parentFormGroup = $('#e_companyTradeName').closest('.form-group');
        parentFormGroup.removeClass('has-error');
    }
    if (e_branchCode.value == '') {
        let parentFormGroup = $('#e_branchCode').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $.notify({
            icon: 'fas fa-hashtag',
            title: 'Submission Error!',
            message: 'Please enter a valid branch code.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        let parentFormGroup = $('#e_branchCode').closest('.form-group');
        parentFormGroup.removeClass('has-error');
    }
    if (e_branchAddress_country.value == '') {
        let parentFormGroup = $('#e_branchAddress_country').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $.notify({
            icon: 'fas fa-hashtag',
            title: 'Submission Error!',
            message: 'Please enter a valid country.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        let parentFormGroup = $('#e_branchAddress_country').closest('.form-group');
        parentFormGroup.removeClass('has-error');
    }
    if (e_branchAddress_governate.value == '') {
        let parentFormGroup = $('#e_branchAddress_governate').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $.notify({
            icon: 'fas fa-location-dot',
            title: 'Submission Error!',
            message: 'Please enter a valid governorate.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        let parentFormGroup = $('#e_branchAddress_governate').closest('.form-group');
        parentFormGroup.removeClass('has-error');
    }
    if (e_branchAddress_regionCity.value == '') {
        let parentFormGroup = $('#e_branchAddress_regionCity').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $.notify({
            icon: 'fas fa-location-dot',
            title: 'Submission Error!',
            message: 'Please enter a valid region city.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        let parentFormGroup = $('#e_branchAddress_regionCity').closest('.form-group');
        parentFormGroup.removeClass('has-error');
    }
    if (e_branchAddress_street.value == '') {
        let parentFormGroup = $('#e_branchAddress_street').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $.notify({
            icon: 'fas fa-location-dot',
            title: 'Submission Error!',
            message: 'Please enter a valid street.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        let parentFormGroup = $('#e_branchAddress_street').closest('.form-group');
        parentFormGroup.removeClass('has-error');
    }
    if (e_branchAddress_buildingNumber.value == '') {
        let parentFormGroup = $('#e_branchAddress_buildingNumber').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $.notify({
            icon: 'fas fa-building',
            title: 'Submission Error!',
            message: 'Please enter a valid building number.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        let parentFormGroup = $('#e_branchAddress_buildingNumber').closest('.form-group');
        parentFormGroup.removeClass('has-error');
    }
    if (e_deviceSerialNumber.value == '') {
        let parentFormGroup = $('#e_deviceSerialNumber').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $.notify({
            icon: 'fas fa-barcode',
            title: 'Submission Error!',
            message: 'Please enter a valid serial number.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        let parentFormGroup = $('#e_deviceSerialNumber').closest('.form-group');
        parentFormGroup.removeClass('has-error');
    }
    if (e_activityCode.value == '') {
        let parentFormGroup = $('#e_activityCode').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $.notify({
            icon: 'fas fa-hashtag',
            title: 'Submission Error!',
            message: 'Please enter a valid activity code.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        let parentFormGroup = $('#e_activityCode').closest('.form-group');
        parentFormGroup.removeClass('has-error');
    }

    if (flag) {
        // Create FormData object
        const formData = new FormData();
        // Append values to FormData
        formData.append('seller_id', sellers_list.value);
        formData.append('group_id', e_groups_list.value);
        formData.append('e_rin', e_rin.value);
        formData.append('e_companyTradeName', e_companyTradeName.value);
        formData.append('e_branchCode', e_branchCode.value);
        formData.append('e_branchAddress_country', e_branchAddress_country.value);
        formData.append('e_branchAddress_governate', e_branchAddress_governate.value);
        formData.append('e_branchAddress_regionCity', e_branchAddress_regionCity.value);
        formData.append('e_branchAddress_street', e_branchAddress_street.value);
        formData.append('e_branchAddress_buildingNumber', e_branchAddress_buildingNumber.value);
        formData.append('e_deviceSerialNumber', e_deviceSerialNumber.value);
        formData.append('e_syndicateLicenseNumber', e_syndicateLicenseNumber.value);
        formData.append('e_activityCode', e_activityCode.value);
        
        $.ajax({
            url: "/adminpanal/tax/edit/api/",
            type: 'POST',
            dataType: "json",
            processData: false,  // Don't process the data
            contentType: false,  // Don't set content type
            data: formData,
            headers: {
                'X-CSRFToken': document.getElementById('csrfToken').value,
            },
            success: function (t) {
                // console.log(t);
                if (t.status == 'No Post') {
                    swal("Technical Error!", "You have to contact with your administrator.", {
                        icon: "error",
                        buttons: false,
                        timer: 2000
                    });
                }
                if (t.status == 'exists') {
                    swal("Submission Error!", "The pos has been submitted already.", {
                        icon: "error",
                        buttons: false,
                        timer: 2000
                    });
                }
                if (t.status == 'error') {
                    swal("Submission Error!", "No seller found with this rin.", {
                        icon: "error",
                        buttons: false,
                        timer: 2000
                    });
                }
                if (t.status == 'updated') {
                    swal("Thank you", "The Seller has been updated successfully.", {
                        icon: "success",
                        buttons: false,
                        timer: 2000
                    });
                    document.getElementById('resetEditTax').click();
                    getAllSellers();
                    document.getElementById("reset").click();
                }
            },
        });
    }
});

document.getElementById('resetEditTax').addEventListener('click', () => {
    $('#e_groups_list').closest('.form-group').removeClass('has-error');
    $('#e_groups_list').selectpicker('setStyle', 'border-danger', 'remove');
    $('#e_groups_list').selectpicker('setStyle', 'border-gray', 'add');
    $('#e_rin').closest('.form-group').removeClass('has-error');
    $('#e_companyTradeName').closest('.form-group').removeClass('has-error');
    $('#e_branchCode').closest('.form-group').removeClass('has-error');
    $('#e_branchAddress_country').closest('.form-group').removeClass('has-error');
    $('#e_branchAddress_governate').closest('.form-group').removeClass('has-error');
    $('#e_branchAddress_regionCity').closest('.form-group').removeClass('has-error');
    $('#e_branchAddress_street').closest('.form-group').removeClass('has-error');
    $('#e_branchAddress_buildingNumber').closest('.form-group').removeClass('has-error');
    $('#e_deviceSerialNumber').closest('.form-group').removeClass('has-error');
    $('#e_syndicateLicenseNumber').closest('.form-group').removeClass('has-error');
    $('#e_activityCode').closest('.form-group').removeClass('has-error');

    $('#e_groups_list').selectpicker('val', '');
    $('#e_groups_list').attr('disabled', 'true');
    $('#e_groups_list').selectpicker('refresh');
    document.getElementById('e_rin').value = '';
    document.getElementById('e_rin').setAttribute('disabled', 'true');
    document.getElementById('e_companyTradeName').value = '';
    document.getElementById('e_companyTradeName').setAttribute('disabled', 'true');
    document.getElementById('e_branchCode').value = '';
    document.getElementById('e_branchCode').setAttribute('disabled', 'true');
    document.getElementById('e_branchAddress_country').value = '';
    document.getElementById('e_branchAddress_country').setAttribute('disabled', 'true');
    document.getElementById('e_branchAddress_governate').value = '';
    document.getElementById('e_branchAddress_governate').setAttribute('disabled', 'true');
    document.getElementById('e_branchAddress_regionCity').value = '';
    document.getElementById('e_branchAddress_regionCity').setAttribute('disabled', 'true');
    document.getElementById('e_branchAddress_street').value = '';
    document.getElementById('e_branchAddress_street').setAttribute('disabled', 'true');
    document.getElementById('e_branchAddress_buildingNumber').value = '';
    document.getElementById('e_branchAddress_buildingNumber').setAttribute('disabled', 'true');
    document.getElementById('e_deviceSerialNumber').value = '';
    document.getElementById('e_deviceSerialNumber').setAttribute('disabled', 'true');
    document.getElementById('e_syndicateLicenseNumber').value = '';
    document.getElementById('e_syndicateLicenseNumber').setAttribute('disabled', 'true');
    document.getElementById('e_activityCode').value = '';
    document.getElementById('e_activityCode').setAttribute('disabled', 'true');

    $('#sellers_list').selectpicker('val', '');
});


document.getElementById('submitDeleteTax').addEventListener('click', () => {
    var d_sellers_list = document.getElementById('d_sellers_list');
    var flag = true;
    // Get the selected options as an array of values
    const selectedValues = Array.from(d_sellers_list.selectedOptions).map(option => option.value);
    console.log(selectedValues);
    if (selectedValues.length == 0) {
        $.notify({
            icon: 'fas fa-percent',
            title: 'Submission Error!',
            message: 'Please choose at least one seller to delete.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (flag) {
        // Create FormData object
        const formData = new FormData();
        selectedValues.forEach((id, index) => {
            formData.append('sellers_ids', id);
        });
        $.ajax({
            url: "/adminpanal/tax/delete/api/",
            type: 'POST',
            dataType: "json",
            processData: false,  // Don't process the data
            contentType: false,  // Don't set content type
            data: formData,
            headers: {
                'X-CSRFToken': document.getElementById('csrfToken').value,
            },
            success: function (response) {
                // console.log(t);
                if (response.status == 'deleted') {
                    swal("Thank you", "The selected seller/s have been deleted successfully.", {
                        icon: "success",
                        buttons: false,
                        timer: 3000
                    });
                }
                if (response.status == 'No_Post') {
                    swal("Sorry!", "You have to send a request.", {
                        icon: "error",
                        buttons: false,
                        timer: 3000
                    });
                }
                document.getElementById('resetDeleteTax').click();
                getAllSellers();
                document.getElementById("reset").click();
            },
        });
    }
});

document.getElementById('resetDeleteTax').addEventListener('click', () => {
    $('#d_sellers_list').selectpicker('val', '');
});