var current_pumps = [];
var new_pumps = [];

document.getElementById('stations_list').addEventListener('change', (event)=>{
    current_pumps = [];
    document.querySelector('#pre_pump_number i').className = 'spinner-border';
    console.log(event.target.value);
    $.ajax({
        url: "/adminpanal/pumps/stations/single/api/",
        method: "GET",
        dataType: "json",
        data: {
            'station_id': event.target.value,
        },
        success: function (t) {
            console.log(t);
            if(t.status == 'not_exists'){
                document.getElementById('preview_pumps_data').innerHTML = '';
                document.getElementById('preview_no_data_msg').classList.remove('d-none');
                document.getElementById('preview_pumps_data').classList.add('d-none');

                document.getElementById('pumpsSVG').classList.add('d-none');
                document.getElementById('pumpsView').classList.remove('d-none');
                document.querySelector('#pre_pump_number i').className = 'fas fa-gas-pump';
                document.getElementById('pump_number').removeAttribute('disabled');
                document.getElementById('add_pump').removeAttribute('disabled');
                swal("Sorry!", "No pumps found in the selected station.", {
                    icon: "error",
                    buttons: false,
                    timer: 2000
                });
            }else{
                var temp_list = ``;
                t.forEach((pump)=>{
                    temp_list += `
                    <div class="col-sm-12 col-md-12">
                        <div class="card card-stats btn-blue-dark card-round mb-3">
                            <div class="card-body">
                                <div class="row align-items-center">
                                    <div class="col-icon">
                                        <div class="icon-big text-center btn-success-dark bubble-shadow-small rounded-3">
                                            <i class="fas fa-gas-pump"></i>
                                        </div>
                                    </div>
                                    <div class="col col-stats ms-3 ms-sm-0">
                                        <div class="numbers">
                                            <p class="card-category">${pump.timestamp}</p>
                                            <h4 class="card-title text-white">${pump.number}</h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>`;
                    current_pumps.push((pump.number).split(' ')[1]);
                });
                document.getElementById('preview_pumps_data').innerHTML = temp_list;
                document.getElementById('preview_no_data_msg').classList.add('d-none');
                document.getElementById('preview_pumps_data').classList.remove('d-none');

                document.getElementById('pumpsSVG').classList.add('d-none');
                document.getElementById('pumpsView').classList.remove('d-none');

                document.querySelector('#pre_pump_number i').className = 'fas fa-gas-pump';
                document.getElementById('pump_number').removeAttribute('disabled');
                document.getElementById('add_pump').removeAttribute('disabled');
            }
        },
    });
});

document.getElementById('pump_number').addEventListener('keydown', function(event) {
    // Check if the "Enter" key was pressed
    if (event.key === 'Enter') {
        // Trigger the button click
        document.getElementById('add_pump').click();
    }
});

document.getElementById('add_pump').addEventListener('click', ()=>{
    var pumps_data = document.getElementById('pumps_data');
    var pump_number = document.getElementById('pump_number');
    if(pump_number.value <= 0 || pump_number.value > 100 || pump_number.value == ''){
        $.notify({
            icon: 'fas fa-gas-pump',
            title: 'Validation Error',
            message: 'Please enter a valid pump number.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
    }else{
        if(current_pumps.includes(pump_number.value)){
            $.notify({
                icon: 'fas fa-gas-pump',
                title: 'Submittion Error!',
                message: 'Sorry, the pump number you trying to add is already exists.',
            }, {
                type: 'danger',
                placement: {
                    from: "top",
                    align: "right"
                },
                time: 1000,
            });
        }else{
            if(pumps_data.children.length < 1){
                pumps_data.innerHTML = `
                <div class="col-sm-6 col-md-6" id="temp_pump_${pump_number.value}">
                    <div class="card card-stats card-round">
                        <div class="card-body">
                            <div class="row align-items-center">
                                <div class="col-icon">
                                    <div class="icon-big text-center btn-success-dark bubble-shadow-small rounded-3">
                                        <i class="fas fa-gas-pump"></i>
                                    </div>
                                </div>
                                <div class="col col-stats ms-3 ms-sm-0">
                                    <div class="numbers">
                                        <p class="card-category">Pump</p>
                                        <h4 class="card-title">${pump_number.value}</h4>
                                    </div>
                                </div>
                                <div class="col-icon" style="margin-left: 0px;margin-right: 15px;">
                                    <div class="icon-big text-center bubble-shadow-small">
                                        <i class="fas fa-trash text-danger delete-icon" onclick="deletePump('${pump_number.value}')" style="cursor: pointer;"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>`;
                document.getElementById('no_data_msg').classList.add('d-none');
                pumps_data.classList.remove('d-none');
            }else{
                pumps_data.innerHTML += `
                <div class="col-sm-6 col-md-6" id="temp_pump_${pump_number.value}">
                    <div class="card card-stats card-round">
                        <div class="card-body">
                            <div class="row align-items-center">
                                <div class="col-icon">
                                    <div class="icon-big text-center btn-success-dark bubble-shadow-small rounded-3">
                                        <i class="fas fa-gas-pump"></i>
                                    </div>
                                </div>
                                <div class="col col-stats ms-3 ms-sm-0">
                                    <div class="numbers">
                                        <p class="card-category">Pump</p>
                                        <h4 class="card-title">${pump_number.value}</h4>
                                    </div>
                                </div>
                                <div class="col-icon" style="margin-left: 0px;margin-right: 15px;">
                                    <div class="icon-big text-center bubble-shadow-small">
                                        <i class="fas fa-trash text-danger delete-icon" onclick="deletePump('${pump_number.value}')" style="cursor: pointer;"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>`;
            }
            current_pumps.push(pump_number.value);
            new_pumps.push(pump_number.value);
            pump_number.value = '';
            pump_number.focus();
        }
    }
});

function deletePump(pump_number){
    document.getElementById('temp_pump_'+pump_number).remove();
    var pumps_data = document.getElementById('pumps_data');
    if(pumps_data.children.length < 1){
        document.getElementById('no_data_msg').classList.remove('d-none');
        pumps_data.classList.add('d-none');
    }
    const index = current_pumps.indexOf(pump_number);
    const index2 = new_pumps.indexOf(pump_number);
    if (index !== -1) {
        // Remove the element at the found index
        current_pumps.splice(index, 1);
    }
    if (index2 !== -1) {
        // Remove the element at the found index
        new_pumps.splice(index, 1);
    }
}

document.getElementById('submitPumps').addEventListener('click', () => {
    var stations_list = document.getElementById('stations_list');
    var pumps_data = document.getElementById('pumps_data');
    var flag = true;

    if (stations_list.value == '') {
        // product_num.classList.add('bg-danger', 'text-white');
        $.notify({
            icon: 'fas fa-industry',
            title: 'Validation Error',
            message: 'Please choose a station.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        if(pumps_data.children.length < 1){
            // product_num.classList.add('bg-danger', 'text-white');
            $.notify({
                icon: 'fas fa-gas-pump',
                title: 'Submittion Error!',
                message: 'Please enter a pump number.',
            }, {
                type: 'danger',
                placement: {
                    from: "top",
                    align: "right"
                },
                time: 1000,
            });
            flag = false;
        }
    }

    if (flag) {
        // Create FormData object
        const formData = new FormData();
        // Append values to FormData
        formData.append('station_id', stations_list.value);
        new_pumps.forEach((pump_num)=>{
            formData.append('pumps', pump_num);
        });
        $.ajax({
            url: "/adminpanal/pumps/add/api/",
            type: 'POST',
            dataType: "json",
            processData: false,  // Don't process the data
            contentType: false,  // Don't set content type
            data: formData,
            headers: {
                'X-CSRFToken': document.getElementById('csrfToken').value,
            },
            success: function (t) {
                // console.log(t);
                if (t.status == 'No Post') {
                    // $.notify({
                    //     icon: 'fas fa-gears',
                    //     title: 'Technical Error',
                    //     message: 'You have to contact with your administrator.',
                    // }, {
                    //     type: 'danger',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Technical Error!", "You have to contact with your administrator.", {
                        icon: "error",
                        buttons: false,
                        timer: 2000
                    });
                }
                if (t.status == 'added') {
                    // $.notify({
                    //     icon: 'fas fa-droplet',
                    //     title: 'Submittion Successfully',
                    //     message: 'The product has been submitted successfully.',
                    // }, {
                    //     type: 'success',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Thank you", "The pumps has been submitted successfully.", {
                        icon: "success",
                        buttons: false,
                        timer: 2000
                    });
                    document.getElementById('resetPumps').click();
                    document.getElementById("reset").click();
                }
            },
        });
    }
});

// function submitProduct(){
//     product_num = document.getElementById('product_num');
//     product_name = document.getElementById('product_name');
//     product_price = document.getElementById('product_price');
//     if(product_num.value == ''){
//         product_num.classList.add('bg-danger', 'text-white');
//     }else if(product_name.value == ''){
//         product_name.classList.add('bg-danger', 'text-white');
//     }else if(product_price.value == ''){
//         product_price.classList.add('bg-danger', 'text-white');
//     }else{
//         document.getElementById('miniloader').classList.remove('d-none');
//         $.ajax({
//             url: "/adminpanal/product/add/api/",
//             method: "GET",
//             dataType: "json",
//             data: {
//                 'product_num': product_num.value,
//                 'product_name': product_name.value,
//                 'product_price': product_price.value,
//             },
//             success: function (t) {
//                 console.log(t);
//                 if(t.status == 'exists'){
//                     document.getElementById('error_msg').innerHTML = 'Product Already Exists!';
//                     document.getElementById('error_msg').classList.add('text-danger');
//                     document.getElementById('error_msg').classList.remove('d-none');
//                     document.getElementById('miniloader').classList.add('d-none');
//                     setTimeout(()=>{
//                         document.getElementById('error_msg').innerHTML = '';
//                         document.getElementById('error_msg').classList.remove('text-danger');
//                         document.getElementById('error_msg').classList.add('d-none');
//                     },3000);
//                 }


//                 if(t.status == 'No Get'){
//                     document.getElementById('error_msg').innerHTML = 'Technical Error!';
//                     document.getElementById('error_msg').classList.add('text-danger');
//                     document.getElementById('error_msg').classList.remove('d-none');

//                     setTimeout(()=>{
//                         document.getElementById('error_msg').innerHTML = '';
//                         document.getElementById('error_msg').classList.remove('text-danger');
//                         document.getElementById('error_msg').classList.add('d-none');
//                     },3000);
//                 }


//                 if(t.status == 'added'){
//                     document.getElementById('error_msg').innerHTML = 'Product is added successfully.';
//                     document.getElementById('error_msg').classList.add('text-success');
//                     document.getElementById('error_msg').classList.remove('d-none');

//                     product_num.classList.remove('bg-danger', 'text-white');
//                     product_name.classList.remove('bg-danger', 'text-white');
//                     product_price.classList.remove('bg-danger', 'text-white');
//                     product_num.value = '';
//                     product_name.value = '';
//                     product_price.value = '';

//                     var e = $("#productTbl");
//                     e.bootstrapTable("showLoading");
//                     e.bootstrapTable("append",{
//                         'id':t.id,
//                         'number':t.number,
//                         'name':t.name,
//                         'price':t.price,
//                         'timestamp':t.timestamp,
//                         'actions': `<button class="btn btn-dark w-100" onclick="deleteProduct('${t.id}')">Delete</button>`,
//                     });
//                     e.bootstrapTable("refresh");
//                     e.bootstrapTable("hideLoading");
//                     document.getElementById('miniloader').classList.add('d-none');
//                     document.getElementById('products_num').innerHTML = parseInt(document.getElementById('products_num').innerHTML) + 1;

//                     setTimeout(()=>{
//                         document.getElementById('error_msg').innerHTML = '';
//                         document.getElementById('error_msg').classList.remove('text-danger');
//                         document.getElementById('error_msg').classList.add('d-none');
//                     },3000);
//                 }

//             },
//         });
//     }
// }

document.getElementById('resetPumps').addEventListener('click', () => {
    $('#stations_list').selectpicker('val', '');
    document.getElementById('preview_pumps_data').innerHTML = '';
    document.getElementById('preview_pumps_data').classList.add('d-none');
    document.getElementById('preview_no_data_msg').classList.remove('d-none');
    document.getElementById('pumpsView').classList.add('d-none');
    document.getElementById('pumpsSVG').classList.remove('d-none');
    document.getElementById('pumps_data').innerHTML = '';
    document.getElementById('pumps_data').classList.add('d-none');
    document.getElementById('no_data_msg').classList.remove('d-none');
    document.getElementById('pump_number').value = '';
    document.getElementById('pump_number').setAttribute('disabled', 'true');
    document.getElementById('add_pump').setAttribute('disabled', 'true');
    current_pumps = [];
    new_pumps = [];
});

//define column header menu as column visibility toggle
var headerMenu = function () {
    var menu = [];
    var columns = this.getColumns();

    for (let column of columns) {

        //create checkbox element using font awesome icons
        let icon = document.createElement("i");
        icon.classList.add("fas");
        icon.classList.add(column.isVisible() ? "fa-check-square" : "fa-square");

        //build label
        let label = document.createElement("span");
        let title = document.createElement("span");

        title.textContent = " " + column.getDefinition().title;

        label.appendChild(icon);
        label.appendChild(title);

        //create menu item
        menu.push({
            label: label,
            action: function (e) {
                //prevent menu closing
                e.stopPropagation();

                //toggle current column visibility
                column.toggle();

                //change menu item icon
                if (column.isVisible()) {
                    icon.classList.remove("fa-square");
                    icon.classList.add("fa-check-square");
                } else {
                    icon.classList.remove("fa-check-square");
                    icon.classList.add("fa-square");
                }
            }
        });
    }

    return menu;
};

//Define variables for input elements
var fieldSEl = document.getElementById("sort_field");
var dirEl = document.getElementById("sort_direction");

//Define variables for input elements
var fieldEl = document.getElementById("filter_field");
var typeEl = document.getElementById("filter_type");
var valueEl = document.getElementById("filter_value");


//Trigger setFilter function with correct parameters
function updateFilter() {
    var filterVal = fieldEl.options[fieldEl.selectedIndex].value;
    var typeVal = typeEl.options[typeEl.selectedIndex].value;

    var filter = filterVal;

    if (filterVal) {
        table.setFilter(filter, typeVal, valueEl.value);
    }
}

//Update filters on value change
document.getElementById("filter_field").addEventListener("change", updateFilter);
document.getElementById("filter_type").addEventListener("change", updateFilter);
document.getElementById("filter_value").addEventListener("keyup", updateFilter);

//Clear filters on "Clear Filters" button click
document.getElementById("filter_clear").addEventListener("click", function () {
    fieldEl.value = "";
    typeEl.value = "";
    valueEl.value = "";

    table.clearFilter();
});

// Define column configurations with headerMenu
function defaultColumns() {
    return [
        { title: "ID", field: "id", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
        { title: "Pump Number", field: "pump_number", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
        { title: "Station Code", field: "station_code", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
        { title: "Station Name", field: "station_name", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
        {
            title: "Creation Date", field: "timestamp", hozAlign: "start", sorter: "datetime", sorterParams: {
                format: "yyyy-MM-dd HH:mm:ss",
                alignEmptyValues: "top",
            }, headerMenu: headerMenu
        },
    ];
}

// Initial Table Configuration Function
function createTable() {
    return new Tabulator("#pumps_table", {
        layout: "fitColumns",          // Fit columns to the table width
        responsiveLayout: "hide",       // Hide columns that don’t fit
        height: window.innerHeight / 2,
        printAsHtml: true,
        printStyled: true,
        textDirection: "ltr",
        groupBy: "station_name",
        groupStartOpen: true,
        groupToggleElement: "header",
        groupHeaderPrint: function(value, count, data, group){
            return value;
        },
        groupHeaderDownload: function(value, count, data, group){
            return value;
        },
        printHeader: `
        <div class="row mt-4 mb-4">
            <div class="col-12 d-flex justify-content-center align-items-center">
                <h1>Pumps Table</h1>
            </div>
        </div>
        <hr>`,
        printFooter: `
        <div class="row mt-4">
            <div class="col-12 d-flex justify-content-center align-items-center">
                <img src='/static/img/gts-logo.png' alt='gts-logo' style="width: 50%;height: 100%;" />
            </div>
        </div>
        `,
        ajaxURL: "http://127.0.0.1:8000/adminpanal/pumps/view/api/",
        ajaxParams: { page: 1, size: 10 },
        progressiveLoad: "scroll",
        placeholder: "No Pumps Data",
        selectableRows: true,
        paginationSize: 10,
        columnDefaults: {
            tooltip: true,
        },
        langs: {
            "ar-eg": {
                "columns": {
                    "id": "مسلسل",
                    "pump_number": "رقم المضخة",
                    "station_code": "كود المحطة",
                    "station_name": "اسم المحطة",
                    "timestamp": "تاريخ الانشاء",
                },
            }
        },
        columns: defaultColumns(),
    });
}

var table = createTable();

// var table = new Tabulator("#pumps_table", {
//     layout: "fitColumns",          // Fit columns to the table width
//     responsiveLayout: "hide",       // Hide columns that don’t fit
//     height: window.innerHeight / 2,
//     printAsHtml: true,
//     printStyled: true,
//     // autoColumns:true,
//     // printRowRange: "all",
//     // textDirection: "rtl",
//     printHeader: `
//     <div class="row mt-4 mb-4">
//         <div class="col-12 d-flex justify-content-center align-items-center">
//             <h1>Products Table</h1>
//         </div>
//     </div>
//     <hr>
//     `,
//     printFooter: `
//     <div class="row mt-4">
//         <div class="col-12 d-flex justify-content-center align-items-center">
//             <img src='/static/img/gts-logo.png' alt='gts-logo' style="width: 50%;height: 100%;" />
//         </div>
//     </div>
//     `,
//     // clipboard: true,
//     // clipboardPasteAction: "replace",
//     // resizableRows: true,
//     // resizableRowGuide: true,
//     // resizableColumnGuide: true,
//     // movableColumns: true,
//     ajaxURL: "http://127.0.0.1:8000/adminpanal/product/view/api/",
//     ajaxParams: { page: 1, size: 10 },  // Start with page 1 and size 3
//     progressiveLoad: "scroll",      // Enable progressive loading with scroll
//     placeholder: "No Product Data",
//     selectableRows: true, //make rows selectable
//     // addRowPos: "top",
//     // history: true,
//     paginationSize: 10,
//     columnDefaults: {
//         tooltip: true,
//     },
//     langs: {
//         "ar-eg": { //French language definition
//             "columns": {
//                 "id": "مسلسل",
//                 "number": "الرقم",
//                 "name": "الاسم",
//                 "price": "السعر",
//                 "timestamp": "تاريخ الانشاء",
//             },
//         }
//     },
//     columns: [
//         { title: "ID", field: "id", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
//         { title: "Number", field: "number", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
//         { title: "Name", field: "name", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
//         { title: "Price", field: "price", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
//         { title: "Timestamp", field: "timestamp", hozAlign: "start", sorter: "datetime", headerMenu: headerMenu },
//     ],
// });

//Trigger sort when "Trigger Sort" button is clicked
document.getElementById("sort_trigger").addEventListener("click", function () {
    table.setSort(fieldSEl.options[fieldSEl.selectedIndex].value, dirEl.options[dirEl.selectedIndex].value);
});

document.getElementById("sort_reset").addEventListener("click", function () {
    table.setSort("id", "asc");
});

table.on("rowSelectionChanged", function (data, rows) {
    document.getElementById("select_stats").innerHTML = data.length;
});

//select row on "select all" button click
document.getElementById("select_all").addEventListener("click", function () {
    table.selectRow();
});

//deselect row on "deselect all" button click
document.getElementById("deselect_all").addEventListener("click", function () {
    table.deselectRow();
});

//Delete row on "Delete Row" button click
document.getElementById("del_row").addEventListener("click", function () {
    var rowid = document.getElementById('row_delete');
    if (rowid.value == '') {
        $.notify({
            icon: 'fas fa-trash',
            title: 'Validation Error',
            message: 'Please enter a valid row number.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
    } else {
        table.deleteRow(parseInt(rowid.value));
        rowid.value = '';
    }
});

//Clear table on "Empty the table" button click
document.getElementById("clear").addEventListener("click", function () {
    table.clearData()
});

//Reset table contents on "Reset the table" button click
document.getElementById("reset").addEventListener("click", function () {
    // table.setData("http://127.0.0.1:8000/adminpanal/product/view/api/", { page: 1, size: 10 });
    // Destroy current instance of the table
    table.destroy();
    // Recreate table with initial settings
    table = createTable();
});

document.getElementById('download_btn').addEventListener('click', () => {
    var file_name = document.getElementById('file_name');
    var download_type = document.getElementById('download_type');
    var flag = true;
    if (file_name.value == '') {
        $.notify({
            icon: 'fas fa-font',
            title: 'Validation Error',
            message: 'Please enter a valid file name.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (download_type.value == '') {
        $.notify({
            icon: 'fas fa-gear',
            title: 'Validation Error',
            message: 'Please choose a download type.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }

    if (flag) {
        if (download_type.value == 'csv') table.download("csv", `${file_name.value}.csv`);
        if (download_type.value == 'json') table.download("json", `${file_name.value}.json`);
        if (download_type.value == 'xlsx') table.download("xlsx", `${file_name.value}.xlsx`, { sheetName: file_name.value });
        if (download_type.value == 'pdf') {
            table.download("pdf", `${file_name.value}.pdf`, {
                orientation: "portrait", //set page orientation to portrait
                title: "Pumps Data", //add title to report
            });
        }
        if (download_type.value == 'html') table.download("html", `${file_name.value}.html`, { style: true });
    }
});

//print button
document.getElementById("print_table").addEventListener("click", function () {
    // Get the selected print range from the dropdown
    var selectedRange = document.getElementById("print_range").value;
    console.log(selectedRange);
    // Update printRowRange on the table instance
    table.options.printRowRange = selectedRange;
    // Print the table using the selected printRowRange
    table.print(false, true);
});


//set locale to French
document.getElementById("lang_arabic").addEventListener("click", function () {
    table.setLocale("ar-eg");
    table.setColumns(defaultColumns());  // Reload columns to apply headerMenu
    // document.getElementById("pumps_table").setAttribute("dir", "rtl");
});

//set default locale
document.getElementById("lang_default").addEventListener("click", function () {
    table.setLocale("");
    table.setColumns(defaultColumns());  // Reload columns to apply headerMenu
    // document.getElementById("pumps_table").setAttribute("dir", "ltr");
});

function getAllStations() {
    $.ajax({
        url: "/adminpanal/pumps/stations/all/api/",
        method: "GET",
        dataType: "json",
        data: {},
        success: function (t) {
            console.log(t);
            const select = document.getElementById("stations_list");
            const deleteSelect = document.getElementById("d_stations_list");

            // Clear any existing options (optional)
            select.innerHTML = '<option value="" selected disabled>Choose station...</option>';
            deleteSelect.innerHTML = '<option value="" selected disabled>Choose station...</option>';

            // Add new options
            t.forEach(station => {
                const option1 = document.createElement("option");
                option1.value = station.id;
                option1.textContent = `${station.station_code} - ${station.station_name}`;
                select.appendChild(option1);

                const option2 = document.createElement("option");
                option2.value = station.id;
                option2.textContent = `${station.station_code} - ${station.station_name}`;
                deleteSelect.appendChild(option2);
            });

            // Refresh selectpicker to apply changes
            $('#stations_list').selectpicker('refresh');
            $('#d_stations_list').selectpicker('refresh');
        },
    });
}

$(function () {
    getAllStations();
});


document.getElementById('d_stations_list').addEventListener('change', (event)=>{
    console.log(event.target.value);
    $.ajax({
        url: "/adminpanal/pumps/stations/single/api/",
        method: "GET",
        dataType: "json",
        data: {
            'station_id': event.target.value,
        },
        success: function (t) {
            console.log(t);
            if(t.status == 'not_exists'){
                swal("Sorry!", "No pumps found in the selected station.", {
                    icon: "error",
                    buttons: false,
                    timer: 2000
                });
                $('#d_pumps_list').empty();
                $('#d_pumps_list').attr('disabled', 'true');
                $('#d_pumps_list').selectpicker('refresh');
            }else{
                const select = document.getElementById("d_pumps_list");

                // Clear any existing options (optional)
                select.innerHTML = '';

                // Add new options
                t.forEach(pump => {
                    const option = document.createElement("option");
                    option.value = pump.id;
                    option.textContent = pump.number;
                    option.setAttribute("data-subtext", `${pump.timestamp}`);
                    select.appendChild(option);
                });

                // Refresh selectpicker to apply changes
                $('#d_pumps_list').removeAttr('disabled');
                $('#d_pumps_list').selectpicker('refresh');
            }
        },
    });
});


document.getElementById('submitDeletePumps').addEventListener('click', () => {
    var d_stations_list = document.getElementById('d_stations_list');
    var d_pumps_list = document.getElementById('d_pumps_list');
    var flag = true;
    // Get the selected options as an array of values
    const selectedValues = Array.from(d_pumps_list.selectedOptions).map(option => option.value);
    console.log(selectedValues);
    if (d_stations_list.value == '') {
        $.notify({
            icon: 'fas fa-trash',
            title: 'Validation Error',
            message: 'Please choose a station first!',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        if (selectedValues.length == 0) {
            $.notify({
                icon: 'fas fa-trash',
                title: 'Validation Error',
                message: 'Please choose at least one pump to delete.',
            }, {
                type: 'danger',
                placement: {
                    from: "top",
                    align: "right"
                },
                time: 1000,
            });
            flag = false;
        }
    }
    if (flag) {
        // Create FormData object
        const formData = new FormData();
        // Append values to FormData
        // formData.append('f_st_codes', selectedValues);
        selectedValues.forEach((id, index) => {
            formData.append('pumps_ids', id);
        });
        $.ajax({
            url: "/adminpanal/pumps/delete/api/",
            type: 'POST',
            dataType: "json",
            processData: false,  // Don't process the data
            contentType: false,  // Don't set content type
            data: formData,
            headers: {
                'X-CSRFToken': document.getElementById('csrfToken').value,
            },
            success: function (response) {
                // console.log(t);
                if (response.status == 'deleted') {
                    swal("Thank you", "The selected pumps have been deleted successfully.", {
                        icon: "success",
                        buttons: false,
                        timer: 3000
                    });
                }
                if (response.status == 'No_Post') {
                    swal("Sorry!", "You have to send a request.", {
                        icon: "error",
                        buttons: false,
                        timer: 3000
                    });
                }
                document.getElementById('resetDeletePumps').click();
                document.getElementById("reset").click();
            },
        });
    }
});

document.getElementById('resetDeletePumps').addEventListener('click', () => {
    $('#d_pumps_list').empty();
    $('#d_pumps_list').attr('disabled', 'true');
    $('#d_pumps_list').selectpicker('refresh');
    $('#d_stations_list').selectpicker('val', '');
});