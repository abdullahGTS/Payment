let pond;

document.addEventListener('DOMContentLoaded', () => {
    // Get a reference to the file input element
    const inputElement = document.querySelector('.my-pond');
    FilePond.registerPlugin(
        FilePondPluginFileEncode,
        FilePondPluginFileValidateSize,
    );

    // Create a FilePond instance
    pond = FilePond.create(inputElement, {
        acceptedFileTypes: ['text/xml'],
        // allowMultiple: true,
        instantUpload: false,
        maxFileSize: '1MB', // Set the maximum file size to 5 MB
        onaddfile: (error, fileItem) => {
            if (error) {
                console.log('FilePond error:', error);
                $.notify({
                    icon: 'fas fa-file-circle-plus',
                    title: 'Validation Error',
                    message: 'Please upload a valid XML file.',
                }, {
                    type: 'danger',
                    placement: {
                        from: "top",
                        align: "right"
                    },
                    time: 1000,
                });
            } else {
                console.log('File added:', fileItem.file.name);
                openStationModal(fileItem.file.name);
                const file = fileItem.file;
                const reader = new FileReader();
                reader.onload = function (e) {
                    const xmlString = e.target.result;
                    displayXML(xmlString);
                };
                reader.readAsText(file);
            }
        },
        onremovefile: (error, fileItem) => {
            if (error) {
                console.log('FilePond error:', error);
                $.notify({
                    icon: 'fas fa-file-circle-plus',
                    title: 'Validation Error',
                    message: 'Sorry, Can not delete the XML file.',
                }, {
                    type: 'danger',
                    placement: {
                        from: "top",
                        align: "right"
                    },
                    time: 1000,
                });
            } else {
                console.log('File removed:', fileItem.file);
                // Clear the XML viewer when a file is removed
                document.getElementById('xmlViewer').innerHTML = `<div class="row preview">
                    <div class="col-12 d-flex justify-content-center align-items-center">
                        <h3 class="text-white">XML File Preview</h3>
                    </div>
                </div>`;
                closeStationModal();
            }
        }
    });

    function displayXML(xmlString) {
        const parser = new DOMParser();
        const xmlDoc = parser.parseFromString(xmlString, 'text/xml');
        const serializer = new XMLSerializer();
        const formattedXML = serializer.serializeToString(xmlDoc);
        document.getElementById('xmlViewer').innerHTML = `<pre style="color: #fff;">${escapeHTML(formattedXML)}</pre>`;
    }

    function escapeHTML(str) {
        return str.replace(/[&<>'"]/g, function (tag) {
            const charsToReplace = {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                "'": '&#39;',
                '"': '&quot;'
            };
            return charsToReplace[tag] || tag;
        });
    }
});


function ResetFusion() {
    document.getElementById('xmlViewer').innerHTML = `<div class="row preview">
        <div class="col-12 d-flex justify-content-center align-items-center">
            <h3 class="text-white">XML File Preview</h3>
        </div>
    </div>`;
    pond.removeFiles();
}

function openStationModal(name) {
    const station_code = name.split('.')[0].split('-')[1].slice(0, 6);
    console.log(parseInt(station_code));
    $.ajax({
        url: "/adminpanal/station/check/station/data/api/",
        method: "GET",
        dataType: "json",
        data: {
            'station_code': parseInt(station_code),
        },
        success: function (t) {
            console.log(t);
            if (t.status == 'not_found') {
                swal("Sorry!", "You have to configure a fusion first.", {
                    icon: "error",
                    buttons: false,
                    timer: 3000
                });
            }
            if (t.status == 'exists') {
                swal("Submittion Error!", "Sorry, The station data already exists.", {
                    icon: "error",
                    buttons: false,
                    timer: 3000
                });
            }
            if (t.status == 'found') {
                // swal("Thank you", "The fusion excel sheet has submitted successfully.", {
                //     icon: "success",
                //     buttons: false,
                //     timer: 3000
                // });
                document.getElementById('uf_station_code').value = t.data.station_code;
                document.getElementById('uf_station_name').value = t.data.station_name;
                document.getElementById('uf_fusion_ip').value = t.data.ip;
                document.getElementById('uf_fusion_port').value = t.data.port;
                document.getElementById('confirmStationFile').removeAttribute('disabled');
            }
        },
    });
}

function closeStationModal() {
    document.getElementById('uf_station_code').value = '';
    document.getElementById('uf_station_name').value = '';
    document.getElementById('uf_fusion_ip').value = '';
    document.getElementById('uf_fusion_port').value = '';
    $('#uf_central_area').closest('.form-group').removeClass('has-error');
    $('#uf_governorate').closest('.form-group').removeClass('has-error');
    $('#uf_long').closest('.form-group').removeClass('has-error');
    $('#uf_lat').closest('.form-group').removeClass('has-error');
    document.getElementById('confirmStationFile').setAttribute('disabled', 'true');
}

document.getElementById('skipStation').addEventListener('click', () => {
    var uf_station_code = document.getElementById('uf_station_code');
    var uf_station_name = document.getElementById('uf_station_name');
    var uf_fusion_ip = document.getElementById('uf_fusion_ip');
    var uf_fusion_port = document.getElementById('uf_fusion_port');
    var uf_central_area = document.getElementById('uf_central_area');
    var uf_governorate = document.getElementById('uf_governorate');
    var uf_long = document.getElementById('uf_long');
    var uf_lat = document.getElementById('uf_lat');
    var file = pond.getFiles();
    var flag = true;
    if (uf_station_code.value == '') {
        let parentFormGroup = $('#uf_station_code').closest('.form-group');
        parentFormGroup.addClass('has-error');
        swal("Validation Error!", "Please enter a valid station code.", {
            icon: "error",
            buttons: false,
            timer: 3000
        });
        flag = false;
    }
    if (uf_station_name.value == '') {
        let parentFormGroup = $('#uf_station_name').closest('.form-group');
        parentFormGroup.addClass('has-error');
        swal("Validation Error!", "Please enter a valid station name.", {
            icon: "error",
            buttons: false,
            timer: 3000
        });
        flag = false;
    }
    if (uf_fusion_ip.value == '') {
        let parentFormGroup = $('#uf_fusion_ip').closest('.form-group');
        parentFormGroup.addClass('has-error');
        swal("Validation Error!", "Please enter a valid fusion ip.", {
            icon: "error",
            buttons: false,
            timer: 3000
        });
        flag = false;
    }
    if (uf_fusion_port.value == '') {
        let parentFormGroup = $('#uf_fusion_port').closest('.form-group');
        parentFormGroup.addClass('has-error');
        swal("Validation Error!", "Please enter a valid fusion port.", {
            icon: "error",
            buttons: false,
            timer: 3000
        });
        flag = false;
    }

    if(flag){
        // Create FormData object
        const formData = new FormData();
        // Append values to FormData
        formData.append('uf_station_code', uf_station_code.value);
        formData.append('uf_station_name', uf_station_name.value);
        formData.append('uf_fusion_ip', uf_fusion_ip.value);
        formData.append('uf_fusion_port', uf_fusion_port.value);
        formData.append('uf_central_area', uf_central_area.value);
        formData.append('uf_governorate', uf_governorate.value);
        formData.append('uf_long', uf_long.value);
        formData.append('uf_lat', uf_lat.value);
        file.forEach((file, index) => {
            console.log(file.file);
            formData.append(`filepond`, file.file);
        });

        $.ajax({
            url: '/adminpanal/station/add/file/api/',
            type: 'POST',
            dataType: 'json', // Set the content type if sending JSON data
            data: formData, // Convert data to JSON string if sending JSON
            processData: false,  // Don't process the data
            contentType: false,  // Don't set content type
            headers: {
                'X-CSRFToken': document.getElementById('csrfToken').value,
            },
            success: function (response) {
                // Handle the successful response
                console.log(response);
                if (response.status == 'exists') {
                    // $.notify({
                    //     icon: 'fas fa-hdd',
                    //     title: 'Submittion Error',
                    //     message: 'Sorry, The station data already exists.',
                    // }, {
                    //     type: 'danger',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Submittion Error!", "Sorry, The station data already exists.", {
                        icon: "error",
                        buttons: false,
                        timer: 3000
                    });
                }
                if (response.status == 'missing_data') {
                    // $.notify({
                    //     icon: 'fas fa-hdd',
                    //     title: 'Submittion Error',
                    //     message: 'Sorry, missing request data.',
                    // }, {
                    //     type: 'danger',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Submittion Error!", "Sorry, missing request data.", {
                        icon: "error",
                        buttons: false,
                        timer: 3000
                    });
                }
                if (response.status == 'added') {
                    // $.notify({
                    //     icon: 'fas fa-hdd',
                    //     title: 'Submittion Successfully',
                    //     message: 'The fusion has been submitted successfully.',
                    // }, {
                    //     type: 'success',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Submittion Successfully", "The Station has been submitted successfully.", {
                        icon: "success",
                        buttons: false,
                        timer: 3000
                    });
                    document.getElementById("reset").click();
                    getAllFusions();
                    getAllStations();
                }
                resetUFStation();
            }
        });
    }
});


document.getElementById('saveStationChanges').addEventListener('click', () => {
    var uf_station_code = document.getElementById('uf_station_code');
    var uf_station_name = document.getElementById('uf_station_name');
    var uf_fusion_ip = document.getElementById('uf_fusion_ip');
    var uf_fusion_port = document.getElementById('uf_fusion_port');
    var uf_central_area = document.getElementById('uf_central_area');
    var uf_governorate = document.getElementById('uf_governorate');
    var uf_long = document.getElementById('uf_long');
    var uf_lat = document.getElementById('uf_lat');
    var file = pond.getFiles();
    var flag = true;
    var fields = ``;
    if (uf_station_code.value == '') {
        let parentFormGroup = $('#uf_station_code').closest('.form-group');
        parentFormGroup.addClass('has-error');
        // swal("Validation Error!", "Please enter a valid station code.", {
        //     icon: "error",
        //     buttons: false,
        //     timer: 3000
        // });
        fields += `<div class="card mb-1 py-2 bg-danger text-white col-12">Station Code</div>`;
        flag = false;
    }
    if (uf_station_name.value == '') {
        let parentFormGroup = $('#uf_station_name').closest('.form-group');
        parentFormGroup.addClass('has-error');
        // swal("Validation Error!", "Please enter a valid station name.", {
        //     icon: "error",
        //     buttons: false,
        //     timer: 3000
        // });
        fields += `<div class="card mb-1 py-2 bg-danger text-white col-12">Station Name</div>`;
        flag = false;
    }
    if (uf_fusion_ip.value == '') {
        let parentFormGroup = $('#uf_fusion_ip').closest('.form-group');
        parentFormGroup.addClass('has-error');
        // swal("Validation Error!", "Please enter a valid fusion ip.", {
        //     icon: "error",
        //     buttons: false,
        //     timer: 3000
        // });
        fields += `<div class="card mb-1 py-2 bg-danger text-white col-12">Fusion IP</div>`;
        flag = false;
    }
    if (uf_fusion_port.value == '') {
        let parentFormGroup = $('#uf_fusion_port').closest('.form-group');
        parentFormGroup.addClass('has-error');
        // swal("Validation Error!", "Please enter a valid fusion port.", {
        //     icon: "error",
        //     buttons: false,
        //     timer: 3000
        // });
        fields += `<div class="card mb-1 py-2 bg-danger text-white col-12">Fusion Port</div>`;
        flag = false;
    }
    if (uf_central_area.value == '') {
        let parentFormGroup = $('#uf_central_area').closest('.form-group');
        parentFormGroup.addClass('has-error');
        // swal("Validation Error!", "Please choose a valid central area.", {
        //     icon: "error",
        //     buttons: false,
        //     timer: 3000
        // });
        fields += `<div class="card mb-1 py-2 bg-danger text-white col-12">Central Area</div>`;
        flag = false;
    }
    if (uf_governorate.value == '') {
        let parentFormGroup = $('#uf_governorate').closest('.form-group');
        parentFormGroup.addClass('has-error');
        // swal("Validation Error!", "Please choose a valid governorate.", {
        //     icon: "error",
        //     buttons: false,
        //     timer: 3000
        // });
        fields += `<div class="card mb-1 py-2 bg-danger text-white col-12">Governorate</div>`;
        flag = false;
    }
    if (uf_long.value == '') {
        let parentFormGroup = $('#uf_long').closest('.form-group');
        parentFormGroup.addClass('has-error');
        // swal("Validation Error!", "Please enter a valid longitude.", {
        //     icon: "error",
        //     buttons: false,
        //     timer: 3000
        // });
        fields += `<div class="card mb-1 py-2 bg-danger text-white col-12">Longitude</div>`;
        flag = false;
    }
    if (uf_lat.value == '') {
        let parentFormGroup = $('#uf_lat').closest('.form-group');
        parentFormGroup.addClass('has-error');
        // swal("Validation Error!", "Please enter a valid latitude.", {
        //     icon: "error",
        //     buttons: false,
        //     timer: 3000
        // });
        fields += `<div class="card mb-1 py-2 bg-danger text-white col-12">Latitude</div>`;
        flag = false;
    }

    if(!flag){
        swal({
            title: "Required Fields!",
            content: {
                element: "div",
                attributes: {
                    innerHTML: fields,
                    className:"row" // Insert the concatenated HTML string
                },
            },
            icon: "error",
            buttons: false,
            timer: 3000
        });
    }else {
        // Create FormData object
        const formData = new FormData();
        // Append values to FormData
        formData.append('uf_station_code', uf_station_code.value);
        formData.append('uf_station_name', uf_station_name.value);
        formData.append('uf_fusion_ip', uf_fusion_ip.value);
        formData.append('uf_fusion_port', uf_fusion_port.value);
        formData.append('uf_central_area', uf_central_area.value);
        formData.append('uf_governorate', uf_governorate.value);
        formData.append('uf_long', uf_long.value);
        formData.append('uf_lat', uf_lat.value);
        file.forEach((file, index) => {
            console.log(file.file);
            formData.append(`filepond`, file.file);
        });

        $.ajax({
            url: '/adminpanal/station/add/file/api/',
            type: 'POST',
            dataType: 'json', // Set the content type if sending JSON data
            data: formData, // Convert data to JSON string if sending JSON
            processData: false,  // Don't process the data
            contentType: false,  // Don't set content type
            headers: {
                'X-CSRFToken': document.getElementById('csrfToken').value,
            },
            success: function (response) {
                // Handle the successful response
                console.log(response);
                if (response.status == 'exists') {
                    // $.notify({
                    //     icon: 'fas fa-hdd',
                    //     title: 'Submittion Error',
                    //     message: 'Sorry, The station data already exists.',
                    // }, {
                    //     type: 'danger',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Submittion Error!", "Sorry, The station data already exists.", {
                        icon: "error",
                        buttons: false,
                        timer: 3000
                    });
                }
                if (response.status == 'missing_data') {
                    // $.notify({
                    //     icon: 'fas fa-hdd',
                    //     title: 'Submittion Error',
                    //     message: 'Sorry, missing request data.',
                    // }, {
                    //     type: 'danger',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Submittion Error!", "Sorry, missing request data.", {
                        icon: "error",
                        buttons: false,
                        timer: 3000
                    });
                }
                if (response.status == 'added') {
                    // $.notify({
                    //     icon: 'fas fa-hdd',
                    //     title: 'Submittion Successfully',
                    //     message: 'The fusion has been submitted successfully.',
                    // }, {
                    //     type: 'success',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    $('#submitStationFileModal').modal('hide');
                    swal("Submittion Successfully", "The Station has been submitted successfully.", {
                        icon: "success",
                        buttons: false,
                        timer: 3000
                    });
                    document.getElementById("reset").click();
                    getAllFusions();
                    getAllStations();
                }
                resetUFStation();
            }
        });
    }
});


function resetUFStation(){
    document.getElementById('uf_station_code').value = '';
    document.getElementById('uf_station_code').setAttribute('readonly', 'true');
    document.getElementById('uf_station_name').value = '';
    document.getElementById('uf_station_name').setAttribute('readonly', 'true');
    document.getElementById('uf_fusion_ip').value = '';
    document.getElementById('uf_fusion_ip').setAttribute('readonly', 'true');
    document.getElementById('uf_fusion_port').value = '';
    document.getElementById('uf_fusion_port').setAttribute('readonly', 'true');
    $('#uf_central_area').selectpicker('val', '');
    $('#uf_central_area').selectpicker('refresh');
    $('#uf_governorate').innerHTML = '<option value="" selected disabled>Choose governorate...</option>';
    $('#uf_governorate').prop("disabled", true);
    $('#uf_governorate').selectpicker('val', '');
    $('#uf_governorate').selectpicker('refresh');
    document.getElementById('uf_long').value = '';
    document.getElementById('uf_lat').value = '';
    document.getElementById('confirmStationFile').setAttribute('disabled', 'true');
    ResetFusion();
}

document.getElementById('submitStation').addEventListener('click', () => {
    var station_codes = document.getElementById('station_codes');
    var station_name = document.getElementById('station_name');
    var fusion_ip = document.getElementById('fusion_ip');
    var fusion_port = document.getElementById('fusion_port');
    var central_area = document.getElementById('central_area');
    var governorate = document.getElementById('governorate');
    var long = document.getElementById('long');
    var lat = document.getElementById('lat');
    var flag = true;

    if (station_codes.value == '') {
        // product_num.classList.add('bg-danger', 'text-white');
        $.notify({
            icon: 'fas fa-hashtag',
            title: 'Validation Error',
            message: 'Please choose a valid station code.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    } else {
        if (station_name.value == '') {
            // product_name.classList.add('bg-danger', 'text-white');
            $.notify({
                icon: 'fas fa-pen',
                title: 'Validation Error',
                message: 'Please enter a valid station name.',
            }, {
                type: 'danger',
                placement: {
                    from: "top",
                    align: "right"
                },
                time: 1000,
            });
            flag = false;
        }
        if (fusion_ip.value == '') {
            // product_price.classList.add('bg-danger', 'text-white');
            $.notify({
                icon: 'fas fa-wifi',
                title: 'Validation Error',
                message: 'Please enter a valid fusion ip.',
            }, {
                type: 'danger',
                placement: {
                    from: "top",
                    align: "right"
                },
                time: 1000,
            });
            flag = false;
        }
        if (fusion_port.value == '') {
            // product_price.classList.add('bg-danger', 'text-white');
            $.notify({
                icon: 'fas fa-ethernet',
                title: 'Validation Error',
                message: 'Please enter a valid fusion port.',
            }, {
                type: 'danger',
                placement: {
                    from: "top",
                    align: "right"
                },
                time: 1000,
            });
            flag = false;
        }
    }

    if (flag) {
        // Create FormData object
        const formData = new FormData();
        // Append values to FormData
        formData.append('station_codes', station_codes.value);
        formData.append('station_name', station_name.value);
        formData.append('fusion_ip', fusion_ip.value);
        formData.append('fusion_port', fusion_port.value);
        formData.append('central_area', central_area.value);
        formData.append('governorate', governorate.value);
        formData.append('long', long.value);
        formData.append('lat', lat.value);

        $.ajax({
            url: '/adminpanal/station/add/api/',
            type: 'POST',
            dataType: 'json', // Set the content type if sending JSON data
            data: formData, // Convert data to JSON string if sending JSON
            processData: false,  // Don't process the data
            contentType: false,  // Don't set content type
            headers: {
                'X-CSRFToken': document.getElementById('csrfToken').value,
            },
            success: function (response) {
                // Handle the successful response
                console.log(response);
                if (response.status == 'exists') {
                    // $.notify({
                    //     icon: 'fas fa-hdd',
                    //     title: 'Submittion Error',
                    //     message: 'Sorry, The station data already exists.',
                    // }, {
                    //     type: 'danger',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Submittion Error!", "Sorry, The station data already exists.", {
                        icon: "error",
                        buttons: false,
                        timer: 3000
                    });
                }
                if (response.status == 'missing_data') {
                    // $.notify({
                    //     icon: 'fas fa-hdd',
                    //     title: 'Submittion Error',
                    //     message: 'Sorry, missing request data.',
                    // }, {
                    //     type: 'danger',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Submittion Error!", "Sorry, missing request data.", {
                        icon: "error",
                        buttons: false,
                        timer: 3000
                    });
                }
                if (response.status == 'added') {
                    // $.notify({
                    //     icon: 'fas fa-hdd',
                    //     title: 'Submittion Successfully',
                    //     message: 'The fusion has been submitted successfully.',
                    // }, {
                    //     type: 'success',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Submittion Successfully", "The Station has been submitted successfully.", {
                        icon: "success",
                        buttons: false,
                        timer: 3000
                    });
                    document.getElementById("reset").click();
                    getAllFusions();
                    getAllStations();
                }
                document.getElementById('resetStation').click();
            }
        });
    }
});

document.getElementById('resetStation').addEventListener('click', () => {
    $('#station_codes').selectpicker('val', '');
    document.getElementById('station_name').value = '';
    document.getElementById('station_name').setAttribute('readonly', 'true');
    document.getElementById('fusion_ip').value = '';
    document.getElementById('fusion_ip').setAttribute('readonly', 'true');
    document.getElementById('fusion_port').value = '';
    document.getElementById('fusion_port').setAttribute('readonly', 'true');
    $('#central_area').selectpicker('val', '');
    $('#central_area').selectpicker('refresh');
    $('#governorate').innerHTML = '<option value="" selected disabled>Choose governorate...</option>';
    $('#governorate').prop("disabled", true);
    $('#governorate').selectpicker('val', '');
    $('#governorate').selectpicker('refresh');
    document.getElementById('long').value = '';
    document.getElementById('lat').value = '';
});

//define column header menu as column visibility toggle
var headerMenu = function () {
    var menu = [];
    var columns = this.getColumns();

    for (let column of columns) {

        //create checkbox element using font awesome icons
        let icon = document.createElement("i");
        icon.classList.add("fas");
        icon.classList.add(column.isVisible() ? "fa-check-square" : "fa-square");

        //build label
        let label = document.createElement("span");
        let title = document.createElement("span");

        title.textContent = " " + column.getDefinition().title;

        label.appendChild(icon);
        label.appendChild(title);

        //create menu item
        menu.push({
            label: label,
            action: function (e) {
                //prevent menu closing
                e.stopPropagation();

                //toggle current column visibility
                column.toggle();

                //change menu item icon
                if (column.isVisible()) {
                    icon.classList.remove("fa-square");
                    icon.classList.add("fa-check-square");
                } else {
                    icon.classList.remove("fa-check-square");
                    icon.classList.add("fa-square");
                }
            }
        });
    }

    return menu;
};

//Define variables for input elements
var fieldSEl = document.getElementById("sort_field");
var dirEl = document.getElementById("sort_direction");

//Define variables for input elements
var fieldEl = document.getElementById("filter_field");
var typeEl = document.getElementById("filter_type");
var valueEl = document.getElementById("filter_value");


//Trigger setFilter function with correct parameters
function updateFilter() {
    var filterVal = fieldEl.options[fieldEl.selectedIndex].value;
    var typeVal = typeEl.options[typeEl.selectedIndex].value;

    var filter = filterVal;

    if (filterVal) {
        table.setFilter(filter, typeVal, valueEl.value);
    }
}

//Update filters on value change
document.getElementById("filter_field").addEventListener("change", updateFilter);
document.getElementById("filter_type").addEventListener("change", updateFilter);
document.getElementById("filter_value").addEventListener("keyup", updateFilter);

//Clear filters on "Clear Filters" button click
document.getElementById("filter_clear").addEventListener("click", function () {
    fieldEl.value = "";
    typeEl.value = "";
    valueEl.value = "";

    table.clearFilter();
});

// Define column configurations with headerMenu
function defaultColumns() {
    return [
        { title: "ID", field: "id", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
        { title: "Station Code", field: "station_code", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
        { title: "Station Name", field: "station_name", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
        { title: "Fusion IP", field: "ip", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
        { title: "Fusion Port", field: "port", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
        { title: "Longitude", field: "long", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
        { title: "Latitude", field: "lat", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
        {
            title: "Last Connection", field: "last_connection", hozAlign: "start", sorter: "datetime", sorterParams: {
                format: "yyyy-MM-dd HH:mm:ss",
                alignEmptyValues: "top",
            }, headerMenu: headerMenu
        },
        { title: "Governorate", field: "governorate", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
        { title: "Central Area", field: "central_area", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
        {
            title: "Timestamp", field: "timestamp", hozAlign: "start", sorter: "datetime", sorterParams: {
                format: "yyyy-MM-dd HH:mm:ss",
                alignEmptyValues: "top",
            }, headerMenu: headerMenu
        },
    ];
}

// Initial Table Configuration Function
function createTable() {
    return new Tabulator("#station_table", {
        layout: "fitColumns",          // Fit columns to the table width
        responsiveLayout: "hide",       // Hide columns that don’t fit
        // renderHorizontal:"virtual",
        height: window.innerHeight / 2,
        // maxHeight: window.innerHeight / 2,
        printAsHtml: true,
        printStyled: true,
        textDirection: "ltr",
        printHeader: `
        <div class="row mt-4 mb-4">
            <div class="col-12 d-flex justify-content-center align-items-center">
                <h1>Stations Table</h1>
            </div>
        </div>
        <hr>
        `,
        printFooter: `
        <div class="row mt-4">
            <div class="col-12 d-flex justify-content-center align-items-center">
                <img src='/static/img/gts-logo.png' alt='gts-logo' style="width: 50%;height: 100%;" />
            </div>
        </div>
        `,
        ajaxURL: "http://127.0.0.1:8000/adminpanal/station/view/api/",
        ajaxParams: { page: 1, size: 10 },
        progressiveLoad: "scroll",
        placeholder: "No Stations Data",
        selectableRows: true,
        paginationSize: 10,
        columnDefaults: {
            tooltip: true,
        },
        langs: {
            "ar-eg": {
                "columns": {
                    "id": "مسلسل",
                    "station_code": "كود المحطة",
                    "station_name": "اسم المحطة",
                    "ip": "العنوان",
                    "port": "المنفذ",
                    "long": "خط الطول",
                    "lat": "خط العرض",
                    "last_connection": "اخر اتصال",
                    "governorate": "المحافظة",
                    "central_area": "المنطقة المركزية",
                    "timestamp": "تاريخ الانشاء",
                },
            }
        },
        columns: defaultColumns(),
    });
}

var table = createTable();

// var table = new Tabulator("#product_table", {
//     layout: "fitColumns",          // Fit columns to the table width
//     responsiveLayout: "hide",       // Hide columns that don’t fit
//     height: window.innerHeight / 2,
//     printAsHtml: true,
//     printStyled: true,
//     // autoColumns:true,
//     // printRowRange: "all",
//     // textDirection: "rtl",
//     printHeader: `
//     <div class="row mt-4 mb-4">
//         <div class="col-12 d-flex justify-content-center align-items-center">
//             <h1>Products Table</h1>
//         </div>
//     </div>
//     <hr>
//     `,
//     printFooter: `
//     <div class="row mt-4">
//         <div class="col-12 d-flex justify-content-center align-items-center">
//             <img src='/static/img/gts-logo.png' alt='gts-logo' style="width: 50%;height: 100%;" />
//         </div>
//     </div>
//     `,
//     // clipboard: true,
//     // clipboardPasteAction: "replace",
//     // resizableRows: true,
//     // resizableRowGuide: true,
//     // resizableColumnGuide: true,
//     // movableColumns: true,
//     ajaxURL: "http://127.0.0.1:8000/adminpanal/product/view/api/",
//     ajaxParams: { page: 1, size: 10 },  // Start with page 1 and size 3
//     progressiveLoad: "scroll",      // Enable progressive loading with scroll
//     placeholder: "No Product Data",
//     selectableRows: true, //make rows selectable
//     // addRowPos: "top",
//     // history: true,
//     paginationSize: 10,
//     columnDefaults: {
//         tooltip: true,
//     },
//     langs: {
//         "ar-eg": { //French language definition
//             "columns": {
//                 "id": "مسلسل",
//                 "number": "الرقم",
//                 "name": "الاسم",
//                 "price": "السعر",
//                 "timestamp": "تاريخ الانشاء",
//             },
//         }
//     },
//     columns: [
//         { title: "ID", field: "id", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
//         { title: "Number", field: "number", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
//         { title: "Name", field: "name", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
//         { title: "Price", field: "price", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
//         { title: "Timestamp", field: "timestamp", hozAlign: "start", sorter: "datetime", headerMenu: headerMenu },
//     ],
// });

//Trigger sort when "Trigger Sort" button is clicked
document.getElementById("sort_trigger").addEventListener("click", function () {
    table.setSort(fieldSEl.options[fieldSEl.selectedIndex].value, dirEl.options[dirEl.selectedIndex].value);
});

document.getElementById("sort_reset").addEventListener("click", function () {
    table.setSort("id", "asc");
});

table.on("rowSelectionChanged", function (data, rows) {
    document.getElementById("select_stats").innerHTML = data.length;
});

//select row on "select all" button click
document.getElementById("select_all").addEventListener("click", function () {
    table.selectRow();
});

//deselect row on "deselect all" button click
document.getElementById("deselect_all").addEventListener("click", function () {
    table.deselectRow();
});

//Delete row on "Delete Row" button click
document.getElementById("del_row").addEventListener("click", function () {
    var rowid = document.getElementById('row_delete');
    if (rowid.value == '') {
        $.notify({
            icon: 'fas fa-trash',
            title: 'Validation Error',
            message: 'Please enter a valid row number.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
    } else {
        table.deleteRow(parseInt(rowid.value));
        rowid.value = '';
    }
});

//Clear table on "Empty the table" button click
document.getElementById("clear").addEventListener("click", function () {
    table.clearData()
});

//Reset table contents on "Reset the table" button click
document.getElementById("reset").addEventListener("click", function () {
    // table.setData("http://127.0.0.1:8000/adminpanal/product/view/api/", { page: 1, size: 10 });
    // Destroy current instance of the table
    table.destroy();
    // Recreate table with initial settings
    table = createTable();
});

document.getElementById('download_btn').addEventListener('click', () => {
    var file_name = document.getElementById('file_name');
    var download_type = document.getElementById('download_type');
    var flag = true;
    if (file_name.value == '') {
        $.notify({
            icon: 'fas fa-font',
            title: 'Validation Error',
            message: 'Please enter a valid file name.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (download_type.value == '') {
        $.notify({
            icon: 'fas fa-gear',
            title: 'Validation Error',
            message: 'Please choose a download type.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }

    if (flag) {
        if (download_type.value == 'csv') table.download("csv", `${file_name.value}.csv`);
        if (download_type.value == 'json') table.download("json", `${file_name.value}.json`);
        if (download_type.value == 'xlsx') table.download("xlsx", `${file_name.value}.xlsx`, { sheetName: file_name.value });
        if (download_type.value == 'pdf') {
            table.download("pdf", `${file_name.value}.pdf`, {
                orientation: "portrait", //set page orientation to portrait
                title: "Stations Data", //add title to report
            });
        }
        if (download_type.value == 'html') table.download("html", `${file_name.value}.html`, { style: true });
    }
});

//print button
document.getElementById("print_table").addEventListener("click", function () {
    // Get the selected print range from the dropdown
    var selectedRange = document.getElementById("print_range").value;
    console.log(selectedRange);
    // Update printRowRange on the table instance
    table.options.printRowRange = selectedRange;
    // Print the table using the selected printRowRange
    table.print(false, true);
});


//set locale to French
document.getElementById("lang_arabic").addEventListener("click", function () {
    table.setLocale("ar-eg");
    table.setColumns(defaultColumns());  // Reload columns to apply headerMenu
    // document.getElementById("product_table").setAttribute("dir", "rtl");
});

//set default locale
document.getElementById("lang_default").addEventListener("click", function () {
    table.setLocale("");
    table.setColumns(defaultColumns());  // Reload columns to apply headerMenu
    // document.getElementById("product_table").setAttribute("dir", "ltr");
});

function getAllFusions() {
    $.ajax({
        url: "/adminpanal/station/fusions/code/api/",
        method: "GET",
        dataType: "json",
        data: {},
        success: function (t) {
            console.log(t);
            const select = document.getElementById("station_codes");

            // Clear any existing options (optional)
            select.innerHTML = '<option value="" selected disabled>Choose station code...</option>';

            // Add new options
            t.forEach(fusion => {
                const option = document.createElement("option");
                option.value = fusion.id;
                option.textContent = `${fusion.station_code} - ${fusion.station_name}`;
                select.appendChild(option);
            });

            // Refresh selectpicker to apply changes
            $('#station_codes').selectpicker('refresh');
        },
    });
}


function getAllStations() {
    $.ajax({
        url: "/adminpanal/station/all/api/",
        method: "GET",
        dataType: "json",
        data: {},
        success: function (t) {
            console.log(t);
            const select = document.getElementById("station_edit_list");
            const st_delete_select = document.getElementById("station_list");

            // Clear any existing options (optional)
            select.innerHTML = '<option value="" selected disabled>Choose Station...</option>';
            st_delete_select.innerHTML = '';

            // Add new options
            t.forEach(station => {
                const option1 = document.createElement("option");
                option1.value = station.id;
                option1.textContent = `${station.station_code}`;
                option1.setAttribute("data-subtext", `${station.station_name}`);
                select.appendChild(option1);
                
                const option2 = document.createElement("option");
                option2.value = station.id;
                option2.textContent = `${station.station_code}`;
                option2.setAttribute("data-subtext", `${station.station_name}`);
                st_delete_select.appendChild(option2);
            });

            // Refresh selectpicker to apply changes
            $('#station_edit_list').selectpicker('refresh');
            $('#station_list').selectpicker('refresh');
        },
    });
}

function getCentralAreas() {
    $.ajax({
        url: "/adminpanal/station/centralarea/api/",
        method: "GET",
        dataType: "json",
        data: {},
        success: function (t) {
            console.log(t);
            const select = document.getElementById("central_area");
            const uf_select = document.getElementById("uf_central_area");

            select.innerHTML = '<option value="" selected disabled>Choose central area...</option>';
            uf_select.innerHTML = '<option value="" selected disabled>Choose central area...</option>';

            // Add new options
            t.forEach(ca => {
                const option1 = document.createElement("option");
                option1.value = ca.id;
                option1.textContent = ca.name;
                select.appendChild(option1);

                const option2 = document.createElement("option");
                option2.value = ca.id;
                option2.textContent = ca.name;
                uf_select.appendChild(option2);
            });
            // Refresh selectpicker to apply changes
            $('#central_area').selectpicker('refresh');
            $('#uf_central_area').selectpicker('refresh');
        },
    });
}

document.getElementById("central_area").addEventListener('change', (event) => {
    getGovernorates(event.target.value);
    document.querySelector('#pre_governorate i').className = 'spinner-border';
    document.getElementById("governorate").removeAttribute('disabled');
});


function getGovernorates(ca_id) {
    $.ajax({
        url: "/adminpanal/station/governorate/api/",
        method: "GET",
        dataType: "json",
        data: {
            'central_area_id': ca_id,
        },
        success: function (t) {
            console.log(t);
            const select = document.getElementById("governorate");

            select.innerHTML = '<option value="" selected disabled>Choose governorate...</option>';

            // Add new options
            t.forEach(gov => {
                const option = document.createElement("option");
                option.value = gov.id;
                option.textContent = gov.name;
                select.appendChild(option);
            });
            // Refresh selectpicker to apply changes
            $('#governorate').selectpicker('refresh');
            document.querySelector('#pre_governorate i').className = 'fas fa-map-location-dot';
        },
    });
}


document.getElementById("uf_central_area").addEventListener('change', (event) => {
    getUFGovernorates(event.target.value);
    document.querySelector('#pre_uf_governorate i').className = 'spinner-border';
    document.getElementById("uf_governorate").removeAttribute('disabled');
});


function getUFGovernorates(ca_id) {
    $.ajax({
        url: "/adminpanal/station/governorate/api/",
        method: "GET",
        dataType: "json",
        data: {
            'central_area_id': ca_id,
        },
        success: function (t) {
            console.log(t);
            const select = document.getElementById("uf_governorate");

            select.innerHTML = '<option value="" selected disabled>Choose governorate...</option>';

            // Add new options
            t.forEach(gov => {
                const option = document.createElement("option");
                option.value = gov.id;
                option.textContent = gov.name;
                select.appendChild(option);
            });
            // Refresh selectpicker to apply changes
            $('#uf_governorate').selectpicker('refresh');
            document.querySelector('#pre_uf_governorate i').className = 'fas fa-map-location-dot';
        },
    });
}

document.getElementById("station_codes").addEventListener('change', (event) => {
    document.querySelector('#pre_station_name i').className = 'spinner-border';
    document.querySelector('#pre_fusion_ip i').className = 'spinner-border';
    document.querySelector('#pre_fusion_port i').className = 'spinner-border';
    $.ajax({
        url: "/adminpanal/station/get/station/data/api/",
        method: "GET",
        dataType: "json",
        data: {
            'fusion_id': event.target.value,
        },
        success: function (t) {
            console.log(t);
            document.getElementById('station_name').value = t.station_name;
            document.getElementById('fusion_ip').value = t.ip;
            document.getElementById('fusion_port').value = t.port;
            document.querySelector('#pre_station_name i').className = 'fas fa-pen';
            document.querySelector('#pre_fusion_ip i').className = 'fas fa-wifi';
            document.querySelector('#pre_fusion_port i').className = 'fas fa-ethernet';
        },
    });
});

$(function () {
    getAllFusions();
    getCentralAreas();
    getAllStations();
});


document.getElementById('station_edit_list').addEventListener('change', (event) => {
    console.log(event.target.value);
    document.querySelector('#pre_e_central_area i').className = 'spinner-border';
    document.querySelector('#pre_e_governorate i').className = 'spinner-border';
    document.querySelector('#pre_e_long i').className = 'spinner-border';
    document.querySelector('#pre_e_lat i').className = 'spinner-border';
    $.ajax({
        url: "/adminpanal/station/single/api/",
        method: "GET",
        dataType: "json",
        data: {
            'station_id': event.target.value,
        },
        success: function (t) {
            console.log(t);

            const ca_select = document.getElementById("e_central_area");
            const gov_select = document.getElementById("e_governorate");
            const e_long = document.getElementById("e_long");
            const e_lat = document.getElementById("e_lat");

            ca_select.innerHTML = '<option value="" selected disabled>Choose central area...</option>';
            gov_select.innerHTML = '<option value="" selected disabled>Choose governorate...</option>';

            // Add new options
            t.all_ca.forEach(ca => {
                const option = document.createElement("option");
                option.value = ca.id;
                option.textContent = ca.name;
                if (ca.id == t.central_area){
                    option.setAttribute('selected', 'true');
                }
                ca_select.appendChild(option);
            });
            t.all_gov.forEach(gov => {
                const option = document.createElement("option");
                option.value = gov.id;
                option.textContent = gov.name;
                if (gov.id == t.governorate){
                    option.setAttribute('selected', 'true');
                }
                gov_select.appendChild(option);
            });
            document.getElementById('cur_gov').value = t.governorate;
            
            e_long.value = t.long;
            e_lat.value = t.lat;

            ca_select.removeAttribute('disabled');
            gov_select.removeAttribute('disabled');
            e_long.removeAttribute('disabled');
            e_lat.removeAttribute('disabled');
            
            // Refresh selectpicker to apply changes
            $('#e_central_area').selectpicker('refresh');
            $('#e_governorate').selectpicker('refresh');

            document.querySelector('#pre_e_central_area i').className = 'fas fa-map';
            document.querySelector('#pre_e_governorate i').className = 'fas fa-map-location-dot';
            document.querySelector('#pre_e_long i').className = 'fas fa-location-dot';
            document.querySelector('#pre_e_lat i').className = 'fas fa-location-dot';
        },
    });
});


document.getElementById("e_central_area").addEventListener('change', (event) => {
    getUSGovernorates(event.target.value);
    document.querySelector('#pre_e_governorate i').className = 'spinner-border';
});

function getUSGovernorates(ca_id) {
    $.ajax({
        url: "/adminpanal/station/governorate/api/",
        method: "GET",
        dataType: "json",
        data: {
            'central_area_id': ca_id,
        },
        success: function (t) {
            console.log(t);
            const select = document.getElementById("e_governorate");
            const cur_gov = document.getElementById('cur_gov');

            select.innerHTML = '<option value="" selected disabled>Choose governorate...</option>';

            // Add new options
            t.forEach(gov => {
                const option = document.createElement("option");
                option.value = gov.id;
                option.textContent = gov.name;
                if(gov.id == cur_gov.value){
                    option.setAttribute('selected', 'true');
                }
                select.appendChild(option);
            });
            // Refresh selectpicker to apply changes
            $('#e_governorate').selectpicker('refresh');
            document.querySelector('#pre_e_governorate i').className = 'fas fa-map-location-dot';
        },
    });
}

document.getElementById('submitEditStation').addEventListener('click', () => {
    var station_edit_list = document.getElementById('station_edit_list');
    var e_central_area = document.getElementById('e_central_area');
    var e_governorate = document.getElementById('e_governorate');
    var e_long = document.getElementById('e_long');
    var e_lat = document.getElementById('e_lat');
    var flag = true;
    console.log(station_edit_list.value);
    if (station_edit_list.value == "") {
        $.notify({
            icon: 'fas fa-trash',
            title: 'Validation Error',
            message: 'Please choose a station to edit.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (e_central_area.value == "") {
        $.notify({
            icon: 'fas fa-trash',
            title: 'Validation Error',
            message: 'Please choose a valid central area.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (e_governorate.value == "") {
        $.notify({
            icon: 'fas fa-trash',
            title: 'Validation Error',
            message: 'Please choose a valid governorate.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (e_long.value == "") {
        $.notify({
            icon: 'fas fa-trash',
            title: 'Validation Error',
            message: 'Please enter a valid longitude.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (e_lat.value == "") {
        $.notify({
            icon: 'fas fa-trash',
            title: 'Validation Error',
            message: 'Please enter a valid latitude.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (flag) {
        // Create FormData object
        const formData = new FormData();
        // Append values to FormData
        formData.append('station_id', station_edit_list.value);
        formData.append('e_central_area', e_central_area.value);
        formData.append('e_governorate', e_governorate.value);
        formData.append('e_long', e_long.value);
        formData.append('e_lat', e_lat.value);
        $.ajax({
            url: "/adminpanal/station/edit/api/",
            type: 'POST',
            dataType: "json",
            processData: false,  // Don't process the data
            contentType: false,  // Don't set content type
            data: formData,
            headers: {
                'X-CSRFToken': document.getElementById('csrfToken').value,
            },
            success: function (response) {
                // console.log(t);
                if (response.status == 'exists') {
                    swal("Sorry!", "There is a station with the same long and lat.", {
                        icon: "error",
                        buttons: false,
                        timer: 3000
                    });
                }
                if (response.status == 'error') {
                    swal("Sorry!", "Can't edit the selected station.", {
                        icon: "error",
                        buttons: false,
                        timer: 3000
                    });
                }
                if (response.status == 'updated') {
                    swal("Thank you", "The selected station has been updated successfully.", {
                        icon: "success",
                        buttons: false,
                        timer: 3000
                    });
                    getAllFusions();
                    document.getElementById('resetEditStation').click();
                    document.getElementById("reset").click();
                }
                if (response.status == 'No_Post') {
                    swal("Sorry!", "You have to send a request.", {
                        icon: "error",
                        buttons: false,
                        timer: 3000
                    });
                }
            },
        });
    }
});

document.getElementById('resetEditStation').addEventListener('click', () => {
    $('#station_edit_list').selectpicker('val', '');
    $('#station_edit_list').selectpicker('refresh');

    document.getElementById("e_central_area").innerHTML = '<option value="" selected disabled>Choose central area...</option>';
    $("#e_central_area").selectpicker('val', '');
    document.getElementById("e_central_area").setAttribute('disabled', 'true');
    $("#e_central_area").selectpicker('refresh');
    document.getElementById("e_governorate").innerHTML = '<option value="" selected disabled>Choose governorate...</option>';
    $("#e_governorate").selectpicker('val', '');
    document.getElementById("e_governorate").setAttribute('disabled', 'true');
    $("#e_governorate").selectpicker('refresh');
    document.getElementById("e_long").value = "";
    document.getElementById("e_long").setAttribute('disabled', 'true');
    document.getElementById("e_lat").value = "";
    document.getElementById("e_lat").setAttribute('disabled', 'true');
});


document.getElementById('submitDeleteStation').addEventListener('click', () => {
    var station_select = document.getElementById('station_list');
    var flag = true;
    // Get the selected options as an array of values
    const selectedValues = Array.from(station_select.selectedOptions).map(option => option.value);
    console.log(selectedValues);
    if (selectedValues.length == 0) {
        $.notify({
            icon: 'fas fa-trash',
            title: 'Validation Error',
            message: 'Please choose at least one station to delete.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (flag) {
        // Create FormData object
        const formData = new FormData();
        // Append values to FormData
        // formData.append('f_st_codes', selectedValues);
        selectedValues.forEach((id, index) => {
            formData.append('station_ids', id);
        });
        $.ajax({
            url: "/adminpanal/station/delete/api/",
            type: 'POST',
            dataType: "json",
            processData: false,  // Don't process the data
            contentType: false,  // Don't set content type
            data: formData,
            headers: {
                'X-CSRFToken': document.getElementById('csrfToken').value,
            },
            success: function (response) {
                // if (response.status == 'delete_exists') {
                //     var spans = ``;
                //     if (response.codes) {
                //         response.codes.forEach((code) => {
                //             console.log(code);
                //             spans += `<span class="m-1 col-1">${code}</span>`; // Adding each code inside a span with margin
                //         });
                //     } else {
                //         spans = "No Exists Codes.";
                //     }
                //     swal("Thank you", "The selected fusions has been deleted successfully.", {
                //         icon: "success",
                //         buttons: {
                //             confirm: {
                //                 text: "cannot delete codes!",
                //                 className: "btn btn-success-dark",
                //             },
                //             cancel: {
                //                 visible: true,
                //                 className: "btn btn-danger",
                //             },
                //         },
                //     }).then((exists) => {
                //         if (exists) {
                //             swal({
                //                 title: "Cannot Delete Station Codes!",
                //                 content: {
                //                     element: "div",
                //                     attributes: {
                //                         innerHTML: spans,
                //                         className: "row" // Insert the concatenated HTML string
                //                     },
                //                 },
                //                 icon: "error",
                //                 buttons: {
                //                     confirm: {
                //                         className: "btn btn-danger",
                //                     },
                //                 },
                //             });
                //         } else {
                //             swal.close();
                //         }
                //     });
                // }
                // if (response.status == 'exists') {
                //     swal("Sorry!", "Can't delete the selected fusions, already linked with stations.", {
                //         icon: "error",
                //         buttons: false,
                //         timer: 3000
                //     });
                // }
                if (response.status == 'deleted') {
                    swal("Thank you", "The selected stations has been deleted successfully.", {
                        icon: "success",
                        buttons: false,
                        timer: 3000
                    });
                }
                if (response.status == 'No_Post') {
                    swal("Sorry!", "You have to send a request.", {
                        icon: "error",
                        buttons: false,
                        timer: 3000
                    });
                }
                getAllFusions();
                getAllStations();
                document.getElementById('resetDeleteStation').click();
                document.getElementById("reset").click();
            },
        });
    }
});

document.getElementById('resetDeleteStation').addEventListener('click', () => {
    $('#station_list').selectpicker('val', '');
});





























// let pond;

// document.addEventListener('DOMContentLoaded', () => {
//     // Get a reference to the file input element
//     const inputElement = document.querySelector('.my-pond');
//     FilePond.registerPlugin(
//         FilePondPluginFileEncode,
//         FilePondPluginFileValidateSize,
//     );

//     // Create a FilePond instance
//     pond = FilePond.create(inputElement, {
//         acceptedFileTypes: ['text/xml'],
//         // allowMultiple: true,
//         instantUpload: false,
//         maxFileSize: '1MB', // Set the maximum file size to 5 MB
//         onaddfile: (error, fileItem) => {
//             if (error) {
//                 console.log('FilePond error:', error);
//             } else {
//                 console.log('File added:', fileItem.file);
//                 const file = fileItem.file;
//                 const reader = new FileReader();
//                 reader.onload = function (e) {
//                     const xmlString = e.target.result;
//                     displayXML(xmlString);
//                 };
//                 reader.readAsText(file);
//             }
//         },
//         onremovefile: (error, fileItem) => {
//             if (error) {
//                 console.log('FilePond error:', error);
//             } else {
//                 console.log('File removed:', fileItem.file);
//                 // Clear the XML viewer when a file is removed
//                 document.getElementById('xmlViewer').innerHTML = `<div class="row" style="height: 300px;">
//                                                     <div class="col-12 d-flex justify-content-center align-items-center">
//                                                         <h3 class="text-white">XML File Preview</h3>
//                                                     </div>
//                                                 </div>`;
//             }
//         }
//     });

//     function displayXML(xmlString) {
//         const parser = new DOMParser();
//         const xmlDoc = parser.parseFromString(xmlString, 'text/xml');
//         const serializer = new XMLSerializer();
//         const formattedXML = serializer.serializeToString(xmlDoc);
//         document.getElementById('xmlViewer').innerHTML = `<pre style="color: #fff;">${escapeHTML(formattedXML)}</pre>`;
//     }

//     function escapeHTML(str) {
//         return str.replace(/[&<>'"]/g, function (tag) {
//             const charsToReplace = {
//                 '&': '&amp;',
//                 '<': '&lt;',
//                 '>': '&gt;',
//                 "'": '&#39;',
//                 '"': '&quot;'
//             };
//             return charsToReplace[tag] || tag;
//         });
//     }
// });


// function ResetStation() {
//     document.getElementById('num').classList.remove('bg-danger', 'text-white');
//     document.getElementById('name').classList.remove('bg-danger', 'text-white');
//     document.getElementById('fusion_ip').classList.remove('bg-danger', 'text-white');
//     document.getElementById('fusion_port').classList.remove('bg-danger', 'text-white');
//     document.getElementById('long').classList.remove('bg-danger', 'text-white');
//     document.getElementById('lat').classList.remove('bg-danger', 'text-white');
//     document.getElementById('central_area').classList.remove('bg-danger', 'text-white');
//     document.getElementById('governorate').classList.remove('bg-danger', 'text-white');
//     // $('.filepond--drop-label').removeClass('bg-danger text-white');


//     document.getElementById('fusion_ip').removeAttribute('disabled');
//     document.getElementById('fusion_port').removeAttribute('disabled');
//     document.getElementById('load_btn').removeAttribute('disabled');

//     document.getElementById('num').value = '';
//     document.getElementById('name').value = '';
//     document.getElementById('fusion_ip').value = '';
//     document.getElementById('fusion_port').value = '';
//     document.getElementById('long').value = '';
//     document.getElementById('lat').value = '';
//     document.getElementById('central_area').value = '';
//     document.getElementById('governorate').value = '';
//     document.getElementById('xmlViewer').innerHTML = `<div class="row" style="height: 300px;">
//         <div class="col-12 d-flex justify-content-center align-items-center">
//             <h3 class="text-white">XML File Preview</h3>
//         </div>
//     </div>`;
//     pond.removeFiles();
// }


// function SubmitStation() {
//     var num = document.getElementById('num');
//     var name = document.getElementById('name');
//     var fusion_ip = document.getElementById('fusion_ip');
//     var fusion_port = document.getElementById('fusion_port');
//     var long = document.getElementById('long');
//     var lat = document.getElementById('lat');
//     var central_area = document.getElementById('central_area');
//     var governorate = document.getElementById('governorate');
//     var files = pond.getFiles();
//     var flag = true;
//     if (!num.value) {
//         num.classList.add('bg-danger', 'text-white');
//         flag = false;
//     } else {
//         num.classList.remove('bg-danger', 'text-white');
//         flag = true;
//     }
//     if (!name.value) {
//         name.classList.add('bg-danger', 'text-white');
//         flag = false;
//     } else {
//         name.classList.remove('bg-danger', 'text-white');
//         flag = true;
//     }
//     if (!fusion_ip.value) {
//         fusion_ip.classList.add('bg-danger', 'text-white');
//         flag = false;

//     } else {
//         fusion_ip.classList.remove('bg-danger', 'text-white');
//         flag = true;
//     }
//     if (!fusion_port.value) {
//         fusion_port.classList.add('bg-danger', 'text-white');
//         flag = false;
//     }
//     else {
//         fusion_port.classList.remove('bg-danger', 'text-white');
//         flag = true;
//     }
//     if (!long.value) {
//         long.classList.add('bg-danger', 'text-white');
//         flag = false;
//     }
//     else {
//         long.classList.remove('bg-danger', 'text-white');
//         flag = true;
//     }
//     if (!lat.value) {
//         lat.classList.add('bg-danger', 'text-white');
//         flag = false;
//     }
//     else {
//         lat.classList.remove('bg-danger', 'text-white');
//         flag = true;
//     }
//     if (!central_area.value) {
//         central_area.classList.add('bg-danger', 'text-white');
//         flag = false;
//     }
//     else {
//         central_area.classList.remove('bg-danger', 'text-white');
//         flag = true;
//     }
//     if (!governorate.value) {
//         governorate.classList.add('bg-danger', 'text-white');
//         flag = false;
//     }
//     else {
//         governorate.classList.remove('bg-danger', 'text-white');
//         flag = true;
//     }
//     // if (files.length <= 0) {
//     //     $('.filepond--drop-label').addClass('bg-danger text-white');
//     //     flag = false;
//     // }
//     // else {
//     //     $('.filepond--drop-label').removeClass('bg-danger text-white');
//     //     flag = true;
//     // }

//     if (flag) {
//         // Create FormData object
//         const formData = new FormData();
//         // Append values to FormData
//         formData.append('num', num.value);
//         formData.append('name', name.value);
//         formData.append('fusion_ip', fusion_ip.value);
//         formData.append('fusion_port', fusion_port.value);
//         formData.append('long', long.value);
//         formData.append('lat', lat.value);
//         formData.append('central_area', central_area.value);
//         formData.append('governorate', governorate.value);
//         // Append files to FormData
//         files.forEach((file, index) => {
//             console.log(file.file);
//             formData.append(`filepond`, file.file);
//         });

//         $.ajax({
//             url: '/adminpanal/station/add/',
//             type: 'POST',
//             dataType: 'json', // Set the content type if sending JSON data
//             data: formData, // Convert data to JSON string if sending JSON
//             processData: false,  // Don't process the data
//             contentType: false,  // Don't set content type
//             headers: {
//                 'X-CSRFToken': document.getElementById('csrfToken').value,
//             },
//             success: function (response) {
//                 // Handle the successful response
//                 console.log(response);
//                 if (response.status == 'added') {
//                     ResetStation();
//                     document.getElementById('success_msg').classList.remove('d-none');
//                     setTimeout(() => {
//                         document.getElementById('success_msg').classList.add('d-none');
//                     }, 2000);
//                 }
//                 if (response.status == 'exists') {
//                     ResetStation();
//                     document.getElementById('error_msg').classList.remove('d-none');
//                     setTimeout(() => {
//                         document.getElementById('error_msg').classList.add('d-none');
//                     }, 2000);
//                 }
//             }
//         });
//     }
// }


// function getStationFusion(){
//     var station_num = document.getElementById('num');
//     if(station_num.value == ''){
//         station_num.classList.add('bg-danger', 'text-white');
//         setTimeout(()=>{
//             station_num.classList.remove('bg-danger', 'text-white');
//         },500);
//     }else{
//         $.ajax({
//             url: "/adminpanal/station/add/fusion/api/",
//             method: "GET",
//             dataType: "json",
//             data: {
//                 'station_num': station_num.value,
//             },
//             success: function (t) {
//                 console.log(t);
//                 var fusion_ip = document.getElementById('fusion_ip');
//                 var fusion_port = document.getElementById('fusion_port');
//                 var load_btn = document.getElementById('load_btn');
//                 if (t.status == 'found'){
//                     fusion_ip.value = t.ip;
//                     fusion_port.value = t.port;
//                     fusion_ip.setAttribute('disabled', 'true');
//                     fusion_port.setAttribute('disabled', 'true');
//                     load_btn.setAttribute('disabled', 'true');
//                 }else{
//                     fusion_ip.value = 'IP Not Found';
//                     fusion_port.value = 'Port Not Found';
//                     fusion_ip.removeAttribute('disabled');
//                     fusion_port.removeAttribute('disabled');
//                     fusion_ip.classList.add('bg-danger', 'text-white');
//                     fusion_port.classList.add('bg-danger', 'text-white');
//                     setTimeout(()=>{
//                         fusion_ip.value = '';
//                         fusion_port.value = '';
//                         fusion_ip.classList.remove('bg-danger', 'text-white');
//                         fusion_port.classList.remove('bg-danger', 'text-white');
//                     },2000);
//                 }
//             },
//         });
//     }
// }

// document.getElementById('num').addEventListener('keyup', (e)=>{
//     if(e.target.value == ''){
//         document.getElementById('load_btn').removeAttribute('disabled');
//         document.getElementById('fusion_ip').value = '';
//         document.getElementById('fusion_port').value = '';
//         document.getElementById('fusion_ip').removeAttribute('disabled');
//         document.getElementById('fusion_port').removeAttribute('disabled');
//     }
// });