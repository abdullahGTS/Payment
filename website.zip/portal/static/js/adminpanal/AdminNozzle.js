var current_nozzles = [];
var new_nozzles = [];

document.getElementById('stations_list').addEventListener('change', (event)=>{
    document.getElementById("pumps_list").innerHTML = '<option value="" selected disabled>Choose Pump...</option>';
    $('#pumps_list').attr('disabled', 'true');
    $('#pumps_list').selectpicker('refresh');
    console.log(event.target.value);
    $.ajax({
        url: "/adminpanal/nozzles/stations/single/api/",
        method: "GET",
        dataType: "json",
        data: {
            'station_id': event.target.value,
        },
        success: function (t) {
            console.log(t);
            if(t.status == 'not_exists'){
                swal("Sorry!", "No pumps found in the selected station.", {
                    icon: "error",
                    buttons: false,
                    timer: 2000
                });
            }else{
                const select = document.getElementById("pumps_list");

                // Clear any existing options (optional)
                select.innerHTML = '<option value="" selected disabled>Choose Pump...</option>';

                // Add new options
                t.forEach(pump => {
                    const option = document.createElement("option");
                    option.value = pump.id;
                    option.textContent = pump.number;
                    select.appendChild(option);
                });

                // Refresh selectpicker to apply changes
                $('#pumps_list').removeAttr('disabled');
                $('#pumps_list').selectpicker('refresh');
            }
        },
    });
});

document.getElementById('pumps_list').addEventListener('change', (event)=>{
    current_nozzles = [];
    document.querySelector('#pre_nozzle_number i').className = 'spinner-border';
    console.log(event.target.value);
    $.ajax({
        url: "/adminpanal/nozzles/pumps/single/api/",
        method: "GET",
        dataType: "json",
        data: {
            'pump_id': event.target.value,
            'station_id': document.getElementById('stations_list').value,
        },
        success: function (t) {
            console.log(t);
            if(t.status == 'not_exists'){
                document.getElementById('preview_nozzles_data').innerHTML = '';
                document.getElementById('preview_no_data_msg').classList.remove('d-none');
                document.getElementById('preview_nozzles_data').classList.add('d-none');

                document.getElementById('nozzlesSVG').classList.add('d-none');
                document.getElementById('nozzlesView').classList.remove('d-none');
                document.querySelector('#pre_nozzle_number i').className = 'fas fa-fill-drip';
                document.getElementById('nozzle_number').removeAttribute('disabled');
                document.getElementById('add_nozzle').removeAttribute('disabled');
                $('#products_list').removeAttr('disabled');
                $('#products_list').selectpicker('refresh');

                swal("Sorry!", "No nozzles found in the selected pump.", {
                    icon: "error",
                    buttons: false,
                    timer: 2000
                });
            }else{
                var temp_list = ``;
                t.forEach((nozzle)=>{
                    temp_list += `
                    <div class="col-sm-12 col-md-12">
                        <div class="card card-stats btn-blue-dark card-round mb-3">
                            <div class="card-body">
                                <div class="row align-items-center">
                                    <div class="col-icon">
                                        <div class="icon-big text-center btn-success-dark bubble-shadow-small rounded-3">
                                            <img src="/static/img/nozzle-icon2.png" style="width: 30px;" alt="nozzle-icon">
                                        </div>
                                    </div>
                                    <div class="col col-stats ms-3 ms-sm-0">
                                        <div class="numbers">
                                            <p class="card-category">${nozzle.timestamp}</p>
                                            <h4 class="card-title text-white">${nozzle.nozzle_number}</h4>
                                        </div>
                                    </div>
                                    <div class="col col-stats ms-3 ms-sm-0">
                                        <div class="numbers">
                                            <p class="card-category">Product</p>
                                            <h4 class="card-title text-white">${nozzle.product_name}</h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>`;
                    current_nozzles.push((nozzle.nozzle_number).split(' ')[1]);
                });
                document.getElementById('preview_nozzles_data').innerHTML = temp_list;
                document.getElementById('preview_no_data_msg').classList.add('d-none');
                document.getElementById('preview_nozzles_data').classList.remove('d-none');

                document.getElementById('nozzlesSVG').classList.add('d-none');
                document.getElementById('nozzlesView').classList.remove('d-none');

                document.querySelector('#pre_nozzle_number i').className = 'fas fa-fill-drip';
                document.getElementById('nozzle_number').removeAttribute('disabled');
                document.getElementById('add_nozzle').removeAttribute('disabled');
                $('#products_list').removeAttr('disabled');
                $('#products_list').selectpicker('refresh');
            }
        },
    });
});

document.getElementById('nozzle_number').addEventListener('keydown', function(event) {
    // Check if the "Enter" key was pressed
    if (event.key === 'Enter') {
        // Trigger the button click
        document.getElementById('add_nozzle').click();
    }
});

document.getElementById('add_nozzle').addEventListener('click', ()=>{
    var nozzles_data = document.getElementById('nozzles_data');
    var nozzle_number = document.getElementById('nozzle_number');
    var product_name = document.getElementById('products_list');
    if(nozzle_number.value <= 0 || nozzle_number.value > 100 || nozzle_number.value == ''){
        $.notify({
            icon: 'fas fa-fill-drip',
            title: 'Validation Error',
            message: 'Please enter a valid pump number.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
    }else{
        if(product_name.value == ''){
            $.notify({
                icon: 'fas fa-droplet',
                title: 'Validation Error',
                message: 'Please choose a product.',
            }, {
                type: 'danger',
                placement: {
                    from: "top",
                    align: "right"
                },
                time: 1000,
            });
        }else{
            if(current_nozzles.includes(nozzle_number.value)){
                $.notify({
                    icon: 'fas fa-fill-drip',
                    title: 'Submittion Error!',
                    message: 'Sorry, the nozzle number you trying to add is already exists.',
                }, {
                    type: 'danger',
                    placement: {
                        from: "top",
                        align: "right"
                    },
                    time: 1000,
                });
            }else{
                var selected_product_name = product_name.options[product_name.selectedIndex];
                if(nozzles_data.children.length < 1){
                    nozzles_data.innerHTML = `
                    <div class="col-sm-12 col-md-12" id="temp_nozzle_${nozzle_number.value}">
                        <div class="card card-stats card-round mb-3">
                            <div class="card-body">
                                <div class="row align-items-center">
                                    <div class="col-icon">
                                        <div class="icon-big text-center btn-success-dark bubble-shadow-small rounded-3">
                                            <img src="/static/img/nozzle-icon2.png" style="width: 30px;" alt="nozzle-icon">
                                        </div>
                                    </div>
                                    <div class="col col-stats ms-3 ms-sm-0">
                                        <div class="numbers">
                                            <p class="card-category">Pump</p>
                                            <h4 class="card-title">${nozzle_number.value}</h4>
                                        </div>
                                    </div>
                                    <div class="col col-stats ms-3 ms-sm-0">
                                        <div class="numbers">
                                            <p class="card-category">Product</p>
                                            <h4 class="card-title">${selected_product_name.innerHTML}</h4>
                                        </div>
                                    </div>
                                    <div class="col-icon" style="margin-left: 0px;margin-right: 15px;">
                                        <div class="icon-big text-center bubble-shadow-small">
                                            <i class="fas fa-trash text-danger delete-icon" onclick="deleteNozzle('${nozzle_number.value}')" style="cursor: pointer;"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>`;
                    document.getElementById('no_data_msg').classList.add('d-none');
                    nozzles_data.classList.remove('d-none');
                }else{
                    nozzles_data.innerHTML += `
                    <div class="col-sm-12 col-md-12" id="temp_nozzle_${nozzle_number.value}">
                        <div class="card card-stats card-round mb-3">
                            <div class="card-body">
                                <div class="row align-items-center">
                                    <div class="col-icon">
                                        <div class="icon-big text-center btn-success-dark bubble-shadow-small rounded-3">
                                            <img src="/static/img/nozzle-icon2.png" style="width: 30px;" alt="nozzle-icon">
                                        </div>
                                    </div>
                                    <div class="col col-stats ms-3 ms-sm-0">
                                        <div class="numbers">
                                            <p class="card-category">Pump</p>
                                            <h4 class="card-title">${nozzle_number.value}</h4>
                                        </div>
                                    </div>
                                    <div class="col col-stats ms-3 ms-sm-0">
                                        <div class="numbers">
                                            <p class="card-category">Product</p>
                                            <h4 class="card-title">${selected_product_name.innerHTML}</h4>
                                        </div>
                                    </div>
                                    <div class="col-icon" style="margin-left: 0px;margin-right: 15px;">
                                        <div class="icon-big text-center bubble-shadow-small">
                                            <i class="fas fa-trash text-danger delete-icon" onclick="deleteNozzle('${nozzle_number.value}')" style="cursor: pointer;"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>`;
                }
                current_nozzles.push(nozzle_number.value);
                new_nozzles.push({'nozzle': nozzle_number.value, 'product': selected_product_name.value});
                nozzle_number.value = '';
                nozzle_number.focus();
            }
        }
    }
});

function deleteNozzle(nozzle_number){
    document.getElementById('temp_nozzle_'+nozzle_number).remove();
    var nozzles_data = document.getElementById('nozzles_data');
    if(nozzles_data.children.length < 1){
        document.getElementById('no_data_msg').classList.remove('d-none');
        nozzles_data.classList.add('d-none');
    }
    const index = current_nozzles.indexOf(nozzle_number);
    if (index !== -1) {
        // Remove the element at the found index
        current_nozzles.splice(index, 1);
    }

    const exists = new_nozzles.some(n => n.nozzle == nozzle_number);
    if (exists) {
        console.log(`Nozzle ${nozzle_number} exists.`);
        // Remove the object with nozzle 1
        new_nozzles = new_nozzles.filter(n => n.nozzle !== nozzle_number);
    } else {
        console.log(`Nozzle ${nozzle_number} does not exist.`);
    }
}

document.getElementById('submitNozzles').addEventListener('click', () => {
    var stations_list = document.getElementById('stations_list');
    var pumps_list = document.getElementById('pumps_list');
    var nozzles_data = document.getElementById('nozzles_data');
    var flag = true;

    if (stations_list.value == '') {
        // product_num.classList.add('bg-danger', 'text-white');
        $.notify({
            icon: 'fas fa-industry',
            title: 'Validation Error',
            message: 'Please choose a station.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        if (pumps_list.value == '') {
            // product_num.classList.add('bg-danger', 'text-white');
            $.notify({
                icon: 'fas fa-gas-pump',
                title: 'Validation Error',
                message: 'Please choose a pump.',
            }, {
                type: 'danger',
                placement: {
                    from: "top",
                    align: "right"
                },
                time: 1000,
            });
            flag = false;
        }else{
            if(nozzles_data.children.length < 1){
                // product_num.classList.add('bg-danger', 'text-white');
                $.notify({
                    icon: 'fas fa-gas-pump',
                    title: 'Submittion Error!',
                    message: 'Please enter a nozzle.',
                }, {
                    type: 'danger',
                    placement: {
                        from: "top",
                        align: "right"
                    },
                    time: 1000,
                });
                flag = false;
            }
        }
    }

    if (flag) {
        // Create FormData object
        const formData = new FormData();
        // Append values to FormData
        formData.append('station_id', stations_list.value);
        formData.append('pump_id', pumps_list.value);
        new_nozzles.forEach((pump)=>{
            formData.append('pumps_products', `${pump.nozzle}-${pump.product}`);
        });
        $.ajax({
            url: "/adminpanal/nozzles/add/api/",
            type: 'POST',
            dataType: "json",
            processData: false,  // Don't process the data
            contentType: false,  // Don't set content type
            data: formData,
            headers: {
                'X-CSRFToken': document.getElementById('csrfToken').value,
            },
            success: function (t) {
                // console.log(t);
                if (t.status == 'No Post') {
                    // $.notify({
                    //     icon: 'fas fa-gears',
                    //     title: 'Technical Error',
                    //     message: 'You have to contact with your administrator.',
                    // }, {
                    //     type: 'danger',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Technical Error!", "You have to contact with your administrator.", {
                        icon: "error",
                        buttons: false,
                        timer: 2000
                    });
                }
                if (t.status == 'added') {
                    // $.notify({
                    //     icon: 'fas fa-droplet',
                    //     title: 'Submittion Successfully',
                    //     message: 'The product has been submitted successfully.',
                    // }, {
                    //     type: 'success',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Thank you", "The nozzles has been submitted successfully.", {
                        icon: "success",
                        buttons: false,
                        timer: 2000
                    });
                    document.getElementById('resetNozzles').click();
                    document.getElementById("reset").click();
                }
            },
        });
    }
});

// function submitProduct(){
//     product_num = document.getElementById('product_num');
//     product_name = document.getElementById('product_name');
//     product_price = document.getElementById('product_price');
//     if(product_num.value == ''){
//         product_num.classList.add('bg-danger', 'text-white');
//     }else if(product_name.value == ''){
//         product_name.classList.add('bg-danger', 'text-white');
//     }else if(product_price.value == ''){
//         product_price.classList.add('bg-danger', 'text-white');
//     }else{
//         document.getElementById('miniloader').classList.remove('d-none');
//         $.ajax({
//             url: "/adminpanal/product/add/api/",
//             method: "GET",
//             dataType: "json",
//             data: {
//                 'product_num': product_num.value,
//                 'product_name': product_name.value,
//                 'product_price': product_price.value,
//             },
//             success: function (t) {
//                 console.log(t);
//                 if(t.status == 'exists'){
//                     document.getElementById('error_msg').innerHTML = 'Product Already Exists!';
//                     document.getElementById('error_msg').classList.add('text-danger');
//                     document.getElementById('error_msg').classList.remove('d-none');
//                     document.getElementById('miniloader').classList.add('d-none');
//                     setTimeout(()=>{
//                         document.getElementById('error_msg').innerHTML = '';
//                         document.getElementById('error_msg').classList.remove('text-danger');
//                         document.getElementById('error_msg').classList.add('d-none');
//                     },3000);
//                 }


//                 if(t.status == 'No Get'){
//                     document.getElementById('error_msg').innerHTML = 'Technical Error!';
//                     document.getElementById('error_msg').classList.add('text-danger');
//                     document.getElementById('error_msg').classList.remove('d-none');

//                     setTimeout(()=>{
//                         document.getElementById('error_msg').innerHTML = '';
//                         document.getElementById('error_msg').classList.remove('text-danger');
//                         document.getElementById('error_msg').classList.add('d-none');
//                     },3000);
//                 }


//                 if(t.status == 'added'){
//                     document.getElementById('error_msg').innerHTML = 'Product is added successfully.';
//                     document.getElementById('error_msg').classList.add('text-success');
//                     document.getElementById('error_msg').classList.remove('d-none');

//                     product_num.classList.remove('bg-danger', 'text-white');
//                     product_name.classList.remove('bg-danger', 'text-white');
//                     product_price.classList.remove('bg-danger', 'text-white');
//                     product_num.value = '';
//                     product_name.value = '';
//                     product_price.value = '';

//                     var e = $("#productTbl");
//                     e.bootstrapTable("showLoading");
//                     e.bootstrapTable("append",{
//                         'id':t.id,
//                         'number':t.number,
//                         'name':t.name,
//                         'price':t.price,
//                         'timestamp':t.timestamp,
//                         'actions': `<button class="btn btn-dark w-100" onclick="deleteProduct('${t.id}')">Delete</button>`,
//                     });
//                     e.bootstrapTable("refresh");
//                     e.bootstrapTable("hideLoading");
//                     document.getElementById('miniloader').classList.add('d-none');
//                     document.getElementById('products_num').innerHTML = parseInt(document.getElementById('products_num').innerHTML) + 1;

//                     setTimeout(()=>{
//                         document.getElementById('error_msg').innerHTML = '';
//                         document.getElementById('error_msg').classList.remove('text-danger');
//                         document.getElementById('error_msg').classList.add('d-none');
//                     },3000);
//                 }

//             },
//         });
//     }
// }

document.getElementById('resetNozzles').addEventListener('click', () => {
    $('#stations_list').selectpicker('val', '');
    $('#pumps_list').empty();
    document.getElementById('pumps_list').innerHTML = '<option value="" selected disabled>Choose Pump...</option>';
    $('#pumps_list').selectpicker('val', '');
    $('#pumps_list').attr('disabled', 'true');
    $('#pumps_list').selectpicker('refresh');
    document.getElementById('preview_nozzles_data').innerHTML = '';
    document.getElementById('preview_nozzles_data').classList.add('d-none');
    document.getElementById('preview_no_data_msg').classList.remove('d-none');
    document.getElementById('nozzlesView').classList.add('d-none');
    document.getElementById('nozzlesSVG').classList.remove('d-none');
    document.getElementById('nozzles_data').innerHTML = '';
    document.getElementById('nozzles_data').classList.add('d-none');
    document.getElementById('no_data_msg').classList.remove('d-none');
    document.getElementById('nozzle_number').value = '';
    document.getElementById('nozzle_number').setAttribute('disabled', 'true');
    document.getElementById('add_nozzle').setAttribute('disabled', 'true');
    $('#products_list').selectpicker('val', '');
    $('#products_list').attr('disabled', 'true');
    $('#products_list').selectpicker('refresh');
    current_nozzles = [];
    new_nozzles = [];
});

//define column header menu as column visibility toggle
var headerMenu = function () {
    var menu = [];
    var columns = this.getColumns();

    for (let column of columns) {

        //create checkbox element using font awesome icons
        let icon = document.createElement("i");
        icon.classList.add("fas");
        icon.classList.add(column.isVisible() ? "fa-check-square" : "fa-square");

        //build label
        let label = document.createElement("span");
        let title = document.createElement("span");

        title.textContent = " " + column.getDefinition().title;

        label.appendChild(icon);
        label.appendChild(title);

        //create menu item
        menu.push({
            label: label,
            action: function (e) {
                //prevent menu closing
                e.stopPropagation();

                //toggle current column visibility
                column.toggle();

                //change menu item icon
                if (column.isVisible()) {
                    icon.classList.remove("fa-square");
                    icon.classList.add("fa-check-square");
                } else {
                    icon.classList.remove("fa-check-square");
                    icon.classList.add("fa-square");
                }
            }
        });
    }

    return menu;
};

//Define variables for input elements
var fieldSEl = document.getElementById("sort_field");
var dirEl = document.getElementById("sort_direction");

//Define variables for input elements
var fieldEl = document.getElementById("filter_field");
var typeEl = document.getElementById("filter_type");
var valueEl = document.getElementById("filter_value");


//Trigger setFilter function with correct parameters
function updateFilter() {
    var filterVal = fieldEl.options[fieldEl.selectedIndex].value;
    var typeVal = typeEl.options[typeEl.selectedIndex].value;

    var filter = filterVal;

    if (filterVal) {
        table.setFilter(filter, typeVal, valueEl.value);
    }
}

//Update filters on value change
document.getElementById("filter_field").addEventListener("change", updateFilter);
document.getElementById("filter_type").addEventListener("change", updateFilter);
document.getElementById("filter_value").addEventListener("keyup", updateFilter);

//Clear filters on "Clear Filters" button click
document.getElementById("filter_clear").addEventListener("click", function () {
    fieldEl.value = "";
    typeEl.value = "";
    valueEl.value = "";

    table.clearFilter();
});

// Define column configurations with headerMenu
function defaultColumns() {
    return [
        { title: "ID", field: "id", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
        { title: "Nozzle", field: "nozzle_number", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
        { title: "Product", field: "product_name", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
        { title: "Pump", field: "pump_number", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
        { title: "Station Code", field: "station_code", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
        { title: "Station Name", field: "station_name", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
        {
            title: "Creation Date", field: "timestamp", hozAlign: "start", sorter: "datetime", sorterParams: {
                format: "yyyy-MM-dd HH:mm:ss",
                alignEmptyValues: "top",
            }, headerMenu: headerMenu
        },
    ];
}

// Initial Table Configuration Function
function createTable() {
    return new Tabulator("#nozzles_table", {
        layout: "fitColumns",          // Fit columns to the table width
        responsiveLayout: "hide",       // Hide columns that don’t fit
        height: window.innerHeight / 2,
        printAsHtml: true,
        printStyled: true,
        textDirection: "ltr",
        groupBy: ["station_name", "pump_number", "product_name"],
        groupStartOpen: true,
        groupToggleElement: "header",
        groupHeaderPrint: function(value, count, data, group){
            return value;
        },
        groupHeaderDownload: function(value, count, data, group){
            return value;
        },
        downloadRowRange: "all",
        printHeader: `
        <div class="row mt-4 mb-4">
            <div class="col-12 d-flex justify-content-center align-items-center">
                <h1>Nozzles Table</h1>
            </div>
        </div>
        <hr>`,
        printFooter: `
        <div class="row mt-4">
            <div class="col-12 d-flex justify-content-center align-items-center">
                <img src='/static/img/gts-logo.png' alt='gts-logo' style="width: 50%;height: 100%;" />
            </div>
        </div>
        `,
        ajaxURL: "http://127.0.0.1:8000/adminpanal/nozzles/view/api/",
        ajaxParams: { page: 1, size: 10 },
        progressiveLoad: "scroll",
        placeholder: "No Pumps Data",
        selectableRows: true,
        paginationSize: 10,
        columnDefaults: {
            tooltip: true,
        },
        langs: {
            "ar-eg": {
                "columns": {
                    "id": "مسلسل",
                    "nozzle_number": "رقم الفوهة",
                    "product_name": "اسم المنتج",
                    "pump_number": "رقم المضخة",
                    "station_code": "كود المحطة",
                    "station_name": "اسم المحطة",
                    "timestamp": "تاريخ الانشاء",
                },
            }
        },
        columns: defaultColumns(),
    });
}

var table = createTable();

// var table = new Tabulator("#nozzles_table", {
//     layout: "fitColumns",          // Fit columns to the table width
//     responsiveLayout: "hide",       // Hide columns that don’t fit
//     height: window.innerHeight / 2,
//     printAsHtml: true,
//     printStyled: true,
//     // autoColumns:true,
//     // printRowRange: "all",
//     // textDirection: "rtl",
//     printHeader: `
//     <div class="row mt-4 mb-4">
//         <div class="col-12 d-flex justify-content-center align-items-center">
//             <h1>Products Table</h1>
//         </div>
//     </div>
//     <hr>
//     `,
//     printFooter: `
//     <div class="row mt-4">
//         <div class="col-12 d-flex justify-content-center align-items-center">
//             <img src='/static/img/gts-logo.png' alt='gts-logo' style="width: 50%;height: 100%;" />
//         </div>
//     </div>
//     `,
//     // clipboard: true,
//     // clipboardPasteAction: "replace",
//     // resizableRows: true,
//     // resizableRowGuide: true,
//     // resizableColumnGuide: true,
//     // movableColumns: true,
//     ajaxURL: "http://127.0.0.1:8000/adminpanal/product/view/api/",
//     ajaxParams: { page: 1, size: 10 },  // Start with page 1 and size 3
//     progressiveLoad: "scroll",      // Enable progressive loading with scroll
//     placeholder: "No Product Data",
//     selectableRows: true, //make rows selectable
//     // addRowPos: "top",
//     // history: true,
//     paginationSize: 10,
//     columnDefaults: {
//         tooltip: true,
//     },
//     langs: {
//         "ar-eg": { //French language definition
//             "columns": {
//                 "id": "مسلسل",
//                 "number": "الرقم",
//                 "name": "الاسم",
//                 "price": "السعر",
//                 "timestamp": "تاريخ الانشاء",
//             },
//         }
//     },
//     columns: [
//         { title: "ID", field: "id", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
//         { title: "Number", field: "number", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
//         { title: "Name", field: "name", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
//         { title: "Price", field: "price", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
//         { title: "Timestamp", field: "timestamp", hozAlign: "start", sorter: "datetime", headerMenu: headerMenu },
//     ],
// });

//Trigger sort when "Trigger Sort" button is clicked
document.getElementById("sort_trigger").addEventListener("click", function () {
    table.setSort(fieldSEl.options[fieldSEl.selectedIndex].value, dirEl.options[dirEl.selectedIndex].value);
});

document.getElementById("sort_reset").addEventListener("click", function () {
    table.setSort("id", "asc");
});

table.on("rowSelectionChanged", function (data, rows) {
    document.getElementById("select_stats").innerHTML = data.length;
});

//select row on "select all" button click
document.getElementById("select_all").addEventListener("click", function () {
    table.selectRow();
});

//deselect row on "deselect all" button click
document.getElementById("deselect_all").addEventListener("click", function () {
    table.deselectRow();
});

//Delete row on "Delete Row" button click
document.getElementById("del_row").addEventListener("click", function () {
    var rowid = document.getElementById('row_delete');
    if (rowid.value == '') {
        $.notify({
            icon: 'fas fa-trash',
            title: 'Validation Error',
            message: 'Please enter a valid row number.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
    } else {
        table.deleteRow(parseInt(rowid.value));
        rowid.value = '';
    }
});

//Clear table on "Empty the table" button click
document.getElementById("clear").addEventListener("click", function () {
    table.clearData()
});

//Reset table contents on "Reset the table" button click
document.getElementById("reset").addEventListener("click", function () {
    // table.setData("http://127.0.0.1:8000/adminpanal/product/view/api/", { page: 1, size: 10 });
    // Destroy current instance of the table
    table.destroy();
    // Recreate table with initial settings
    table = createTable();
});

document.getElementById('download_btn').addEventListener('click', () => {
    var file_name = document.getElementById('file_name');
    var download_type = document.getElementById('download_type');
    var flag = true;
    if (file_name.value == '') {
        $.notify({
            icon: 'fas fa-font',
            title: 'Validation Error',
            message: 'Please enter a valid file name.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (download_type.value == '') {
        $.notify({
            icon: 'fas fa-gear',
            title: 'Validation Error',
            message: 'Please choose a download type.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }

    if (flag) {
        if (download_type.value == 'csv') table.download("csv", `${file_name.value}.csv`);
        if (download_type.value == 'json') table.download("json", `${file_name.value}.json`);
        if (download_type.value == 'xlsx') table.download("xlsx", `${file_name.value}.xlsx`, { sheetName: file_name.value });
        if (download_type.value == 'pdf') {
            table.download("pdf", `${file_name.value}.pdf`, {
                orientation: "portrait", //set page orientation to portrait
                title: "Nozzles Data", //add title to report
            });
        }
        if (download_type.value == 'html') table.download("html", `${file_name.value}.html`, { style: true });
    }
});

//print button
document.getElementById("print_table").addEventListener("click", function () {
    // Get the selected print range from the dropdown
    var selectedRange = document.getElementById("print_range").value;
    console.log(selectedRange);
    // Update printRowRange on the table instance
    table.options.printRowRange = selectedRange;
    // Print the table using the selected printRowRange
    table.print(false, true);
});


//set locale to French
document.getElementById("lang_arabic").addEventListener("click", function () {
    table.setLocale("ar-eg");
    table.setColumns(defaultColumns());  // Reload columns to apply headerMenu
    // document.getElementById("nozzles_table").setAttribute("dir", "rtl");
});

//set default locale
document.getElementById("lang_default").addEventListener("click", function () {
    table.setLocale("");
    table.setColumns(defaultColumns());  // Reload columns to apply headerMenu
    // document.getElementById("nozzles_table").setAttribute("dir", "ltr");
});

function getAllStations() {
    $.ajax({
        url: "/adminpanal/nozzles/stations/all/api/",
        method: "GET",
        dataType: "json",
        data: {},
        success: function (t) {
            console.log(t);
            const select = document.getElementById("stations_list");
            const editSelect = document.getElementById("e_stations_list");
            const deleteSelect = document.getElementById("d_stations_list");

            // Clear any existing options (optional)
            select.innerHTML = '<option value="" selected disabled>Choose station...</option>';
            editSelect.innerHTML = '<option value="" selected disabled>Choose station...</option>';
            deleteSelect.innerHTML = '<option value="" selected disabled>Choose station...</option>';

            // Add new options
            t.forEach(station => {
                const option1 = document.createElement("option");
                option1.value = station.id;
                option1.textContent = `${station.station_code} - ${station.station_name}`;
                select.appendChild(option1);

                const option2 = document.createElement("option");
                option2.value = station.id;
                option2.textContent = `${station.station_code} - ${station.station_name}`;
                editSelect.appendChild(option2);

                const option3 = document.createElement("option");
                option3.value = station.id;
                option3.textContent = `${station.station_code} - ${station.station_name}`;
                deleteSelect.appendChild(option3);
            });

            // Refresh selectpicker to apply changes
            $('#stations_list').selectpicker('refresh');
            $('#e_stations_list').selectpicker('refresh');
            $('#d_stations_list').selectpicker('refresh');
        },
    });
}

function getAllProducts() {
    $.ajax({
        url: "/adminpanal/nozzles/products/all/api/",
        method: "GET",
        dataType: "json",
        data: {},
        success: function (t) {
            console.log(t);
            const select = document.getElementById("products_list");
            const editselect = document.getElementById("e_products_list");

            // Clear any existing options (optional)
            select.innerHTML = '<option value="" selected disabled>Choose Product...</option>';
            editselect.innerHTML = '<option value="" selected disabled>Choose Product...</option>';

            // Add new options
            t.forEach(product => {
                const option1 = document.createElement("option");
                option1.value = product.id;
                option1.textContent = product.name;
                option1.setAttribute("data-subtext", `💵 ${product.price} E.L`);
                select.appendChild(option1);
                
                const option2 = document.createElement("option");
                option2.value = product.id;
                option2.textContent = product.name;
                option2.setAttribute("data-subtext", `💵 ${product.price} E.L`);
                editselect.appendChild(option2);
            });

            // Refresh selectpicker to apply changes
            $('#products_list').selectpicker('refresh');
            $('#e_products_list').selectpicker('refresh');
        },
    });
}

$(function () {
    getAllStations();
    getAllProducts();
});


document.getElementById('e_stations_list').addEventListener('change', (event)=>{
    document.querySelector('#pre_e_pumps_list i').className = 'spinner-border';
    document.getElementById("e_pumps_list").innerHTML = '<option value="" selected disabled>Choose Pump...</option>';
    document.getElementById("e_nozzles_list").innerHTML = '<option value="" selected disabled>Choose Nozzle...</option>';
    $('#e_pumps_list').attr('disabled', 'true');
    $('#e_pumps_list').selectpicker('refresh');
    $('#e_nozzles_list').attr('disabled', 'true');
    $('#e_nozzles_list').selectpicker('refresh');
    $('#e_products_list').selectpicker('val', '');
    $('#e_products_list').attr('disabled', 'true');
    $('#e_products_list').selectpicker('refresh');
    console.log(event.target.value);
    $.ajax({
        url: "/adminpanal/nozzles/stations/single/api/",
        method: "GET",
        dataType: "json",
        data: {
            'station_id': event.target.value,
        },
        success: function (t) {
            console.log(t);
            if(t.status == 'not_exists'){
                swal("Sorry!", "No pumps found in the selected station.", {
                    icon: "error",
                    buttons: false,
                    timer: 2000
                });
            }else{
                const select = document.getElementById("e_pumps_list");

                // Clear any existing options (optional)
                select.innerHTML = '<option value="" selected disabled>Choose Pump...</option>';

                // Add new options
                t.forEach(pump => {
                    const option = document.createElement("option");
                    option.value = pump.id;
                    option.textContent = pump.number;
                    select.appendChild(option);
                });

                // Refresh selectpicker to apply changes
                $('#e_pumps_list').removeAttr('disabled');
                $('#e_pumps_list').selectpicker('refresh');
            }
            document.querySelector('#pre_e_pumps_list i').className = 'fas fa-gas-pump';
        },
    });
});

document.getElementById('e_pumps_list').addEventListener('change', (event)=>{
    document.querySelector('#pre_e_nozzles_list i').className = 'spinner-border';
    document.getElementById("e_nozzles_list").innerHTML = '<option value="" selected disabled>Choose Nozzle...</option>';
    $('#e_nozzles_list').attr('disabled', 'true');
    $('#e_nozzles_list').selectpicker('refresh');
    $('#e_products_list').selectpicker('val', '');
    $('#e_products_list').attr('disabled', 'true');
    $('#e_products_list').selectpicker('refresh');
    console.log(event.target.value);
    $.ajax({
        url: "/adminpanal/nozzles/pumps/single/api/",
        method: "GET",
        dataType: "json",
        data: {
            'pump_id': event.target.value,
            'station_id': document.getElementById('e_stations_list').value,
        },
        success: function (t) {
            console.log(t);
            if(t.status == 'not_exists'){
                swal("Sorry!", "No nozzles found in the selected pump.", {
                    icon: "error",
                    buttons: false,
                    timer: 2000
                });
            }else{
                const select = document.getElementById("e_nozzles_list");

                // Clear any existing options (optional)
                select.innerHTML = '<option value="" selected disabled>Choose Nozzle...</option>';

                // Add new options
                t.forEach(nozzle => {
                    const option = document.createElement("option");
                    option.value = nozzle.id;
                    option.id = nozzle.product_number;
                    option.textContent = nozzle.nozzle_number;
                    select.appendChild(option);
                });

                // Refresh selectpicker to apply changes
                $('#e_nozzles_list').removeAttr('disabled');
                $('#e_nozzles_list').selectpicker('refresh');
            }
            document.querySelector('#pre_e_nozzles_list i').className = 'fas fa-fill-drip';
        },
    });
});

document.getElementById('e_nozzles_list').addEventListener('change', (event)=>{
    document.querySelector('#pre_e_products_list i').className = 'spinner-border';
    $('#e_products_list').selectpicker('val', '');
    $('#e_products_list').attr('disabled', 'true');
    $('#e_products_list').selectpicker('refresh');
    var selected_option = event.target.options[event.target.selectedIndex];
    console.log(selected_option.value);
    console.log(selected_option.id);
    
    $('#e_products_list').selectpicker('val', selected_option.id);
    $('#e_products_list').removeAttr('disabled');
    $('#e_products_list').selectpicker('refresh');
    document.querySelector('#pre_e_products_list i').className = 'fas fa-droplet';
});

document.getElementById('submitEditNozzles').addEventListener('click', () => {
    var e_stations_list = document.getElementById('e_stations_list');
    var e_pumps_list = document.getElementById('e_pumps_list');
    var e_nozzles_list = document.getElementById('e_nozzles_list');
    var e_products_list = document.getElementById('e_products_list');
    var flag = true;

    if (e_stations_list.value == '') {
        $.notify({
            icon: 'fas fa-industry',
            title: 'Submission Error!',
            message: 'Please choose a station first!',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        if (e_pumps_list.value == '') {
            $.notify({
                icon: 'fas fa-gas-pump',
                title: 'Submission Error!',
                message: 'Please choose a pump first!',
            }, {
                type: 'danger',
                placement: {
                    from: "top",
                    align: "right"
                },
                time: 1000,
            });
            flag = false;
        }else{
            if (e_nozzles_list.value == '') {
                $.notify({
                    icon: 'fas fa-fill-drip',
                    title: 'Submission Error!',
                    message: 'Please choose a nozzle first!',
                }, {
                    type: 'danger',
                    placement: {
                        from: "top",
                        align: "right"
                    },
                    time: 1000,
                });
                flag = false;
            }
        }
    }
    if (flag) {
        // Create FormData object
        const formData = new FormData();
        // Append values to FormData
        formData.append('station_id', e_stations_list.value);
        formData.append('pump_id', e_pumps_list.value);
        formData.append('nozzle_id', e_nozzles_list.value);
        formData.append('product_id', e_products_list.value);
        $.ajax({
            url: "/adminpanal/nozzles/edit/api/",
            type: 'POST',
            dataType: "json",
            processData: false,  // Don't process the data
            contentType: false,  // Don't set content type
            data: formData,
            headers: {
                'X-CSRFToken': document.getElementById('csrfToken').value,
            },
            success: function (response) {
                // console.log(t);
                if (response.status == 'updated') {
                    swal("Thank you", "The selected nozzle's product have been updated successfully.", {
                        icon: "success",
                        buttons: false,
                        timer: 3000
                    });
                }
                if (response.status == 'No_Post') {
                    swal("Sorry!", "You have to send a request.", {
                        icon: "error",
                        buttons: false,
                        timer: 3000
                    });
                }
                document.getElementById('resetEditNozzles').click();
                document.getElementById("reset").click();
            },
        });
    }
});

document.getElementById('resetEditNozzles').addEventListener('click', () => {
    $('#e_products_list').selectpicker('val', '');
    $('#e_products_list').attr('disabled', 'true');
    $('#e_products_list').selectpicker('refresh');
    
    document.getElementById("e_nozzles_list").innerHTML = '<option value="" selected disabled>Choose Nozzle...</option>';
    $('#e_nozzles_list').selectpicker('val', '');
    $('#e_nozzles_list').attr('disabled', 'true');
    $('#e_nozzles_list').selectpicker('refresh');
    
    document.getElementById("e_pumps_list").innerHTML = '<option value="" selected disabled>Choose Pump...</option>';
    $('#e_pumps_list').selectpicker('val', '');
    $('#e_pumps_list').attr('disabled', 'true');
    $('#e_pumps_list').selectpicker('refresh');
    
    $('#e_stations_list').selectpicker('val', '');
});


document.getElementById('d_stations_list').addEventListener('change', (event)=>{
    document.getElementById("d_pumps_list").innerHTML = '<option value="" selected disabled>Choose Pump...</option>';
    document.getElementById("d_nozzles_list").innerHTML = '<option value="" selected disabled>Choose Nozzle...</option>';
    $('#d_pumps_list').attr('disabled', 'true');
    $('#d_pumps_list').selectpicker('refresh');
    $('#d_nozzles_list').attr('disabled', 'true');
    $('#d_nozzles_list').selectpicker('refresh');
    console.log(event.target.value);
    $.ajax({
        url: "/adminpanal/nozzles/stations/single/api/",
        method: "GET",
        dataType: "json",
        data: {
            'station_id': event.target.value,
        },
        success: function (t) {
            console.log(t);
            if(t.status == 'not_exists'){
                swal("Sorry!", "No pumps found in the selected station.", {
                    icon: "error",
                    buttons: false,
                    timer: 2000
                });
            }else{
                const select = document.getElementById("d_pumps_list");

                // Clear any existing options (optional)
                select.innerHTML = '<option value="" selected disabled>Choose Pump...</option>';

                // Add new options
                t.forEach(pump => {
                    const option = document.createElement("option");
                    option.value = pump.id;
                    option.textContent = pump.number;
                    select.appendChild(option);
                });

                // Refresh selectpicker to apply changes
                $('#d_pumps_list').removeAttr('disabled');
                $('#d_pumps_list').selectpicker('refresh');
            }
        },
    });
});


document.getElementById('d_pumps_list').addEventListener('change', (event)=>{
    document.getElementById("d_nozzles_list").innerHTML = '';
    $('#d_nozzles_list').attr('disabled', 'true');
    $('#d_nozzles_list').selectpicker('refresh');
    console.log(event.target.value);
    $.ajax({
        url: "/adminpanal/nozzles/pumps/single/api/",
        method: "GET",
        dataType: "json",
        data: {
            'pump_id': event.target.value,
            'station_id': document.getElementById('d_stations_list').value,
        },
        success: function (t) {
            console.log(t);
            if(t.status == 'not_exists'){
                swal("Sorry!", "No nozzles found in the selected pump.", {
                    icon: "error",
                    buttons: false,
                    timer: 2000
                });
            }else{
                const select = document.getElementById("d_nozzles_list");

                // Clear any existing options (optional)
                select.innerHTML = '';

                // Add new options
                t.forEach(nozzle => {
                    const option = document.createElement("option");
                    option.value = nozzle.id;
                    option.textContent = nozzle.nozzle_number;
                    select.appendChild(option);
                });

                // Refresh selectpicker to apply changes
                $('#d_nozzles_list').removeAttr('disabled');
                $('#d_nozzles_list').selectpicker('refresh');
            }
        },
    });
});


document.getElementById('submitDeleteNozzles').addEventListener('click', () => {
    var d_stations_list = document.getElementById('d_stations_list');
    var d_pumps_list = document.getElementById('d_pumps_list');
    var d_nozzles_list = document.getElementById('d_nozzles_list');
    var flag = true;
    // Get the selected options as an array of values
    const selectedValues = Array.from(d_nozzles_list.selectedOptions).map(option => option.value);
    console.log(selectedValues);
    if (d_stations_list.value == '') {
        $.notify({
            icon: 'fas fa-industry',
            title: 'Submission Error!',
            message: 'Please choose a station first!',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }else{
        if(d_pumps_list.value == ''){
            $.notify({
                icon: 'fas fa-gas-pump',
                title: 'Submission Error!',
                message: 'Please choose a pump first!',
            }, {
                type: 'danger',
                placement: {
                    from: "top",
                    align: "right"
                },
                time: 1000,
            });
            flag = false;
        }else{
            if (selectedValues.length == 0) {
                $.notify({
                    icon: 'fas fa-fill-drip',
                    title: 'Submission Error!',
                    message: 'Please choose at least one nozzle to delete.',
                }, {
                    type: 'danger',
                    placement: {
                        from: "top",
                        align: "right"
                    },
                    time: 1000,
                });
                flag = false;
            }
        }
    }
    if (flag) {
        // Create FormData object
        const formData = new FormData();
        // Append values to FormData
        // formData.append('station_id', d_stations_list.value);
        // formData.append('pump_id', d_pumps_list.value);
        selectedValues.forEach((id, index) => {
            formData.append('nozzles_ids', id);
        });
        $.ajax({
            url: "/adminpanal/nozzles/delete/api/",
            type: 'POST',
            dataType: "json",
            processData: false,  // Don't process the data
            contentType: false,  // Don't set content type
            data: formData,
            headers: {
                'X-CSRFToken': document.getElementById('csrfToken').value,
            },
            success: function (response) {
                // console.log(t);
                if (response.status == 'deleted') {
                    swal("Thank you", "The selected nozzles have been deleted successfully.", {
                        icon: "success",
                        buttons: false,
                        timer: 3000
                    });
                }
                if (response.status == 'No_Post') {
                    swal("Sorry!", "You have to send a request.", {
                        icon: "error",
                        buttons: false,
                        timer: 3000
                    });
                }
                document.getElementById('resetDeleteNozzles').click();
                document.getElementById("reset").click();
            },
        });
    }
});

document.getElementById('resetDeleteNozzles').addEventListener('click', () => {
    document.getElementById("d_nozzles_list").innerHTML = '';
    $('#d_nozzles_list').selectpicker('val', '');
    $('#d_nozzles_list').attr('disabled', 'true');
    $('#d_nozzles_list').selectpicker('refresh');
    
    document.getElementById("d_pumps_list").innerHTML = '<option value="" selected disabled>Choose Pump...</option>';
    $('#d_pumps_list').selectpicker('val', '');
    $('#d_pumps_list').attr('disabled', 'true');
    $('#d_pumps_list').selectpicker('refresh');
    
    $('#d_stations_list').selectpicker('val', '');
});