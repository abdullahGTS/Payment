document.getElementById('submitGroup').addEventListener('click', () => {
    var group_name = document.getElementById('group_name');
    var group_users = document.getElementById('group_users');
    var group_stations = document.getElementById('group_stations');
    var selected_group_users = Array.from(group_users.selectedOptions).map(option => option.value);
    var selected_group_stations = Array.from(group_stations.selectedOptions).map(option => option.value);
    var flag = true;
    console.log(selected_group_users);
    console.log(selected_group_stations);

    if (group_name.value == '') {
        let parentFormGroup = $('#group_name').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $.notify({
            icon: 'fas fa-layer-group',
            title: 'Validation Error',
            message: 'Please enter a valid group name.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    } else {
        var groupNamePattern = /^[A-Za-z0-9 ]+$/;
        // Test the input value against the pattern
        if (!groupNamePattern.test(group_name.value)) {
            let parentFormGroup = $('#group_name').closest('.form-group');
            parentFormGroup.addClass('has-error');
            $.notify({
                icon: 'fas fa-layer-group',
                title: 'Validation Error',
                message: 'Group name must be at least 4 characters long and spaces between words.',
            }, {
                type: 'danger',
                placement: {
                    from: "top",
                    align: "right"
                },
                time: 1000,
            });
            flag = false;
        } else {
            let parentFormGroup = $('#group_name').closest('.form-group');
            parentFormGroup.removeClass('has-error');
        }
    }
    if (selected_group_users.length == 0) {
        let parentFormGroup = $('#group_users').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $('#group_users').selectpicker('setStyle', 'border-danger', 'add');
        $.notify({
            icon: 'fas fa-user',
            title: 'Validation Error',
            message: 'Please choose at least one user.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    } else {
        let parentFormGroup = $('#group_users').closest('.form-group');
            parentFormGroup.removeClass('has-error');
        $('#group_users').selectpicker('setStyle', 'border-danger', 'remove');
        $('#group_users').selectpicker('setStyle', 'border-gray', 'add');
    }
    if (selected_group_stations.length == 0) {
        let parentFormGroup = $('#group_stations').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $('#group_stations').selectpicker('setStyle', 'border-danger', 'add');
        $.notify({
            icon: 'fas fa-industry',
            title: 'Validation Error',
            message: 'Please choose at least one station.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    } else {
        let parentFormGroup = $('#group_stations').closest('.form-group');
        parentFormGroup.removeClass('has-error');
        $('#group_stations').selectpicker('setStyle', 'border-danger', 'remove');
        $('#group_stations').selectpicker('setStyle', 'border-gray', 'add');
    }

    if (flag) {
        // Create FormData object
        const formData = new FormData();
        // Append files to FormData
        formData.append(`group_name`, group_name.value);
        selected_group_users.forEach((id, index) => {
            formData.append('users_ids', id);
        });
        selected_group_stations.forEach((id, index) => {
            formData.append('stations_ids', id);
        });
        $.ajax({
            url: '/adminpanal/groups/add/api/',
            type: 'POST',
            dataType: 'json', // Set the content type if sending JSON data
            data: formData, // Convert data to JSON string if sending JSON
            processData: false,  // Don't process the data
            contentType: false,  // Don't set content type
            headers: {
                'X-CSRFToken': document.getElementById('csrfToken').value,
            },
            success: function (t) {
                // console.log(t);
                if (t.status == 'exists') {
                    // $.notify({
                    //     icon: 'fas fa-droplet',
                    //     title: 'Submittion Error',
                    //     message: 'Product number already exists.',
                    // }, {
                    //     type: 'danger',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Submittion Error!", "Group already exists.", {
                        icon: "error",
                        buttons: false,
                        timer: 2000
                    });
                }
                if (t.status == 'user') {
                    // $.notify({
                    //     icon: 'fas fa-droplet',
                    //     title: 'Submittion Error',
                    //     message: 'Product number already exists.',
                    // }, {
                    //     type: 'danger',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Submittion Error!", "User does not exist.", {
                        icon: "error",
                        buttons: false,
                        timer: 2000
                    });
                }
                if (t.status == 'station') {
                    // $.notify({
                    //     icon: 'fas fa-droplet',
                    //     title: 'Submittion Error',
                    //     message: 'Product number already exists.',
                    // }, {
                    //     type: 'danger',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Submittion Error!", "Station does not exist.", {
                        icon: "error",
                        buttons: false,
                        timer: 2000
                    });
                }
                if (t.status == 'No Post') {
                    // $.notify({
                    //     icon: 'fas fa-gears',
                    //     title: 'Technical Error',
                    //     message: 'You have to contact with your administrator.',
                    // }, {
                    //     type: 'danger',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Technical Error!", "You have to contact with your administrator.", {
                        icon: "error",
                        buttons: false,
                        timer: 2000
                    });
                }
                if (t.status == 'added') {
                    // $.notify({
                    //     icon: 'fas fa-droplet',
                    //     title: 'Submittion Successfully',
                    //     message: 'The product has been submitted successfully.',
                    // }, {
                    //     type: 'success',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Thank you", "The Group has been submitted successfully.", {
                        icon: "success",
                        buttons: false,
                        timer: 2000
                    });
                    document.getElementById('resetGroup').click();
                    getAllGroups();
                    getAllUsers();
                    getAllStations();
                    document.getElementById("reset").click();
                }
            },
        });
    }
});

document.getElementById('resetGroup').addEventListener('click', () => {
    let group_name = $('#group_name').closest('.form-group');
    group_name.removeClass('has-error');
    document.getElementById('group_name').value = '';
    let group_users = $('#group_users').closest('.form-group');
    group_users.removeClass('has-error');
    $('#group_users').selectpicker('setStyle', 'border-danger', 'remove');
    $('#group_users').selectpicker('setStyle', 'border-gray', 'add');
    $('#group_users').selectpicker('val', '');
    $('#group_users').selectpicker('refresh');
    let group_stations = $('#group_stations').closest('.form-group');
    group_stations.removeClass('has-error');
    $('#group_stations').selectpicker('setStyle', 'border-danger', 'remove');
    $('#group_stations').selectpicker('setStyle', 'border-gray', 'add');
    $('#group_stations').selectpicker('val', '');
    $('#group_stations').selectpicker('refresh');
    
});

//define column header menu as column visibility toggle
var headerMenu = function () {
    var menu = [];
    var columns = this.getColumns();

    for (let column of columns) {

        //create checkbox element using font awesome icons
        let icon = document.createElement("i");
        icon.classList.add("fas");
        icon.classList.add(column.isVisible() ? "fa-check-square" : "fa-square");

        //build label
        let label = document.createElement("span");
        let title = document.createElement("span");

        title.textContent = " " + column.getDefinition().title;

        label.appendChild(icon);
        label.appendChild(title);

        //create menu item
        menu.push({
            label: label,
            action: function (e) {
                //prevent menu closing
                e.stopPropagation();

                //toggle current column visibility
                column.toggle();

                //change menu item icon
                if (column.isVisible()) {
                    icon.classList.remove("fa-square");
                    icon.classList.add("fa-check-square");
                } else {
                    icon.classList.remove("fa-check-square");
                    icon.classList.add("fa-square");
                }
            }
        });
    }

    return menu;
};

//Define variables for input elements
var fieldSEl = document.getElementById("sort_field");
var dirEl = document.getElementById("sort_direction");

//Define variables for input elements
var fieldEl = document.getElementById("filter_field");
var typeEl = document.getElementById("filter_type");
var valueEl = document.getElementById("filter_value");


//Trigger setFilter function with correct parameters
function updateFilter() {
    var filterVal = fieldEl.options[fieldEl.selectedIndex].value;
    var typeVal = typeEl.options[typeEl.selectedIndex].value;

    var filter = filterVal;

    if (filterVal) {
        table.setFilter(filter, typeVal, valueEl.value);
    }
}

//Update filters on value change
document.getElementById("filter_field").addEventListener("change", updateFilter);
document.getElementById("filter_type").addEventListener("change", updateFilter);
document.getElementById("filter_value").addEventListener("keyup", updateFilter);

//Clear filters on "Clear Filters" button click
document.getElementById("filter_clear").addEventListener("click", function () {
    fieldEl.value = "";
    typeEl.value = "";
    valueEl.value = "";

    table.clearFilter();
});

// Define column configurations with headerMenu
function defaultColumns() {
    return [
        { title: "ID", field: "id", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
        { title: "Group Name", field: "name", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
        { title: "Creator Name", field: "creator", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
        {
            title: "Creation Date", field: "timestamp", hozAlign: "start", sorter: "datetime", sorterParams: {
                format: "yyyy-MM-dd HH:mm:ss",
                alignEmptyValues: "top",
            }, headerMenu: headerMenu
        },
        {
            title: "Users",
            field: "users",
            hozAlign: "start",
            formatter: function (cell, formatterParams) {
                var group_id = cell.getValue();
                return `<button class="btn btn-success-dark btn-border py-1 px-4" onclick="usersViewModal('${group_id}')">
                            Users <i class="fas fa-user ms-2"></i>
                        </button>`;
            },
            headerMenu: headerMenu,
            print: false,
            download: false
        },
        {
            title: "Stations",
            field: "stations",
            hozAlign: "start",
            formatter: function (cell, formatterParams) {
                var group_id = cell.getValue();
                return `<button class="btn btn-success-dark btn-border py-1 px-4" onclick="stationsViewModal('${group_id}')">
                            Stations <i class="fas fa-industry ms-2"></i>
                        </button>`;
            },
            headerMenu: headerMenu,
            print: false,
            download: false
        }
    ];
}

// Initial Table Configuration Function
function createTable() {
    return new Tabulator("#groups_table", {
        layout: "fitColumns",          // Fit columns to the table width
        responsiveLayout: "hide",       // Hide columns that don’t fit
        height: window.innerHeight / 2,
        printAsHtml: true,
        printStyled: true,
        textDirection: "ltr",
        printHeader: `
        <div class="row mt-4 mb-4">
            <div class="col-12 d-flex justify-content-center align-items-center">
                <h1>Groups Table</h1>
            </div>
        </div>
        <hr>
        `,
        printFooter: `
        <div class="row mt-4">
            <div class="col-12 d-flex justify-content-center align-items-center">
                <img src='/static/img/gts-logo.png' alt='gts-logo' style="width: 50%;height: 100%;" />
            </div>
        </div>
        `,
        ajaxURL: "http://127.0.0.1:8000/adminpanal/groups/view/api/",
        ajaxParams: { page: 1, size: 10 },
        progressiveLoad: "scroll",
        placeholder: "No Groups Data",
        selectableRows: false,
        paginationSize: 10,
        columnDefaults: {
            tooltip: true,
        },
        langs: {
            "ar-eg": {
                "columns": {
                    "id": "مسلسل",
                    "first_name": "الاسم الاول",
                    "last_name": "الاسم الاخير",
                    "email": "البريد",
                    "role": "الوظيفة",
                    "image": "الصورة",
                    "add_date": "تاريخ الانشاء",
                    "first_login": "",
                    "is_locked": "مغلق",
                    "attempts": "محاولات الدخول الفاشلة",
                },
            }
        },
        columns: defaultColumns(),
    });
}

var table = createTable();

window.addEventListener('resize', function () {
    table.redraw(true); //trigger full rerender including all data and rows
});

// var table = new Tabulator("#groups_table", {
//     layout: "fitColumns",          // Fit columns to the table width
//     responsiveLayout: "hide",       // Hide columns that don’t fit
//     height: window.innerHeight / 2,
//     printAsHtml: true,
//     printStyled: true,
//     // autoColumns:true,
//     // printRowRange: "all",
//     // textDirection: "rtl",
//     printHeader: `
//     <div class="row mt-4 mb-4">
//         <div class="col-12 d-flex justify-content-center align-items-center">
//             <h1>Products Table</h1>
//         </div>
//     </div>
//     <hr>
//     `,
//     printFooter: `
//     <div class="row mt-4">
//         <div class="col-12 d-flex justify-content-center align-items-center">
//             <img src='/static/img/gts-logo.png' alt='gts-logo' style="width: 50%;height: 100%;" />
//         </div>
//     </div>
//     `,
//     // clipboard: true,
//     // clipboardPasteAction: "replace",
//     // resizableRows: true,
//     // resizableRowGuide: true,
//     // resizableColumnGuide: true,
//     // movableColumns: true,
//     ajaxURL: "http://127.0.0.1:8000/adminpanal/product/view/api/",
//     ajaxParams: { page: 1, size: 10 },  // Start with page 1 and size 3
//     progressiveLoad: "scroll",      // Enable progressive loading with scroll
//     placeholder: "No Product Data",
//     selectableRows: true, //make rows selectable
//     // addRowPos: "top",
//     // history: true,
//     paginationSize: 10,
//     columnDefaults: {
//         tooltip: true,
//     },
//     langs: {
//         "ar-eg": { //French language definition
//             "columns": {
//                 "id": "مسلسل",
//                 "number": "الرقم",
//                 "name": "الاسم",
//                 "price": "السعر",
//                 "timestamp": "تاريخ الانشاء",
//             },
//         }
//     },
//     columns: [
//         { title: "ID", field: "id", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
//         { title: "Number", field: "number", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
//         { title: "Name", field: "name", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
//         { title: "Price", field: "price", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
//         { title: "Timestamp", field: "timestamp", hozAlign: "start", sorter: "datetime", headerMenu: headerMenu },
//     ],
// });


//Trigger sort when "Trigger Sort" button is clicked
document.getElementById("sort_trigger").addEventListener("click", function () {
    table.setSort(fieldSEl.options[fieldSEl.selectedIndex].value, dirEl.options[dirEl.selectedIndex].value);
});

document.getElementById("sort_reset").addEventListener("click", function () {
    table.setSort("id", "asc");
});

table.on("rowSelectionChanged", function (data, rows) {
    document.getElementById("select_stats").innerHTML = data.length;
});

//select row on "select all" button click
document.getElementById("select_all").addEventListener("click", function () {
    table.selectRow();
});

//deselect row on "deselect all" button click
document.getElementById("deselect_all").addEventListener("click", function () {
    table.deselectRow();
});

//Delete row on "Delete Row" button click
document.getElementById("del_row").addEventListener("click", function () {
    var rowid = document.getElementById('row_delete');
    if (rowid.value == '') {
        $.notify({
            icon: 'fas fa-trash',
            title: 'Validation Error',
            message: 'Please enter a valid row number.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
    } else {
        table.deleteRow(parseInt(rowid.value));
        rowid.value = '';
    }
});

//Clear table on "Empty the table" button click
document.getElementById("clear").addEventListener("click", function () {
    table.clearData()
});

//Reset table contents on "Reset the table" button click
document.getElementById("reset").addEventListener("click", function () {
    // table.setData("http://127.0.0.1:8000/adminpanal/product/view/api/", { page: 1, size: 10 });
    // Destroy current instance of the table
    table.destroy();
    // Recreate table with initial settings
    table = createTable();
});

document.getElementById('download_btn').addEventListener('click', () => {
    var file_name = document.getElementById('file_name');
    var download_type = document.getElementById('download_type');
    var flag = true;
    if (file_name.value == '') {
        $.notify({
            icon: 'fas fa-font',
            title: 'Validation Error',
            message: 'Please enter a valid file name.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (download_type.value == '') {
        $.notify({
            icon: 'fas fa-gear',
            title: 'Validation Error',
            message: 'Please choose a download type.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }

    if (flag) {
        if (download_type.value == 'csv') table.download("csv", `${file_name.value}.csv`);
        if (download_type.value == 'json') table.download("json", `${file_name.value}.json`);
        if (download_type.value == 'xlsx') table.download("xlsx", `${file_name.value}.xlsx`, { sheetName: file_name.value });
        if (download_type.value == 'pdf') {
            table.download("pdf", `${file_name.value}.pdf`, {
                orientation: "portrait", //set page orientation to portrait
                title: "Groups Data", //add title to report
            });
        }
        if (download_type.value == 'html') table.download("html", `${file_name.value}.html`, { style: true });
    }
});

//print button
document.getElementById("print_table").addEventListener("click", function () {
    // Get the selected print range from the dropdown
    var selectedRange = document.getElementById("print_range").value;
    console.log(selectedRange);
    // Update printRowRange on the table instance
    table.options.printRowRange = selectedRange;
    // Print the table using the selected printRowRange
    table.print(false, true);
});


//set locale to French
document.getElementById("lang_arabic").addEventListener("click", function () {
    table.setLocale("ar-eg");
    table.setColumns(defaultColumns());  // Reload columns to apply headerMenu
    // document.getElementById("groups_table").setAttribute("dir", "rtl");
});

//set default locale
document.getElementById("lang_default").addEventListener("click", function () {
    table.setLocale("");
    table.setColumns(defaultColumns());  // Reload columns to apply headerMenu
    // document.getElementById("groups_table").setAttribute("dir", "ltr");
});

function usersViewModal(group_id) {
    console.log(group_id);
    // Open the modal with specific options
    $.ajax({
        url: "/adminpanal/groups/users/api/",
        method: "GET",
        dataType: "json",
        data: {
            'group_id': group_id,
        },
        success: function (t) {
            console.log(t);
            document.getElementById('usersModalGroupName').innerHTML = `${t[0].group_name} Users #${t.length}`;
            var usersModalOL = document.getElementById('usersModalOL');
            var tempList = ``;
            t.forEach((user) => {
                tempList += `
                <li class="list-group-item d-flex justify-content-between align-items-start">
                    <div class="ms-2 me-auto">
                        <div class="fw-bold">${user.first_name} ${user.last_name}</div>
                        ${user.email}
                    </div>
                    <div class="badge avatar avatar-lg border-0">
                        <img src="${user.image}" alt="user#${user.id} image" loading="lazy" class="avatar-img rounded-circle">
                    </div>
                </li>
                `
            });
            usersModalOL.innerHTML = tempList;
            $('#usersModal').modal('show');
        },
    });
}

function stationsViewModal(group_id) {
    console.log(group_id);
    // Open the modal with specific options
    $.ajax({
        url: "/adminpanal/groups/stations/api/",
        method: "GET",
        dataType: "json",
        data: {
            'group_id': group_id,
        },
        success: function (t) {
            console.log(t);
            document.getElementById('stationsModalGroupName').innerHTML = `${t[0].group_name} Stations #${t.length}`;
            var stationsModalOL = document.getElementById('stationsModalOL');
            var tempList = ``;
            t.forEach((station) => {
                tempList += `
                <li class="list-group-item d-flex justify-content-between align-items-start">
                    <div class="ms-2 me-auto">
                        <div class="fw-bold">${station.station_name}</div>
                        ${station.ip}:${station.port}
                    </div>
                    <span class="badge btn-success-dark btn-border rounded-pill">${station.station_code}</span>
                </li>
                `;
            });
            stationsModalOL.innerHTML = tempList;
            $('#stationsModal').modal('show');
        },
    });
}

function getAllGroups() {
    $.ajax({
        url: "/adminpanal/groups/all/api/",
        method: "GET",
        dataType: "json",
        data: {},
        success: function (t) {
            console.log(t);
            const select = document.getElementById("groups_edit_list");
            const e_select = document.getElementById("groups_list");

            // Clear any existing options (optional)
            select.innerHTML = '<option value="" selected disabled>Choose group to edit...</option>';
            e_select.innerHTML = '';

            // Add new options
            t.forEach(group => {
                const option1 = document.createElement("option");
                option1.value = group.id;
                option1.textContent = group.name;
                option1.setAttribute("data-subtext", `Users #${group.users} --- Stations #${group.stations}`);
                select.appendChild(option1);

                const option2 = document.createElement("option");
                option2.value = group.id;
                option2.textContent = group.name;
                option2.setAttribute("data-subtext", `Users #${group.users} --- Stations #${group.stations}`);
                e_select.appendChild(option2);
            });

            // Refresh selectpicker to apply changes
            $('#groups_edit_list').selectpicker('refresh');
            $('#groups_list').selectpicker('refresh');
        },
    });
}

function getAllUsers() {
    $.ajax({
        url: "/adminpanal/groups/users/all/api/",
        method: "GET",
        dataType: "json",
        data: {},
        success: function (t) {
            console.log(t);
            const select = document.getElementById("group_users");
            const e_select = document.getElementById("e_group_users");

            // Clear any existing options (optional)
            select.innerHTML = '';
            e_select.innerHTML = '';

            // Add new options
            t.forEach(user => {
                const option1 = document.createElement("option");
                option1.value = user.id;
                option1.textContent = `${user.first_name} ${user.last_name}@${user.role}`;
                option1.setAttribute("data-subtext", `${user.email}`);
                select.appendChild(option1);
                
                const option2 = document.createElement("option");
                option2.value = user.id;
                option2.textContent = `${user.first_name} ${user.last_name}@${user.role}`;
                option2.setAttribute("data-subtext", `${user.email}`);
                e_select.appendChild(option2);
            });

            // Refresh selectpicker to apply changes
            $('#group_users').selectpicker('refresh');
            $('#e_group_users').selectpicker('refresh');
        },
    });
}

function getAllStations() {
    $.ajax({
        url: "/adminpanal/groups/stations/all/api/",
        method: "GET",
        dataType: "json",
        data: {},
        success: function (t) {
            console.log(t);
            const select = document.getElementById("group_stations");
            const e_select = document.getElementById("e_group_stations");

            // Clear any existing options (optional)
            select.innerHTML = '';
            e_select.innerHTML = '';

            // Add new options
            t.forEach(station => {
                const option1 = document.createElement("option");
                option1.value = station.id;
                option1.textContent = `${station.station_code}-${station.station_name}`;
                option1.setAttribute("data-subtext", `${station.ip}:${station.port}`);
                select.appendChild(option1);
                
                const option2 = document.createElement("option");
                option2.value = station.id;
                option2.textContent = `${station.station_code}-${station.station_name}`;
                option2.setAttribute("data-subtext", `${station.ip}:${station.port}`);
                e_select.appendChild(option2);
            });

            // Refresh selectpicker to apply changes
            $('#group_stations').selectpicker('refresh');
            $('#e_group_stations').selectpicker('refresh');
        },
    });
}

$(function () {
    getAllGroups();
    getAllUsers();
    getAllStations();
});

document.getElementById('groups_edit_list').addEventListener('change', (event) => {
    console.log(event.target.value);
    document.querySelector('#pre_e_group_name i').className = 'spinner-border';
    document.querySelector('#pre_e_group_users i').className = 'spinner-border';
    document.querySelector('#pre_e_group_stations i').className = 'spinner-border';
    $.ajax({
        url: "/adminpanal/groups/single/api/",
        method: "GET",
        dataType: "json",
        data: {
            'group_id': event.target.value,
        },
        success: function (t) {
            console.log(t);
            document.getElementById('e_group_name').value = t.name;
            document.getElementById('e_group_name').removeAttribute('disabled');
            $('#e_group_users').val(t.users);
            $("#e_group_users").removeAttr("disabled");
            $('#e_group_users').selectpicker('refresh');
            $('#e_group_stations').val(t.stations);
            $("#e_group_stations").removeAttr("disabled");
            $('#e_group_stations').selectpicker('refresh');

            document.querySelector('#pre_e_group_name i').className = 'fas fa-layer-group';
            document.querySelector('#pre_e_group_users i').className = 'fas fa-user-tie';
            document.querySelector('#pre_e_group_stations i').className = 'fas fa-industry';
        },
    });
});


document.getElementById('submitEditGroup').addEventListener('click', () => {
    var groups_edit_list = document.getElementById('groups_edit_list');
    var e_group_name = document.getElementById('e_group_name');
    var e_group_users = document.getElementById('e_group_users');
    var e_group_stations = document.getElementById('e_group_stations');
    var selected_e_group_users = Array.from(e_group_users.selectedOptions).map(option => option.value);
    var selected_e_group_stations = Array.from(e_group_stations.selectedOptions).map(option => option.value);
    var flag = true;

    if (groups_edit_list.value == '') {
        $.notify({
            icon: 'fas fa-id-card',
            title: 'Validation Error',
            message: 'Please choose a group.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (e_group_name.value == '') {
        let parentFormGroup = $('#e_group_name').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $.notify({
            icon: 'fas fa-id-card',
            title: 'Validation Error',
            message: 'Please enter a valid group name.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    } else {
        var groupNamePattern = /^[A-Za-z0-9 ]+$/;
        // Test the input value against the pattern
        if (!groupNamePattern.test(e_group_name.value)) {
            let parentFormGroup = $('#e_group_name').closest('.form-group');
            parentFormGroup.addClass('has-error');
            $.notify({
                icon: 'fas fa-id-card',
                title: 'Validation Error',
                message: 'Group name must be at least 4 characters long and spaces between words.',
            }, {
                type: 'danger',
                placement: {
                    from: "top",
                    align: "right"
                },
                time: 1000,
            });
            flag = false;
        } else {
            let parentFormGroup = $('#e_group_name').closest('.form-group');
            parentFormGroup.removeClass('has-error');
        }
    }
    if (selected_e_group_users.length == 0) {
        let parentFormGroup = $('#e_group_users').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $('#e_group_users').selectpicker('setStyle', 'border-danger', 'add');
        $.notify({
            icon: 'fas fa-id-card',
            title: 'Validation Error',
            message: 'Please choose at least one user.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    } else {
        let parentFormGroup = $('#e_group_users').closest('.form-group');
        parentFormGroup.removeClass('has-error');
        $('#e_group_users').selectpicker('setStyle', 'border-danger', 'remove');
        $('#e_group_users').selectpicker('setStyle', 'border-gray', 'add');
    }
    if (selected_e_group_stations.length == 0) {
        let parentFormGroup = $('#e_group_stations').closest('.form-group');
        parentFormGroup.addClass('has-error');
        $('#e_group_stations').selectpicker('setStyle', 'border-danger', 'add');
        $.notify({
            icon: 'fas fa-id-card',
            title: 'Validation Error',
            message: 'Please choose at least one station.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    } else {
        let parentFormGroup = $('#e_group_stations').closest('.form-group');
        parentFormGroup.removeClass('has-error');
        $('#e_group_stations').selectpicker('setStyle', 'border-danger', 'remove');
        $('#e_group_stations').selectpicker('setStyle', 'border-gray', 'add');
    }

    if (flag) {
        // Create FormData object
        const formData = new FormData();
        // Append files to FormData
        formData.append(`group_id`, groups_edit_list.value);
        formData.append(`e_group_name`, e_group_name.value);
        selected_e_group_users.forEach((id, index) => {
            formData.append('e_users_ids', id);
        });
        selected_e_group_stations.forEach((id, index) => {
            formData.append('e_stations_ids', id);
        });

        $.ajax({
            url: '/adminpanal/groups/edit/api/',
            type: 'POST',
            dataType: 'json', // Set the content type if sending JSON data
            data: formData, // Convert data to JSON string if sending JSON
            processData: false,  // Don't process the data
            contentType: false,  // Don't set content type
            headers: {
                'X-CSRFToken': document.getElementById('csrfToken').value,
            },
            success: function (t) {
                // console.log(t);
                if (t.status == 'exists') {
                    // $.notify({
                    //     icon: 'fas fa-droplet',
                    //     title: 'Submittion Error',
                    //     message: 'Product number already exists.',
                    // }, {
                    //     type: 'danger',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Submittion Error!", "Group name already exists.", {
                        icon: "error",
                        buttons: false,
                        timer: 2000
                    });
                }
                if (t.status == 'group') {
                    // $.notify({
                    //     icon: 'fas fa-droplet',
                    //     title: 'Submittion Error',
                    //     message: 'Product number already exists.',
                    // }, {
                    //     type: 'danger',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Submittion Error!", "Group does not exist.", {
                        icon: "error",
                        buttons: false,
                        timer: 2000
                    });
                }
                if (t.status == 'user') {
                    // $.notify({
                    //     icon: 'fas fa-droplet',
                    //     title: 'Submittion Error',
                    //     message: 'Product number already exists.',
                    // }, {
                    //     type: 'danger',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Submittion Error!", "User does not exist.", {
                        icon: "error",
                        buttons: false,
                        timer: 2000
                    });
                }
                if (t.status == 'station') {
                    // $.notify({
                    //     icon: 'fas fa-droplet',
                    //     title: 'Submittion Error',
                    //     message: 'Product number already exists.',
                    // }, {
                    //     type: 'danger',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Submittion Error!", "Station does not exist.", {
                        icon: "error",
                        buttons: false,
                        timer: 2000
                    });
                }
                if (t.status == 'No Post') {
                    // $.notify({
                    //     icon: 'fas fa-gears',
                    //     title: 'Technical Error',
                    //     message: 'You have to contact with your administrator.',
                    // }, {
                    //     type: 'danger',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Technical Error!", "You have to contact with your administrator.", {
                        icon: "error",
                        buttons: false,
                        timer: 2000
                    });
                }
                if (t.status == 'updated') {
                    // $.notify({
                    //     icon: 'fas fa-droplet',
                    //     title: 'Submittion Successfully',
                    //     message: 'The product has been submitted successfully.',
                    // }, {
                    //     type: 'success',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Thank you", "The Group has been updated successfully.", {
                        icon: "success",
                        buttons: false,
                        timer: 2000
                    });
                    document.getElementById('resetEditGroup').click();
                    getAllGroups();
                    getAllUsers();
                    getAllStations();
                    document.getElementById("reset").click();
                }
            },
        });
    }
});

document.getElementById('resetEditGroup').addEventListener('click', () => {
    $('#groups_edit_list').selectpicker('val', '');
    document.getElementById('e_group_name').value = '';
    document.getElementById('e_group_name').setAttribute('disabled', 'true');
    $('#e_group_users').selectpicker('val', '');
    $('#e_group_users').attr('disabled', 'true');
    $('#e_group_users').selectpicker('refresh');
    $('#e_group_stations').selectpicker('val', '');
    $('#e_group_stations').attr('disabled', 'true');
    $('#e_group_stations').selectpicker('refresh');
    
    // $('#e_role').selectpicker('setStyle', 'border-danger', 'remove');
    // $('#e_role').selectpicker('setStyle', 'border-gray', 'add');
});

document.getElementById('submitDeleteGroup').addEventListener('click', () => {
    var groups_list = document.getElementById('groups_list');
    var flag = true;
    // Get the selected options as an array of values
    const selectedValues = Array.from(groups_list.selectedOptions).map(option => option.value);
    console.log(selectedValues);
    if (selectedValues.length == 0) {
        $.notify({
            icon: 'fas fa-trash',
            title: 'Validation Error',
            message: 'Please choose at least one group to delete.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (flag) {
        // Create FormData object
        const formData = new FormData();
        // Append values to FormData
        // formData.append('f_st_codes', selectedValues);
        selectedValues.forEach((id, index) => {
            formData.append('groups_ids', id);
        });
        $.ajax({
            url: "/adminpanal/groups/delete/api/",
            type: 'POST',
            dataType: "json",
            processData: false,  // Don't process the data
            contentType: false,  // Don't set content type
            data: formData,
            headers: {
                'X-CSRFToken': document.getElementById('csrfToken').value,
            },
            success: function (response) {
                // console.log(t);
                // if (response.status == 'delete_exists') {
                //     var spans = ``;
                //     if (response.ids) {
                //         response.ids.forEach((id) => {
                //             console.log(id);
                //             spans += `<span class="m-1 col-1">${id}</span>`; // Adding each code inside a span with margin
                //         });
                //     } else {
                //         spans = "No Exists IDs.";
                //     }
                //     swal("Thank you", "The selected products has been deleted successfully.", {
                //         icon: "success",
                //         buttons: {
                //             confirm: {
                //                 text: "cannot delete IDs!",
                //                 className: "btn btn-success-dark",
                //             },
                //             cancel: {
                //                 visible: true,
                //                 className: "btn btn-danger",
                //             },
                //         },
                //     }).then((exists) => {
                //         if (exists) {
                //             swal({
                //                 title: "Cannot Delete Product IDs!",
                //                 content: {
                //                     element: "div",
                //                     attributes: {
                //                         innerHTML: spans,
                //                         className: "row" // Insert the concatenated HTML string
                //                     },
                //                 },
                //                 icon: "error",
                //                 buttons: {
                //                     confirm: {
                //                         className: "btn btn-danger",
                //                     },
                //                 },
                //             });
                //         } else {
                //             swal.close();
                //         }
                //     });
                // }
                // if (response.status == 'exists') {
                //     swal("Sorry!", "Can't delete the selected products, already linked with Nozzles.", {
                //         icon: "error",
                //         buttons: false,
                //         timer: 3000
                //     });
                // }
                if (response.status == 'deleted') {
                    swal("Thank you", "The selected users has been deleted successfully.", {
                        icon: "success",
                        buttons: false,
                        timer: 3000
                    });
                }
                if (response.status == 'No_Post') {
                    swal("Sorry!", "You have to send a request.", {
                        icon: "error",
                        buttons: false,
                        timer: 3000
                    });
                }
                getAllGroups();
                document.getElementById('resetDeleteGroup').click();
                document.getElementById("reset").click();
            },
        });
    }
});

document.getElementById('resetDeleteGroup').addEventListener('click', () => {
    $('#groups_list').selectpicker('val', '');
});