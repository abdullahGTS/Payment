document.getElementById('submitProduct').addEventListener('click', () => {
    var product_num = document.getElementById('product_num');
    var product_name = document.getElementById('product_name');
    var product_price = document.getElementById('product_price');
    var flag = true;

    if (product_num.value == '') {
        // product_num.classList.add('bg-danger', 'text-white');
        $.notify({
            icon: 'fas fa-hashtag',
            title: 'Validation Error',
            message: 'Please enter a valid product number.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (product_name.value == '') {
        // product_name.classList.add('bg-danger', 'text-white');
        $.notify({
            icon: 'fas fa-font',
            title: 'Validation Error',
            message: 'Please enter a valid product name.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (product_price.value == '') {
        // product_price.classList.add('bg-danger', 'text-white');
        $.notify({
            icon: 'fas fa-dollar-sign',
            title: 'Validation Error',
            message: 'Please enter a valid product price.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }

    if (flag) {
        $.ajax({
            url: "/adminpanal/product/add/api/",
            method: "GET",
            dataType: "json",
            data: {
                'product_num': product_num.value,
                'product_name': product_name.value,
                'product_price': product_price.value,
            },
            success: function (t) {
                // console.log(t);
                if (t.status == 'exists') {
                    // $.notify({
                    //     icon: 'fas fa-droplet',
                    //     title: 'Submittion Error',
                    //     message: 'Product number already exists.',
                    // }, {
                    //     type: 'danger',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Submittion Error!", "Product number already exists.", {
                        icon: "error",
                        buttons: false,
                        timer: 2000
                    });
                }
                if (t.status == 'No Get') {
                    // $.notify({
                    //     icon: 'fas fa-gears',
                    //     title: 'Technical Error',
                    //     message: 'You have to contact with your administrator.',
                    // }, {
                    //     type: 'danger',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Technical Error!", "You have to contact with your administrator.", {
                        icon: "error",
                        buttons: false,
                        timer: 2000
                    });
                }
                if (t.status == 'added') {
                    // $.notify({
                    //     icon: 'fas fa-droplet',
                    //     title: 'Submittion Successfully',
                    //     message: 'The product has been submitted successfully.',
                    // }, {
                    //     type: 'success',
                    //     placement: {
                    //         from: "top",
                    //         align: "right"
                    //     },
                    //     time: 1000,
                    // });
                    swal("Thank you", "The product has been submitted successfully.", {
                        icon: "success",
                        buttons: false,
                        timer: 2000
                    });
                    product_num.value = '';
                    product_name.value = '';
                    product_price.value = '';
                    getAllProducts();
                    document.getElementById("reset").click();
                }

            },
        });
    }
});

// function submitProduct(){
//     product_num = document.getElementById('product_num');
//     product_name = document.getElementById('product_name');
//     product_price = document.getElementById('product_price');
//     if(product_num.value == ''){
//         product_num.classList.add('bg-danger', 'text-white');
//     }else if(product_name.value == ''){
//         product_name.classList.add('bg-danger', 'text-white');
//     }else if(product_price.value == ''){
//         product_price.classList.add('bg-danger', 'text-white');
//     }else{
//         document.getElementById('miniloader').classList.remove('d-none');
//         $.ajax({
//             url: "/adminpanal/product/add/api/",
//             method: "GET",
//             dataType: "json",
//             data: {
//                 'product_num': product_num.value,
//                 'product_name': product_name.value,
//                 'product_price': product_price.value,
//             },
//             success: function (t) {
//                 console.log(t);
//                 if(t.status == 'exists'){
//                     document.getElementById('error_msg').innerHTML = 'Product Already Exists!';
//                     document.getElementById('error_msg').classList.add('text-danger');
//                     document.getElementById('error_msg').classList.remove('d-none');
//                     document.getElementById('miniloader').classList.add('d-none');
//                     setTimeout(()=>{
//                         document.getElementById('error_msg').innerHTML = '';
//                         document.getElementById('error_msg').classList.remove('text-danger');
//                         document.getElementById('error_msg').classList.add('d-none');
//                     },3000);
//                 }


//                 if(t.status == 'No Get'){
//                     document.getElementById('error_msg').innerHTML = 'Technical Error!';
//                     document.getElementById('error_msg').classList.add('text-danger');
//                     document.getElementById('error_msg').classList.remove('d-none');

//                     setTimeout(()=>{
//                         document.getElementById('error_msg').innerHTML = '';
//                         document.getElementById('error_msg').classList.remove('text-danger');
//                         document.getElementById('error_msg').classList.add('d-none');
//                     },3000);
//                 }


//                 if(t.status == 'added'){
//                     document.getElementById('error_msg').innerHTML = 'Product is added successfully.';
//                     document.getElementById('error_msg').classList.add('text-success');
//                     document.getElementById('error_msg').classList.remove('d-none');

//                     product_num.classList.remove('bg-danger', 'text-white');
//                     product_name.classList.remove('bg-danger', 'text-white');
//                     product_price.classList.remove('bg-danger', 'text-white');
//                     product_num.value = '';
//                     product_name.value = '';
//                     product_price.value = '';

//                     var e = $("#productTbl");
//                     e.bootstrapTable("showLoading");
//                     e.bootstrapTable("append",{
//                         'id':t.id,
//                         'number':t.number,
//                         'name':t.name,
//                         'price':t.price,
//                         'timestamp':t.timestamp,
//                         'actions': `<button class="btn btn-dark w-100" onclick="deleteProduct('${t.id}')">Delete</button>`,
//                     });
//                     e.bootstrapTable("refresh");
//                     e.bootstrapTable("hideLoading");
//                     document.getElementById('miniloader').classList.add('d-none');
//                     document.getElementById('products_num').innerHTML = parseInt(document.getElementById('products_num').innerHTML) + 1;

//                     setTimeout(()=>{
//                         document.getElementById('error_msg').innerHTML = '';
//                         document.getElementById('error_msg').classList.remove('text-danger');
//                         document.getElementById('error_msg').classList.add('d-none');
//                     },3000);
//                 }

//             },
//         });
//     }
// }

document.getElementById('resetProduct').addEventListener('click', () => {
    document.getElementById('product_num').value = '';
    document.getElementById('product_name').value = '';
    document.getElementById('product_price').value = '';
});

//define column header menu as column visibility toggle
var headerMenu = function () {
    var menu = [];
    var columns = this.getColumns();

    for (let column of columns) {

        //create checkbox element using font awesome icons
        let icon = document.createElement("i");
        icon.classList.add("fas");
        icon.classList.add(column.isVisible() ? "fa-check-square" : "fa-square");

        //build label
        let label = document.createElement("span");
        let title = document.createElement("span");

        title.textContent = " " + column.getDefinition().title;

        label.appendChild(icon);
        label.appendChild(title);

        //create menu item
        menu.push({
            label: label,
            action: function (e) {
                //prevent menu closing
                e.stopPropagation();

                //toggle current column visibility
                column.toggle();

                //change menu item icon
                if (column.isVisible()) {
                    icon.classList.remove("fa-square");
                    icon.classList.add("fa-check-square");
                } else {
                    icon.classList.remove("fa-check-square");
                    icon.classList.add("fa-square");
                }
            }
        });
    }

    return menu;
};

//Define variables for input elements
var fieldSEl = document.getElementById("sort_field");
var dirEl = document.getElementById("sort_direction");

//Define variables for input elements
var fieldEl = document.getElementById("filter_field");
var typeEl = document.getElementById("filter_type");
var valueEl = document.getElementById("filter_value");


//Trigger setFilter function with correct parameters
function updateFilter() {
    var filterVal = fieldEl.options[fieldEl.selectedIndex].value;
    var typeVal = typeEl.options[typeEl.selectedIndex].value;

    var filter = filterVal;

    if (filterVal) {
        table.setFilter(filter, typeVal, valueEl.value);
    }
}

//Update filters on value change
document.getElementById("filter_field").addEventListener("change", updateFilter);
document.getElementById("filter_type").addEventListener("change", updateFilter);
document.getElementById("filter_value").addEventListener("keyup", updateFilter);

//Clear filters on "Clear Filters" button click
document.getElementById("filter_clear").addEventListener("click", function () {
    fieldEl.value = "";
    typeEl.value = "";
    valueEl.value = "";

    table.clearFilter();
});

// Define column configurations with headerMenu
function defaultColumns() {
    return [
        { title: "ID", field: "id", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
        { title: "Number", field: "number", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
        { title: "Name", field: "name", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
        { title: "Price", field: "price", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
        {
            title: "Timestamp", field: "timestamp", hozAlign: "start", sorter: "datetime", sorterParams: {
                format: "yyyy-MM-dd HH:mm:ss",
                alignEmptyValues: "top",
            }, headerMenu: headerMenu
        },
    ];
}

// Initial Table Configuration Function
function createTable() {
    return new Tabulator("#product_table", {
        layout: "fitColumns",          // Fit columns to the table width
        responsiveLayout: "hide",       // Hide columns that don’t fit
        height: window.innerHeight / 2,
        printAsHtml: true,
        printStyled: true,
        textDirection: "ltr",
        printHeader: `
        <div class="row mt-4 mb-4">
            <div class="col-12 d-flex justify-content-center align-items-center">
                <h1>Products Table</h1>
            </div>
        </div>
        <hr>
        `,
        printFooter: `
        <div class="row mt-4">
            <div class="col-12 d-flex justify-content-center align-items-center">
                <img src='/static/img/gts-logo.png' alt='gts-logo' style="width: 50%;height: 100%;" />
            </div>
        </div>
        `,
        ajaxURL: "http://127.0.0.1:8000/adminpanal/product/view/api/",
        ajaxParams: { page: 1, size: 10 },
        progressiveLoad: "scroll",
        placeholder: "No Product Data",
        selectableRows: true,
        paginationSize: 10,
        columnDefaults: {
            tooltip: true,
        },
        langs: {
            "ar-eg": {
                "columns": {
                    "id": "مسلسل",
                    "number": "الرقم",
                    "name": "الاسم",
                    "price": "السعر",
                    "timestamp": "تاريخ الانشاء",
                },
            }
        },
        columns: defaultColumns(),
    });
}

var table = createTable();

// var table = new Tabulator("#product_table", {
//     layout: "fitColumns",          // Fit columns to the table width
//     responsiveLayout: "hide",       // Hide columns that don’t fit
//     height: window.innerHeight / 2,
//     printAsHtml: true,
//     printStyled: true,
//     // autoColumns:true,
//     // printRowRange: "all",
//     // textDirection: "rtl",
//     printHeader: `
//     <div class="row mt-4 mb-4">
//         <div class="col-12 d-flex justify-content-center align-items-center">
//             <h1>Products Table</h1>
//         </div>
//     </div>
//     <hr>
//     `,
//     printFooter: `
//     <div class="row mt-4">
//         <div class="col-12 d-flex justify-content-center align-items-center">
//             <img src='/static/img/gts-logo.png' alt='gts-logo' style="width: 50%;height: 100%;" />
//         </div>
//     </div>
//     `,
//     // clipboard: true,
//     // clipboardPasteAction: "replace",
//     // resizableRows: true,
//     // resizableRowGuide: true,
//     // resizableColumnGuide: true,
//     // movableColumns: true,
//     ajaxURL: "http://127.0.0.1:8000/adminpanal/product/view/api/",
//     ajaxParams: { page: 1, size: 10 },  // Start with page 1 and size 3
//     progressiveLoad: "scroll",      // Enable progressive loading with scroll
//     placeholder: "No Product Data",
//     selectableRows: true, //make rows selectable
//     // addRowPos: "top",
//     // history: true,
//     paginationSize: 10,
//     columnDefaults: {
//         tooltip: true,
//     },
//     langs: {
//         "ar-eg": { //French language definition
//             "columns": {
//                 "id": "مسلسل",
//                 "number": "الرقم",
//                 "name": "الاسم",
//                 "price": "السعر",
//                 "timestamp": "تاريخ الانشاء",
//             },
//         }
//     },
//     columns: [
//         { title: "ID", field: "id", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
//         { title: "Number", field: "number", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
//         { title: "Name", field: "name", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
//         { title: "Price", field: "price", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
//         { title: "Timestamp", field: "timestamp", hozAlign: "start", sorter: "datetime", headerMenu: headerMenu },
//     ],
// });

//Trigger sort when "Trigger Sort" button is clicked
document.getElementById("sort_trigger").addEventListener("click", function () {
    table.setSort(fieldSEl.options[fieldSEl.selectedIndex].value, dirEl.options[dirEl.selectedIndex].value);
});

document.getElementById("sort_reset").addEventListener("click", function () {
    table.setSort("id", "asc");
});

table.on("rowSelectionChanged", function (data, rows) {
    document.getElementById("select_stats").innerHTML = data.length;
});

//select row on "select all" button click
document.getElementById("select_all").addEventListener("click", function () {
    table.selectRow();
});

//deselect row on "deselect all" button click
document.getElementById("deselect_all").addEventListener("click", function () {
    table.deselectRow();
});

//Delete row on "Delete Row" button click
document.getElementById("del_row").addEventListener("click", function () {
    var rowid = document.getElementById('row_delete');
    if (rowid.value == '') {
        $.notify({
            icon: 'fas fa-trash',
            title: 'Validation Error',
            message: 'Please enter a valid row number.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
    } else {
        table.deleteRow(parseInt(rowid.value));
        rowid.value = '';
    }
});

//Clear table on "Empty the table" button click
document.getElementById("clear").addEventListener("click", function () {
    table.clearData()
});

//Reset table contents on "Reset the table" button click
document.getElementById("reset").addEventListener("click", function () {
    // table.setData("http://127.0.0.1:8000/adminpanal/product/view/api/", { page: 1, size: 10 });
    // Destroy current instance of the table
    table.destroy();
    // Recreate table with initial settings
    table = createTable();
});

document.getElementById('download_btn').addEventListener('click', () => {
    var file_name = document.getElementById('file_name');
    var download_type = document.getElementById('download_type');
    var flag = true;
    if (file_name.value == '') {
        $.notify({
            icon: 'fas fa-font',
            title: 'Validation Error',
            message: 'Please enter a valid file name.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (download_type.value == '') {
        $.notify({
            icon: 'fas fa-gear',
            title: 'Validation Error',
            message: 'Please choose a download type.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }

    if (flag) {
        if (download_type.value == 'csv') table.download("csv", `${file_name.value}.csv`);
        if (download_type.value == 'json') table.download("json", `${file_name.value}.json`);
        if (download_type.value == 'xlsx') table.download("xlsx", `${file_name.value}.xlsx`, { sheetName: file_name.value });
        if (download_type.value == 'pdf') {
            table.download("pdf", `${file_name.value}.pdf`, {
                orientation: "portrait", //set page orientation to portrait
                title: "Products Data", //add title to report
            });
        }
        if (download_type.value == 'html') table.download("html", `${file_name.value}.html`, { style: true });
    }
});

//print button
document.getElementById("print_table").addEventListener("click", function () {
    // Get the selected print range from the dropdown
    var selectedRange = document.getElementById("print_range").value;
    console.log(selectedRange);
    // Update printRowRange on the table instance
    table.options.printRowRange = selectedRange;
    // Print the table using the selected printRowRange
    table.print(false, true);
});


//set locale to French
document.getElementById("lang_arabic").addEventListener("click", function () {
    table.setLocale("ar-eg");
    table.setColumns(defaultColumns());  // Reload columns to apply headerMenu
    // document.getElementById("product_table").setAttribute("dir", "rtl");
});

//set default locale
document.getElementById("lang_default").addEventListener("click", function () {
    table.setLocale("");
    table.setColumns(defaultColumns());  // Reload columns to apply headerMenu
    // document.getElementById("product_table").setAttribute("dir", "ltr");
});

function getAllProducts() {
    $.ajax({
        url: "/adminpanal/product/all/api/",
        method: "GET",
        dataType: "json",
        data: {},
        success: function (t) {
            console.log(t);
            const select = document.getElementById("product_list");
            const editSelect = document.getElementById("product_edit_list");

            // Clear any existing options (optional)
            select.innerHTML = '';
            editSelect.innerHTML = '<option value="" selected disabled>Choose product name...</option>';

            // Add new options
            t.forEach(product => {
                const option1 = document.createElement("option");
                option1.value = product.id;
                option1.textContent = `${product.number} - ${product.name}`;
                select.appendChild(option1);

                const option2 = document.createElement("option");
                option2.value = product.id;
                option2.textContent = `${product.number} - ${product.name}`;
                editSelect.appendChild(option2);
            });

            // Refresh selectpicker to apply changes
            $('.selectpicker').selectpicker('refresh');
        },
    });
}

$(function () {
    getAllProducts();
});

document.getElementById('product_edit_list').addEventListener('change', (event)=>{
    console.log(event.target.value);
    $.ajax({
        url: "/adminpanal/product/single/api/",
        method: "GET",
        dataType: "json",
        data: {
            'product_id': event.target.value,
        },
        success: function (t) {
            console.log(t);
            document.getElementById('e_product_num').value = t.number;
            document.getElementById('e_product_num').removeAttribute('readonly');
            document.getElementById('e_product_name').value = t.name;
            document.getElementById('e_product_name').removeAttribute('readonly');
            document.getElementById('e_product_price').value = t.price;
            document.getElementById('e_product_price').removeAttribute('readonly');
        },
    });
});

document.getElementById('submitEditProduct').addEventListener('click', () => {
    var product_edit_list = document.getElementById('product_edit_list');
    var e_product_num = document.getElementById('e_product_num');
    var e_product_name = document.getElementById('e_product_name');
    var e_product_price = document.getElementById('e_product_price');
    var flag = true;
    console.log(product_edit_list.value);
    if (product_edit_list.value == "") {
        $.notify({
            icon: 'fas fa-trash',
            title: 'Validation Error',
            message: 'Please choose a product to edit.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (e_product_num.value == "") {
        $.notify({
            icon: 'fas fa-trash',
            title: 'Validation Error',
            message: 'Please enter a valid product number.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (e_product_name.value == "") {
        $.notify({
            icon: 'fas fa-trash',
            title: 'Validation Error',
            message: 'Please enter a valid product name.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (e_product_price.value == "" || e_product_price.value < 0) {
        $.notify({
            icon: 'fas fa-trash',
            title: 'Validation Error',
            message: 'Please enter a valid product price.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (flag) {
        // Create FormData object
        const formData = new FormData();
        // Append values to FormData
        formData.append('product_id', product_edit_list.value);
        formData.append('number', e_product_num.value);
        formData.append('name', e_product_name.value);
        formData.append('price', e_product_price.value);
        $.ajax({
            url: "/adminpanal/product/edit/api/",
            type: 'POST',
            dataType: "json",
            processData: false,  // Don't process the data
            contentType: false,  // Don't set content type
            data: formData,
            headers: {
                'X-CSRFToken': document.getElementById('csrfToken').value,
            },
            success: function (response) {
                // console.log(t);
                if (response.status == 'exists') {
                    swal("Sorry!", "Can't edit the product with already existing values.", {
                        icon: "error",
                        buttons: false,
                        timer: 3000
                    });
                }
                if (response.status == 'error') {
                    swal("Sorry!", "Can't edit the selected product.", {
                        icon: "error",
                        buttons: false,
                        timer: 3000
                    });
                }
                if (response.status == 'updated') {
                    swal("Thank you", "The selected product has been updated successfully.", {
                        icon: "success",
                        buttons: false,
                        timer: 3000
                    });
                }
                if (response.status == 'No_Post') {
                    swal("Sorry!", "You have to send a request.", {
                        icon: "error",
                        buttons: false,
                        timer: 3000
                    });
                }
                getAllProducts();
                document.getElementById('resetEditProduct').click();
                document.getElementById("reset").click();
            },
        });
    }
});

document.getElementById('resetEditProduct').addEventListener('click', () => {
    $('#product_edit_list').selectpicker('val', '');
    document.getElementById('e_product_num').value = "";
    document.getElementById('e_product_num').setAttribute('readonly', 'true');
    document.getElementById('e_product_name').value = "";
    document.getElementById('e_product_name').setAttribute('readonly', 'true');
    document.getElementById('e_product_price').value = "";
    document.getElementById('e_product_price').setAttribute('readonly', 'true');
});

document.getElementById('submitDeleteProduct').addEventListener('click', () => {
    var product_list = document.getElementById('product_list');
    var flag = true;
    // Get the selected options as an array of values
    const selectedValues = Array.from(product_list.selectedOptions).map(option => option.value);
    console.log(selectedValues);
    if (selectedValues.length == 0) {
        $.notify({
            icon: 'fas fa-trash',
            title: 'Validation Error',
            message: 'Please choose at least a product to delete.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (flag) {
        // Create FormData object
        const formData = new FormData();
        // Append values to FormData
        // formData.append('f_st_codes', selectedValues);
        selectedValues.forEach((id, index) => {
            formData.append('product_ids', id);
        });
        $.ajax({
            url: "/adminpanal/product/delete/api/",
            type: 'POST',
            dataType: "json",
            processData: false,  // Don't process the data
            contentType: false,  // Don't set content type
            data: formData,
            headers: {
                'X-CSRFToken': document.getElementById('csrfToken').value,
            },
            success: function (response) {
                // console.log(t);
                if (response.status == 'delete_exists') {
                    var spans = ``;
                    if (response.ids) {
                        response.ids.forEach((id) => {
                            console.log(id);
                            spans += `<span class="m-1 col-1">${id}</span>`; // Adding each code inside a span with margin
                        });
                    } else {
                        spans = "No Exists IDs.";
                    }
                    swal("Thank you", "The selected products has been deleted successfully.", {
                        icon: "success",
                        buttons: {
                            confirm: {
                                text: "cannot delete IDs!",
                                className: "btn btn-success-dark",
                            },
                            cancel: {
                                visible: true,
                                className: "btn btn-danger",
                            },
                        },
                    }).then((exists) => {
                        if (exists) {
                            swal({
                                title: "Cannot Delete Product IDs!",
                                content: {
                                    element: "div",
                                    attributes: {
                                        innerHTML: spans,
                                        className: "row" // Insert the concatenated HTML string
                                    },
                                },
                                icon: "error",
                                buttons: {
                                    confirm: {
                                        className: "btn btn-danger",
                                    },
                                },
                            });
                        } else {
                            swal.close();
                        }
                    });
                }
                if (response.status == 'exists') {
                    swal("Sorry!", "Can't delete the selected products, already linked with Nozzles.", {
                        icon: "error",
                        buttons: false,
                        timer: 3000
                    });
                }
                if (response.status == 'deleted') {
                    swal("Thank you", "The selected products has been deleted successfully.", {
                        icon: "success",
                        buttons: false,
                        timer: 3000
                    });
                }
                if (response.status == 'No_Post') {
                    swal("Sorry!", "You have to send a request.", {
                        icon: "error",
                        buttons: false,
                        timer: 3000
                    });
                }
                getAllProducts();
                $('#product_list').selectpicker('val', '');
                document.getElementById("reset").click();
            },
        });
    }
});

document.getElementById('resetDeleteProduct').addEventListener('click', () => {
    $('#product_list').selectpicker('val', '');
});