//define column header menu as column visibility toggle
var headerMenu = function () {
    var menu = [];
    var columns = this.getColumns();

    for (let column of columns) {

        //create checkbox element using font awesome icons
        let icon = document.createElement("i");
        icon.classList.add("fas");
        icon.classList.add(column.isVisible() ? "fa-check-square" : "fa-square");

        //build label
        let label = document.createElement("span");
        let title = document.createElement("span");

        title.textContent = " " + column.getDefinition().title;

        label.appendChild(icon);
        label.appendChild(title);

        //create menu item
        menu.push({
            label: label,
            action: function (e) {
                //prevent menu closing
                e.stopPropagation();

                //toggle current column visibility
                column.toggle();

                //change menu item icon
                if (column.isVisible()) {
                    icon.classList.remove("fa-square");
                    icon.classList.add("fa-check-square");
                } else {
                    icon.classList.remove("fa-check-square");
                    icon.classList.add("fa-square");
                }
            }
        });
    }

    return menu;
};

//Define variables for input elements
var fieldSEl = document.getElementById("sort_field");
var dirEl = document.getElementById("sort_direction");

// //Define variables for input elements
// var fieldEl = document.getElementById("filter_field");
// var typeEl = document.getElementById("filter_type");
// var valueEl = document.getElementById("filter_value");


// //Trigger setFilter function with correct parameters
// function updateFilter() {
//     var filterVal = fieldEl.options[fieldEl.selectedIndex].value;
//     var typeVal = typeEl.options[typeEl.selectedIndex].value;

//     var filter = filterVal;

//     if (filterVal) {
//         table.setFilter(filter, typeVal, valueEl.value);
//     }
// }

// //Update filters on value change
// document.getElementById("filter_field").addEventListener("change", updateFilter);
// document.getElementById("filter_type").addEventListener("change", updateFilter);
// document.getElementById("filter_value").addEventListener("keyup", updateFilter);

// //Clear filters on "Clear Filters" button click
// document.getElementById("filter_clear").addEventListener("click", function () {
//     fieldEl.value = "";
//     typeEl.value = "";
//     valueEl.value = "";

//     table.clearFilter();
// });



// Define variables for input elements
var fieldEl = document.getElementById("filter_field");
var typeEl = document.getElementById("filter_type");
var valueEl = document.getElementById("filter_value");
var filtersContainer = document.getElementById("filters_container");

// Array to store applied filters
var filters = [];

// Apply all filters to the table
function applyFilters() {
    table.clearFilter(); // Clear existing filters
    filters.forEach(filter => {
        table.setFilter(filter.field, filter.type, filter.value);
    });
}

// Add a new filter and display it
function addFilter() {
    var filterVal = fieldEl.value;
    var typeVal = typeEl.value;
    var valueVal = valueEl.value;

    if (filterVal && typeVal && valueVal) {
        // Add new filter to the filters array
        filters.push({ field: filterVal, type: typeVal, value: valueVal });

        // Display the applied filter
        var filterDiv = document.createElement("div");
        filterDiv.className = "alert alert-success-dark d-flex justify-content-between align-items-center mb-2";
        filterDiv.innerHTML = `
            <span><strong>${filterVal}</strong> ${typeVal} <strong>${valueVal}</strong></span>
            <button class="btn btn-sm btn-danger remove-filter">Remove</button>
        `;
        filtersContainer.appendChild(filterDiv);

        // Attach remove filter functionality
        filterDiv.querySelector(".remove-filter").addEventListener("click", function () {
            // Remove the filter from the array
            filters = filters.filter(f => !(f.field === filterVal && f.type === typeVal && f.value === valueVal));
            // Remove the filter from the DOM
            filterDiv.remove();
            // Reapply remaining filters
            applyFilters();
        });

        // Apply filters to the table
        applyFilters();

        // Clear input fields
        fieldEl.value = "";
        typeEl.value = "";
        valueEl.value = "";
    } else {
        $.notify({
            icon: 'fas fa-filter',
            title: 'Filteration Error!',
            message: 'Please fill all filter fields before adding a filter.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
    }
}

// Clear all filters
document.getElementById("filter_clear").addEventListener("click", function () {
    filters = [];
    filtersContainer.innerHTML = "";
    table.clearFilter();
});

// Add event listener for "Add Filter" button
document.getElementById("filter_add").addEventListener("click", addFilter);


// Define column configurations with headerMenu
// function defaultColumns() {
//     return [
//         { title: "ID", field: "id", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
//         { title: "Seq. No", field: "seq_no", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
//         { title: "Fusion Sale", field: "fusion_sale", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
//         { title: "Volume", field: "volume", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
//         { title: "Unit Price", field: "unit_price", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
//         { title: "Amount", field: "amount", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
//         { title: "UM", field: "unit_measure", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
//         { title: "Tips", field: "tips", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
//         { title: "Date", field: "date", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
//         { title: "Type", field: "payment_type", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
//         { title: "Is Taxed", field: "is_taxed", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
//         { title: "Pos", field: "pos", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
//         { title: "Product", field: "product", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
//         { title: "Nozzle", field: "nozzle", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
//         { title: "Pump", field: "pump", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
//         { title: "Station", field: "station", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
//         {
//             title: "Creation Date", field: "timestamp", hozAlign: "start", sorter: "datetime", sorterParams: {
//                 format: "yyyy-MM-dd HH:mm:ss",
//                 alignEmptyValues: "top",
//             }, headerMenu: headerMenu
//         },
//     ];
// }

function defaultColumns() {
    return [
        { title: "ID", field: "id", hozAlign: "start", sorter: "number", bottomCalc: "count", headerMenu: headerMenu },
        { title: "Seq. No", field: "seq_no", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
        { title: "Fusion Sale", field: "fusion_sale", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
        { title: "Unit Price", field: "unit_price", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
        { title: "Volume", field: "volume", hozAlign: "start", sorter: "string", bottomCalc: "sum", bottomCalcParams: { precision: 3 }, headerMenu: headerMenu },
        { title: "Amount", field: "amount", hozAlign: "start", sorter: "string", bottomCalc: "sum", bottomCalcParams: { precision: 3 }, headerMenu: headerMenu },
        { title: "UM", field: "unit_measure", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
        { title: "Tips", field: "tips", hozAlign: "start", sorter: "string", bottomCalc: "sum", bottomCalcParams: { precision: 3 }, headerMenu: headerMenu },
        {
            title: "Date", field: "date", hozAlign: "start", sorter: "datetime", sorterParams: {
                format: "yyyy-MM-dd HH:mm:ss",
                alignEmptyValues: "top",
            }, headerMenu: headerMenu
        },
        { title: "Type", field: "payment_type", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
        { title: "Is Taxed", field: "is_taxed", hozAlign: "start", sorter: "boolean", formatter:"tickCross", headerMenu: headerMenu },
        { title: "Pos", field: "pos", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
        { title: "Product", field: "product", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
        { title: "Nozzle", field: "nozzle", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
        { title: "Pump", field: "pump", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
        { title: "Station", field: "station", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
        {
            title: "Creation Date", field: "timestamp", hozAlign: "start", sorter: "datetime", sorterParams: {
                format: "yyyy-MM-dd HH:mm:ss",
                alignEmptyValues: "top",
            }, headerMenu: headerMenu
        },
    ];
}


// Initial Table Configuration Function
function createTable() {
    return new Tabulator("#sales_table", {
        layout: "fitColumns",          // Fit columns to the table width
        responsiveLayout: "hide",       // Hide columns that don’t fit
        // height: window.innerHeight / 2,
        minHeight: window.innerHeight / 2,
        maxHeight: window.innerHeight - 230,
        printAsHtml: true,
        printStyled: true,
        textDirection: "ltr",
        // groupBy: ["station_name", "status"],
        // groupStartOpen: true,
        // groupToggleElement: "header",
        // groupHeaderPrint: function(value, count, data, group){
        //     return value;
        // },
        // groupHeaderDownload: function(value, count, data, group){
        //     return value;
        // },
        // downloadRowRange: "all",
        printHeader: `
        <div class="row mt-4 mb-4">
            <div class="col-12 d-flex justify-content-center align-items-center">
                <h1>Sales Table</h1>
            </div>
        </div>
        <hr>`,
        printFooter: `
        <div class="row mt-4">
            <div class="col-12 d-flex justify-content-center align-items-center">
                <img src='/static/img/gts-logo.png' alt='gts-logo' style="width: 50%;height: 100%;" />
            </div>
        </div>
        `,
        ajaxURL: "http://127.0.0.1:8000/adminpanal/sales/view/api/",
        ajaxParams: { page: 1, size: 10 },
        progressiveLoad: "scroll",
        placeholder: "No Sales Data",
        // selectableRows: true,
        paginationSize: 10,
        columnDefaults: {
            tooltip: true,
        },
        langs: {
            "ar-eg": {
                "columns": {
                    "id": "مسلسل",
                    "seq_no": "التسلسل",
                    "fusion_sale": "بيع الاندماج",
                    "volume": "الحجم",
                    "unit_price": "سعر الوحدة",
                    "amount": "المبلغ",
                    "unit_measure": "وحدة القياس",
                    "tips": "نصائح",
                    "date": "التاريخ",
                    "payment_type": "نوع الدفع",
                    "is_taxed": "هل خاضع للضرائب",
                    "pos": "نقطة البيع",
                    "product": "المنتج",
                    "nozzle": "فوهة",
                    "pump": "مضخة",
                    "station": "محطة",
                    "timestamp": "تاريخ الإنشاء",
                },
            }
        },
        columns: defaultColumns(),
    });
}

var table = createTable();

// var table = new Tabulator("#pos_table", {
//     layout: "fitColumns",          // Fit columns to the table width
//     responsiveLayout: "hide",       // Hide columns that don’t fit
//     height: window.innerHeight / 2,
//     printAsHtml: true,
//     printStyled: true,
//     // autoColumns:true,
//     // printRowRange: "all",
//     // textDirection: "rtl",
//     printHeader: `
//     <div class="row mt-4 mb-4">
//         <div class="col-12 d-flex justify-content-center align-items-center">
//             <h1>Products Table</h1>
//         </div>
//     </div>
//     <hr>
//     `,
//     printFooter: `
//     <div class="row mt-4">
//         <div class="col-12 d-flex justify-content-center align-items-center">
//             <img src='/static/img/gts-logo.png' alt='gts-logo' style="width: 50%;height: 100%;" />
//         </div>
//     </div>
//     `,
//     // clipboard: true,
//     // clipboardPasteAction: "replace",
//     // resizableRows: true,
//     // resizableRowGuide: true,
//     // resizableColumnGuide: true,
//     // movableColumns: true,
//     ajaxURL: "http://127.0.0.1:8000/adminpanal/product/view/api/",
//     ajaxParams: { page: 1, size: 10 },  // Start with page 1 and size 3
//     progressiveLoad: "scroll",      // Enable progressive loading with scroll
//     placeholder: "No Product Data",
//     selectableRows: true, //make rows selectable
//     // addRowPos: "top",
//     // history: true,
//     paginationSize: 10,
//     columnDefaults: {
//         tooltip: true,
//     },
//     langs: {
//         "ar-eg": { //French language definition
//             "columns": {
//                 "id": "مسلسل",
//                 "number": "الرقم",
//                 "name": "الاسم",
//                 "price": "السعر",
//                 "timestamp": "تاريخ الانشاء",
//             },
//         }
//     },
//     columns: [
//         { title: "ID", field: "id", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
//         { title: "Number", field: "number", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
//         { title: "Name", field: "name", hozAlign: "start", sorter: "string", headerMenu: headerMenu },
//         { title: "Price", field: "price", hozAlign: "start", sorter: "number", headerMenu: headerMenu },
//         { title: "Timestamp", field: "timestamp", hozAlign: "start", sorter: "datetime", headerMenu: headerMenu },
//     ],
// });

//Trigger sort when "Trigger Sort" button is clicked
document.getElementById("sort_trigger").addEventListener("click", function () {
    table.setSort(fieldSEl.options[fieldSEl.selectedIndex].value, dirEl.options[dirEl.selectedIndex].value);
});

document.getElementById("sort_reset").addEventListener("click", function () {
    table.setSort("id", "asc");
});

table.on("rowSelectionChanged", function (data, rows) {
    document.getElementById("select_stats").innerHTML = data.length;
});

//select row on "select all" button click
document.getElementById("select_all").addEventListener("click", function () {
    table.selectRow();
});

//deselect row on "deselect all" button click
document.getElementById("deselect_all").addEventListener("click", function () {
    table.deselectRow();
});

//Delete row on "Delete Row" button click
document.getElementById("del_row").addEventListener("click", function () {
    var rowid = document.getElementById('row_delete');
    if (rowid.value == '') {
        $.notify({
            icon: 'fas fa-trash',
            title: 'Validation Error',
            message: 'Please enter a valid row number.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
    } else {
        table.deleteRow(parseInt(rowid.value));
        rowid.value = '';
    }
});

//Clear table on "Empty the table" button click
document.getElementById("clear").addEventListener("click", function () {
    table.clearData()
});

//Reset table contents on "Reset the table" button click
document.getElementById("reset").addEventListener("click", function () {
    // table.setData("http://127.0.0.1:8000/adminpanal/product/view/api/", { page: 1, size: 10 });
    // Destroy current instance of the table
    table.destroy();
    // Recreate table with initial settings
    table = createTable();
});

document.getElementById('download_btn').addEventListener('click', () => {
    var file_name = document.getElementById('file_name');
    var download_type = document.getElementById('download_type');
    var flag = true;
    if (file_name.value == '') {
        $.notify({
            icon: 'fas fa-font',
            title: 'Validation Error',
            message: 'Please enter a valid file name.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }
    if (download_type.value == '') {
        $.notify({
            icon: 'fas fa-gear',
            title: 'Validation Error',
            message: 'Please choose a download type.',
        }, {
            type: 'danger',
            placement: {
                from: "top",
                align: "right"
            },
            time: 1000,
        });
        flag = false;
    }

    if (flag) {
        if (download_type.value == 'csv') table.download("csv", `${file_name.value}.csv`);
        if (download_type.value == 'json') table.download("json", `${file_name.value}.json`);
        if (download_type.value == 'xlsx') table.download("xlsx", `${file_name.value}.xlsx`, { sheetName: file_name.value });
        if (download_type.value == 'pdf') {
            table.download("pdf", `${file_name.value}.pdf`, {
                orientation: "portrait", //set page orientation to portrait
                title: "Sales Data", //add title to report
            });
        }
        if (download_type.value == 'html') table.download("html", `${file_name.value}.html`, { style: true });
    }
});

//print button
document.getElementById("print_table").addEventListener("click", function () {
    // Get the selected print range from the dropdown
    var selectedRange = document.getElementById("print_range").value;
    console.log(selectedRange);
    // Update printRowRange on the table instance
    table.options.printRowRange = selectedRange;
    // Print the table using the selected printRowRange
    table.print(false, true);
});


//set locale to French
document.getElementById("lang_arabic").addEventListener("click", function () {
    table.setLocale("ar-eg");
    table.setColumns(defaultColumns());  // Reload columns to apply headerMenu
    // document.getElementById("pos_table").setAttribute("dir", "rtl");
});

//set default locale
document.getElementById("lang_default").addEventListener("click", function () {
    table.setLocale("");
    table.setColumns(defaultColumns());  // Reload columns to apply headerMenu
    // document.getElementById("pos_table").setAttribute("dir", "ltr");
});