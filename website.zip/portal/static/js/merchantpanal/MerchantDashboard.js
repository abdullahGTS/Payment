function getAllProducts() {
    $.ajax({
        url: "/merchantpanal/dashboard/product/all/api/",
        method: "GET",
        dataType: "json",
        data: {},
        success: function (t) {
            console.log(t);
            var product_cards = document.getElementById('product_cards');
            var temp_list = ``;
            t.forEach(product => {
                temp_list += `
                <div class="col-sm-6 col-md-4 mb-2">
                    <div class="card card-stats card-round">
                        <div class="card-body">
                            <div class="row align-items-center">
                                <div class="col-icon">
                                    <div class="icon-big text-center bg-green-dark bubble-shadow-small"
                                        style="border-radius: 8px;">
                                        <i class="fas fa-droplet text-white"></i>
                                    </div>
                                </div>
                                <div class="col col-stats ms-3 ms-sm-0">
                                    <div class="numbers">
                                        <p class="card-category">${product.name}</p>
                                        <h4 class="card-title">$ ${product.price}</h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>`;
            });
            product_cards.innerHTML = temp_list;
        },
    });
}

function animateTotals() {
    // Select all elements with the "count-up" class
    const counters = document.querySelectorAll(".count-up");

    // Loop through each counter
    counters.forEach(counter => {
        const target = parseInt(counter.getAttribute("data-target"), 10); // Get the target number

        gsap.to(counter, {
            duration: 5, // Duration in seconds
            innerHTML: target, // Target number
            snap: { innerHTML: 1 }, // Ensure it rounds to integers
            onUpdate: function () {
                counter.textContent = Math.round(this.targets()[0].innerHTML).toLocaleString();
            }
        });
    });
}

function getTotals() {
    $.ajax({
        url: "/merchantpanal/dashboard/totals/api/",
        method: "GET",
        dataType: "json",
        data: {},
        success: function (t) {
            console.log(t);
            document.getElementById('total_transactions').setAttribute('data-target', t.total_transactions);
            document.getElementById('total_users').setAttribute('data-target', t.total_users);
            document.getElementById('total_stations').setAttribute('data-target', t.total_stations);
            document.getElementById('total_poses').setAttribute('data-target', t.total_poses);
            animateTotals();
        },
    });
}

function getAllStations() {
    $.ajax({
        url: "/merchantpanal/dashboard/stations/all/api/",
        method: "GET",
        dataType: "json",
        data: {},
        success: function (t) {
            console.log(t);
            // Create the map centered at the first station
            const map = new google.maps.Map(document.getElementById("map"), {
                center: { lat: parseFloat(t[0].lat), lng: parseFloat(t[0].lng) },
                zoom: 4,
            });

            // Add markers for each station
            t.forEach(station => {
                const marker = new google.maps.Marker({
                    position: { lat: parseFloat(station.lat), lng: parseFloat(station.lng) },
                    map: map,
                    title: station.name // Tooltip on hover
                });

                // Optional: Add an info window for each marker
                const infoWindow = new google.maps.InfoWindow({
                    content: `<h4>${station.name}</h4><p>Lat: ${parseFloat(station.lat)}, Lng: ${parseFloat(station.lng)}</p>`,
                });

                marker.addListener("click", () => {
                    infoWindow.open(map, marker);
                });
            });
        },
    });
}

function getAndDrawStationsPieChart() {
    $.ajax({
        url: "/merchantpanal/dashboard/stations/status/api/",
        method: "GET",
        dataType: "json",
        data: {},
        success: function (t) {
            console.log(t);
            var options = {
                series: t.series,
                chart: {
                    width: '100%',
                    minHeight: '100%',
                    type: 'pie',
                    toolbar: {
                        show: true, // Enables the toolbar
                        tools: {
                            download: true, // Allows downloading the chart
                            selection: false, // Not applicable for pie charts
                            zoom: false, // Not applicable for pie charts
                            zoomin: false, // Not applicable for pie charts
                            zoomout: false, // Not applicable for pie charts
                            pan: false, // Not applicable for pie charts
                            reset: false // Not applicable for pie charts
                        },
                        export: {
                            csv: {
                                filename: "stations_status", // File name for CSV export
                                columnDelimiter: ',',
                                headerCategory: 'Category',
                                headerValue: 'Value',
                            },
                            svg: {
                                filename: "stations_status" // File name for SVG export
                            },
                            png: {
                                filename: "stations_status" // File name for PNG export
                            }
                        }
                    }
                },
                labels: t.labels,
                theme: {
                    monochrome: {
                        enabled: true, // Enable the monochrome theme
                        color: '#176e38', // Base color (e.g., Dodger Blue)
                        shadeTo: 'light', // Direction of shade: 'light' or 'dark'
                        shadeIntensity: 0.5, // Intensity of the shade (0 to 1)
                    },
                },
                plotOptions: {
                    pie: {
                        dataLabels: {
                            offset: -5,
                        },
                    },
                },
                grid: {
                    padding: {
                        top: 0,
                        bottom: 0,
                        left: 0,
                        right: 0,
                    },
                },
                dataLabels: {
                    formatter(val, opts) {
                        const name = opts.w.globals.labels[opts.seriesIndex];
                        return [name, val.toFixed(1) + '%'];
                    },
                },
                legend: {
                    show: true, // Enable the legend
                    position: 'bottom', // Position the legend below the chart
                    horizontalAlign: 'center',
                },
            };
            var chart = new ApexCharts(document.querySelector("#stationPieChart"), options);
            chart.render();
        },
    });
}

function getAndDrawPosesPieChart() {
    $.ajax({
        url: "/merchantpanal/dashboard/poses/status/api/",
        method: "GET",
        dataType: "json",
        data: {},
        success: function (t) {
            console.log(t);
            var options = {
                series: t.series,
                chart: {
                    width: '100%',
                    minHeight: '100%',
                    type: 'pie',
                    toolbar: {
                        show: true, // Enables the toolbar
                        tools: {
                            download: true, // Allows downloading the chart
                            selection: false, // Not applicable for pie charts
                            zoom: false, // Not applicable for pie charts
                            zoomin: false, // Not applicable for pie charts
                            zoomout: false, // Not applicable for pie charts
                            pan: false, // Not applicable for pie charts
                            reset: false // Not applicable for pie charts
                        },
                        export: {
                            csv: {
                                filename: "pos_status", // File name for CSV export
                                columnDelimiter: ',',
                                headerCategory: 'Category',
                                headerValue: 'Value',
                            },
                            svg: {
                                filename: "pos_status" // File name for SVG export
                            },
                            png: {
                                filename: "pos_status" // File name for PNG export
                            }
                        }
                    }
                },
                labels: t.labels,
                theme: {
                    monochrome: {
                        enabled: true, // Enable the monochrome theme
                        color: '#1a2035', // Base color (e.g., Dodger Blue)
                        shadeTo: 'light', // Direction of shade: 'light' or 'dark'
                        shadeIntensity: 0.5, // Intensity of the shade (0 to 1)
                    },
                },
                plotOptions: {
                    pie: {
                        dataLabels: {
                            offset: -5,
                        },
                    },
                },
                grid: {
                    padding: {
                        top: 0,
                        bottom: 0,
                        left: 0,
                        right: 0,
                    },
                },
                dataLabels: {
                    formatter(val, opts) {
                        const name = opts.w.globals.labels[opts.seriesIndex];
                        return [name, val.toFixed(1) + '%'];
                    },
                },
                legend: {
                    show: true, // Enable the legend
                    position: 'bottom', // Position the legend below the chart
                    horizontalAlign: 'center',
                },
            };
            var chart = new ApexCharts(document.querySelector("#POSPieChart"), options);
            chart.render();
        },
    });
}

function animateProgress() {
    // Select all progress bars
    const progressBars = document.querySelectorAll('.progress-bar');
    // Loop through each progress bar and animate it
    progressBars.forEach(progressBar => {
        const targetValue = parseInt(progressBar.getAttribute('aria-valuenow'), 10); // Get the target value
        const percentageText = progressBar.closest('.progress').nextElementSibling.querySelector('.progress-percentage'); // Get the percentage text element

        // Animate the progress bar
        gsap.to(progressBar, {
            width: `${targetValue}%`, // Set width dynamically based on the target value
            duration: 5, // Animation duration
            onUpdate: function () {
                // Update the percentage text dynamically
                const currentWidth = parseFloat(progressBar.style.width || 0);
                const percentage = Math.round(currentWidth);
                percentageText.textContent = `${percentage}%`;
            }
        });
    });
}

function getTopThreeStations() {
    $.ajax({
        url: "/merchantpanal/dashboard/stations/top/three/api/",
        method: "GET",
        dataType: "json",
        data: {},
        success: function (t) {
            console.log(t);
            var col_size = [12, 10, 8];
            var temp_list = ``;
            if (t.length > 0) {
                t.forEach((station, index) => {
                    var color = '';
                    if(index == 0){
                        color = 'green';
                    }else{
                        color = 'blue';
                    }
                    temp_list += `
                    <div class="row">
                        <div class="col-12 col-md-${col_size[index]}">
                            <div class="card">
                                <div class="card-body d-flex align-items-center">
                                    <i class="fas fa-${index+1} text-${color}-dark me-5 ms-4" style="font-size: 80px;opacity: 0.5;"></i>
                                    <div class="d-flex flex-column w-100">
                                        <div class="d-flex justify-content-between">
                                            <div>
                                                <h5><b>${station.station_name}</b></h5>
                                            </div>
                                            <h3 class="text-${color}-dark fw-bold">$ <span class="count-up" data-target="${station.sales}">0</span></h3>
                                        </div>
                                        <div class="progress progress-sm mt-2">
                                            <div class="progress-bar bg-${color}-dark" role="progressbar" aria-valuenow="${station.percentage}"
                                                aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                        <div class="d-flex justify-content-between mt-2">
                                            <p class="text-muted mb-0">Change</p>
                                            <p class="text-muted mb-0 progress-percentage">0%</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>`;
                })
                document.getElementById('top_three_stations').innerHTML = temp_list;
                animateTotals();
                animateProgress();
            }
        },
    });
}


$(function () {
    getAllProducts();
    getTotals();
    getAllStations();
    getAndDrawStationsPieChart();
    getAndDrawPosesPieChart();
    getTopThreeStations();
});


// Register the ScrollTrigger plugin
gsap.registerPlugin(ScrollTrigger);

// Select all elements with the "scroll-animate" class
const scrollElements = document.querySelectorAll('.scroll-animate');

// Loop through each element and create a ScrollTrigger animation
scrollElements.forEach(element => {
    gsap.fromTo(
        element,
        { opacity: 0, y: 50 }, // Initial state
        {
            opacity: 1,
            y: 0,
            duration: 1,
            ease: "power2.out",
            scrollTrigger: {
                trigger: element, // Trigger animation when the element enters the viewport
                start: "top 80%", // Animation starts when top of element is 80% of the viewport
                end: "top 50%", // Animation ends when top of element is 50% of the viewport
                toggleActions: "play none none reverse", // Play animation on enter, reverse on leave
            }
        }
    );
});