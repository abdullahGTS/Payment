import os
import secrets
import string
from django.db import models
from django.core.files.storage import default_storage
from django.dispatch import receiver
from django.db.models.signals import post_save, pre_delete, post_delete
from django.utils.text import slugify

# Create your models here.
    
class CentralArea(models.Model):
    name = models.CharField(max_length=256)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name
    
    
class Governorate(models.Model):
    name = models.CharField(max_length=256)
    centralArea = models.ForeignKey(CentralArea, on_delete=models.CASCADE, related_name='centralAreaGov')
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name
    

class Product(models.Model):
    number = models.PositiveBigIntegerField()
    name = models.CharField(max_length=256)
    price = models.FloatField()
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name



class Fusion(models.Model):
    station_code = models.CharField(max_length=254)
    station_name = models.CharField(max_length=254)
    ip = models.CharField(max_length=254)
    port = models.CharField(max_length=254)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.station_code} - {self.ip}:{self.port}"


class FusionFileHandler(models.Model):
    file = models.FileField(upload_to='files/Fusions/')
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.file.name


@receiver(post_delete, sender=FusionFileHandler)
def Fusion_delete_related_files(sender, instance, **kwargs):
    file_path = instance.file.path
    if default_storage.exists(file_path):
        default_storage.delete(file_path)


# Custom upload path function
def upload_to_station(instance, filename):
    # Generate a folder name using the station's name (slugified)
    station_name_slug = slugify(instance.station.fusion.station_name)
    # Construct the upload path
    upload_path = os.path.join('files', 'Stations', station_name_slug, filename)
    return upload_path


class Station(models.Model):
    fusion = models.ForeignKey(Fusion, on_delete=models.CASCADE, related_name='stationFusion')
    long = models.CharField(max_length=256, blank=True, null=True)
    lat = models.CharField(max_length=256, blank=True, null=True)
    last_connection = models.DateTimeField()
    governorate = models.ForeignKey(Governorate, on_delete=models.CASCADE, related_name='stationGov', blank=True, null=True)
    central_area = models.ForeignKey(CentralArea, on_delete=models.CASCADE, related_name='stationCenArea', blank=True, null=True)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.fusion.station_name


class StationFileHandler(models.Model):
    file = models.FileField(upload_to=upload_to_station)
    station = models.ForeignKey(Station, on_delete=models.CASCADE, related_name='Stationfiles')
    timestamp = models.DateTimeField(auto_now_add=True)


@receiver(pre_delete, sender=Station)
def Station_delete_related_files(sender, instance, **kwargs):
    """
    Signal handler to delete all related FileHandler objects and their associated files.
    """
    file_handlers = instance.Stationfiles.all()
    for file_handler in file_handlers:
        file_path = file_handler.file.path
        if default_storage.exists(file_path):
            default_storage.delete(file_path)
        file_handler.delete()



class Pump(models.Model):
    number = models.PositiveBigIntegerField()
    station = models.ForeignKey(Station, on_delete= models.CASCADE, related_name='stationPump')
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'Pump {self.number}'


class Nozzle(models.Model):
    number = models.PositiveBigIntegerField()
    product = models.ForeignKey(
        Product, on_delete=models.CASCADE, related_name='NozzleProduct')
    pump = models.ForeignKey(
        Pump, on_delete=models.CASCADE, related_name='pumpNozzle')
    station = models.ForeignKey(
        Station, on_delete=models.CASCADE, related_name='stationNozzle')
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'Nozzle {self.number}'


pos_status = [
    ('c', 'Created'),
    ('off', 'Offline'),
    ('on', 'Online')
]


class Pos(models.Model):
    android_id = models.CharField(max_length=256)
    pumps = models.ManyToManyField(Pump)
    station = models.ForeignKey(
        Station, on_delete=models.CASCADE, related_name='PosStation')
    status = models.CharField(max_length=50, choices=pos_status)
    last_connection = models.DateTimeField()
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.android_id


@receiver(post_save, sender=Pos)
def PosTokenCreate(sender, instance, created, **kwargs):
    if created:
        PosToken.objects.create(
            pos=instance,
            token=generate_pos_token()
        )

def generate_pos_token(length=16):
    """Generate a random user token of specified length."""
    characters = string.ascii_letters + string.digits
    token = ''.join(secrets.choice(characters) for _ in range(length))
    return token


class PosToken(models.Model):
    pos = models.ForeignKey(Pos, on_delete=models.CASCADE, related_name='PosToken')
    token = models.CharField(max_length=254)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.pos.android_id


class Tax(models.Model):
    group = models.ForeignKey('account.UserGroup', on_delete=models.CASCADE, related_name='taxGroup')
    rin = models.CharField(max_length=256)
    companyTradeName = models.CharField(max_length=256)
    branchCode = models.CharField(max_length=256)
    branchAddress_country = models.CharField(max_length=256)
    branchAddress_governate = models.CharField(max_length=256)
    branchAddress_regionCity = models.CharField(max_length=256)
    branchAddress_street = models.CharField(max_length=256)
    branchAddress_buildingNumber = models.CharField(max_length=256)
    deviceSerialNumber = models.CharField(max_length=256)
    syndicateLicenseNumber = models.CharField(max_length=256, blank=True)
    activityCode = models.CharField(max_length=256)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.rin
