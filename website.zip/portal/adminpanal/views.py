from datetime import datetime, timedelta
import json
import re
from django.http import HttpResponseRedirect, JsonResponse
from django.shortcuts import render
from .decorators import is_admin_login
from account.models import *
from .models import *
import xml.etree.ElementTree as ET
import pandas as pd
from django.core.paginator import Paginator
from django.contrib.auth.hashers import check_password, make_password
from django.views.decorators.csrf import csrf_exempt
from django.middleware.csrf import get_token
from merchantpanal.models import Transaction
from django.db.models import Count, Case, When, IntegerField, Sum, F
# Create your views here.


@is_admin_login
def InitView(request):
    return HttpResponseRedirect('/adminpanal/dashboard/')


@is_admin_login
def DashboardView(request):
    admin_obj = Token.objects.get(
        token=request.session.get('admin_token')).user
    context = {
        'user': admin_obj,
    }
    return render(request, 'adminpanal/AdminDashboard.html', context)


def DashboardProductAllApi(request):
    if request.method == "GET":
        products = Product.objects.all()
        product_list = [
            {
                "name": product.name,
                "price": product.price,
            }
            for product in products
        ]
        return JsonResponse(data=product_list, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)


def DashboardTotalsApi(request):
    if request.method == "GET":
        total_administrators = UserAccount.objects.filter(role_id=1).count()
        total_merchants = UserAccount.objects.filter(role_id=2).count()
        total_groups = UserGroup.objects.count()
        total_stations = Station.objects.count()
        total_poses = Pos.objects.count()
        total_transactions = Transaction.objects.count()
        totals_list = {
            "total_administrators": total_administrators,
            "total_merchants": total_merchants,
            "total_groups": total_groups,
            "total_stations": total_stations,
            "total_poses": total_poses,
            "total_transactions": total_transactions,
        }
        return JsonResponse(data=totals_list, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)


def DashboardStationsAllApi(request):
    if request.method == "GET":
        stations = Station.objects.select_related('fusion').all()
        stations_list = [
            {
                "name": station.fusion.station_name,
                "lat": station.lat,
                "lng": station.long,
            }
            for station in stations
        ]
        return JsonResponse(data=stations_list, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)


def DashboardStationsStatusApi(request):
    if request.method == "GET":
        stations = Station.objects.select_related('fusion').all()
        
        offline_threshold = datetime.now() - timedelta(minutes=15)
        
        counts = stations.aggregate(
            online=Count(Case(
                When(last_connection__gte=offline_threshold, then=1),
                output_field=IntegerField(),
            )),
            offline=Count(Case(
                When(last_connection__lt=offline_threshold, then=1),
                output_field=IntegerField(),
            )),
        )

        online_stations_count = counts['online']
        offline_stations_count = counts['offline']

        print(f"Online stations: {online_stations_count}")
        print(f"Offline stations: {offline_stations_count}")
        
        data = {
            'series': [
                counts['online'],
                counts['offline'],
            ],
            'labels': [
                'online',
                'offline'
            ],
        }
        return JsonResponse(data=data, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)


def DashboardPOSesStatusApi(request):
    if request.method == "GET":
        poses = Pos.objects.select_related('fusion').all()
        
        offline_threshold = datetime.now() - timedelta(minutes=15)
        
        counts = poses.aggregate(
            online=Count(Case(
                When(last_connection__gte=offline_threshold, then=1),
                output_field=IntegerField(),
            )),
            offline=Count(Case(
                When(last_connection__lt=offline_threshold, then=1),
                output_field=IntegerField(),
            )),
        )

        online_poses_count = counts['online']
        offline_poses_count = counts['offline']

        print(f"Online poses: {online_poses_count}")
        print(f"Offline poses: {offline_poses_count}")
        
        data = {
            'series': [
                counts['online'],
                counts['offline'],
            ],
            'labels': [
                'online',
                'offline'
            ],
        }
        return JsonResponse(data=data, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)



# def DashboardStationsTopThreeApi(request):
#     if request.method == "GET":
#         # Get today's and yesterday's date range
#         now = datetime.now()
#         start_of_today = datetime(now.year, now.month, now.day)
#         start_of_yesterday = start_of_today - timedelta(days=1)
#         end_of_yesterday = start_of_today - timedelta(seconds=1)

#         # Fetch sales data for today
#         today_sales = (
#             Transaction.objects.filter(date__gte=start_of_today)
#             .values('station__fusion__station_name')  # Group by station name
#             .annotate(total_sales_today=Sum('amount'))  # Sum sales for today
#         )

#         # Fetch sales data for yesterday
#         yesterday_sales = (
#             Transaction.objects.filter(date__range=(start_of_yesterday, end_of_yesterday))
#             .values('station__fusion__station_name')  # Group by station name
#             .annotate(total_sales_yesterday=Sum('amount'))  # Sum sales for yesterday
#         )

#         # Prepare a dictionary for quick lookup of yesterday's sales
#         yesterday_sales_dict = {
#             sale['station__fusion__station_name']: sale['total_sales_yesterday'] for sale in yesterday_sales
#         }

#         # Calculate the percentage change and prepare the result
#         results = []
#         for sale in today_sales:
#             station_name = sale['station__fusion__station_name']
#             sales_today = sale['total_sales_today']
#             sales_yesterday = yesterday_sales_dict.get(station_name, 0)
            
#             # Calculate percentage change and cap it at 100%
#             if sales_yesterday > 0:
#                 percent_change = ((sales_today - sales_yesterday) / sales_yesterday) * 100
#                 percent_change = min(percent_change, 100)  # Cap percentage at 100%
#             else:
#                 percent_change = 0.0  # If no sales yesterday, set to 0%

#             results.append({
#                 'station_name': station_name,
#                 'sales': sales_today,
#                 'percent': round(percent_change, 2),  # Round to 2 decimal places
#             })

#         # Sort by sales descending and get the top 3
#         top_three_stations = sorted(results, key=lambda x: x['sales'], reverse=True)[:3]
#         print(top_three_stations)
#         return JsonResponse(data=top_three_stations, safe=False)
#     return JsonResponse(data={'status': 'No Get'}, safe=False)

def DashboardStationsTopThreeApi(request):
    if request.method == "GET":
        # Get today's and yesterday's date range
        now = datetime.now()
        start_of_today = datetime(now.year, now.month, now.day)
        start_of_yesterday = start_of_today - timedelta(days=1)
        end_of_yesterday = start_of_today - timedelta(seconds=1)

        # Fetch sales data for today
        today_sales = (
            Transaction.objects.filter(date__gte=start_of_today)
            .values('station__fusion__station_name')  # Group by station name
            .annotate(total_sales_today=Sum('amount'))  # Sum sales for today
        )

        # Fetch sales data for yesterday
        yesterday_sales = (
            Transaction.objects.filter(date__range=(start_of_yesterday, end_of_yesterday))
            .values('station__fusion__station_name')  # Group by station name
            .annotate(total_sales_yesterday=Sum('amount'))  # Sum sales for yesterday
        )

        # Prepare a dictionary for quick lookup of yesterday's sales
        yesterday_sales_dict = {
            sale['station__fusion__station_name']: sale['total_sales_yesterday'] for sale in yesterday_sales
        }

        # Calculate the percentage change and prepare the result
        results = []
        for sale in today_sales:
            station_name = sale['station__fusion__station_name']
            sales_today = sale['total_sales_today']
            sales_yesterday = yesterday_sales_dict.get(station_name, 0)

            # Calculate percentage change
            if sales_yesterday > 0:
                percent_change = ((sales_today - sales_yesterday) / sales_yesterday) * 100
            else:
                percent_change = 100.0  # If no sales yesterday, assume 100% growth

            # Only include stations with non-negative percentage change
            if percent_change >= 0:
                results.append({
                    'station_name': station_name,
                    'sales': sales_today,
                    'percentage': round(percent_change, 2),  # Round to 2 decimal places
                })

        # Sort by sales descending and get the top 3
        top_three_stations = sorted(results, key=lambda x: x['sales'], reverse=True)[:3]

        return JsonResponse(data=top_three_stations, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)



@is_admin_login
def UsersView(request):
    admin_obj = Token.objects.get(
        token=request.session.get('admin_token')).user
    context = {
        'user': admin_obj,
    }
    return render(request, 'adminpanal/AdminUsers.html', context)


def UsersViewApi(request):
    if request.method == "GET":
        page = int(request.GET.get('page', 1))  # Default to page 1
        size = int(request.GET.get('size', 10))  # Default to 10 items per page

        users = UserAccount.objects.all()
        paginator = Paginator(users, size)
        current_page = paginator.page(
            page) if paginator.num_pages >= page else paginator.page(1)

        data = [
            {
                'id': user.id,
                'first_name': user.first_name,
                'last_name': user.last_name,
                'email': user.email,
                'role': user.role.type,
                'image': user.image.url if user.image else '/static/img/avater.png',
                'add_date': user.add_date.strftime("%Y-%m-%d %H:%M:%S"),
                'first_login': user.first_login,
                'is_locked': user.is_locked,
                'attempts': user.attempts,
            }
            for user in current_page.object_list
        ]

        return JsonResponse({
            'data': data,
            'last_page': paginator.num_pages
        }, safe=False)
    return JsonResponse({'status': 'No Get'}, safe=False)


def UsersRolesApi(request):
    if request.method == "GET":
        roles = UserType.objects.all()
        role_list = [
            {
                "id": role.id,
                "type": role.type,
            }
            for role in roles
        ]
        return JsonResponse(data=role_list, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)


def UsersAddApi(request):
    if request.method == "POST":
        first_name = request.POST.get('first_name', None)
        last_name = request.POST.get('last_name', None)
        email = request.POST.get('email', None)
        password = request.POST.get('password', None)
        role = request.POST.get('role', None)
        first_login = request.POST.get('first_login', None)
        is_locked = request.POST.get('is_locked', None)
        check_user = UserAccount.objects.filter(email=email)
        if check_user.exists():
            return JsonResponse(data={'status': 'exists'}, safe=False)
        new_user = UserAccount.objects.create(
            first_name=first_name,
            last_name=last_name,
            email=email,
            password=make_password(password),
            role_id=role,
            first_login=True if first_login == 'true' else False,
            is_locked=True if is_locked == 'true' else False,
        )
        if request.FILES:
            profile_picture = request.FILES.get('profile_picture', None)
            if profile_picture:
                new_user.image = profile_picture
                new_user.save()
        return JsonResponse(data={'status': 'added'}, safe=False)
    return JsonResponse(data={'status': 'No Post'}, safe=False)


def UsersAllApi(request):
    if request.method == "GET":
        users = UserAccount.objects.select_related('role').all()
        users_list = [
            {
                "id": user.id,
                "first_name": user.first_name,
                "last_name": user.last_name,
                "email": user.email,
                "role": user.role.type,
            }
            for user in users
        ]
        return JsonResponse(data=users_list, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)


def UsersSingleApi(request):
    if request.method == "GET":
        user_id = request.GET.get('user_id', None)
        user = UserAccount.objects.get(id=user_id)
        user_details = {
            "id": user.id,
            "first_name": user.first_name,
            "last_name": user.last_name,
            "email": user.email,
            "role": user.role.id,
            "imageUrl": user.image.url if user.image else '',
            "imageAlt": user.image.file.name if user.image else '',
            "first_login": user.first_login,
            "is_locked": user.is_locked,
        }
        return JsonResponse(data=user_details, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)


def UsersEditApi(request):
    if request.method == "POST":
        user_id = request.POST.get('user_id', None)
        e_first_name = request.POST.get('e_first_name', None)
        e_last_name = request.POST.get('e_last_name', None)
        e_email = request.POST.get('e_email', None)
        e_role = request.POST.get('e_role', None)
        e_first_login = request.POST.get('e_first_login', None)
        e_is_locked = request.POST.get('e_is_locked', None)
        e_pp_delete_flag = request.POST.get('e_pp_delete_flag', None)
        e_profile_picture = request.FILES.get('e_profile_picture', None)
        
        check_user = UserAccount.objects.exclude(id=user_id).filter(email=e_email)
        if check_user.exists():
            return JsonResponse(data={'status': 'exists'}, safe=False)
        try:
            user_obj = UserAccount.objects.get(id=user_id)
            user_obj.first_name=e_first_name
            user_obj.last_name=e_last_name
            user_obj.email=e_email
            user_obj.role_id=e_role
            user_obj.first_login=True if e_first_login == 'true' else False
            user_obj.is_locked=True if e_is_locked == 'true' else False
            
            print(e_profile_picture)
            print(e_pp_delete_flag)
            if e_pp_delete_flag != 'current':
                if user_obj.image:
                    file_path = user_obj.image.path
                    if default_storage.exists(file_path):
                        default_storage.delete(file_path)
                user_obj.image = e_profile_picture
                user_obj.save()
            else:
                user_obj.save()
            return JsonResponse(data={'status': 'updated'}, safe=False)
        except Exception as es:
            return JsonResponse(data={'status': 'user_error'}, safe=False)
    return JsonResponse(data={'status': 'No Post'}, safe=False)


def UsersDeleteApi(request):
    if request.method == "POST":
        users_ids = request.POST.getlist('users_ids', None)
        for uid in users_ids:
            UserAccount.objects.filter(id=uid).delete()
        return JsonResponse(data={'status': 'deleted'}, safe=False)
    return JsonResponse(data={'status': 'No_Post'}, safe=False)



@is_admin_login
def GroupsView(request):
    admin_obj = Token.objects.get(
        token=request.session.get('admin_token')).user
    context = {
        'user': admin_obj,
    }
    return render(request, 'adminpanal/AdminGroups.html', context)


def GroupsViewApi(request):
    if request.method == "GET":
        page = int(request.GET.get('page', 1))  # Default to page 1
        size = int(request.GET.get('size', 10))  # Default to 10 items per page

        groups = UserGroup.objects.all()
        paginator = Paginator(groups, size)
        current_page = paginator.page(
            page) if paginator.num_pages >= page else paginator.page(1)

        data = [
            {
                'id': group.id,
                'name': group.name,
                'creator': f"{group.creator.first_name} {group.creator.last_name}",
                'timestamp': group.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
                'users': group.id,
                'stations': group.id,
            }
            for group in current_page.object_list
        ]

        return JsonResponse({
            'data': data,
            'last_page': paginator.num_pages
        }, safe=False)
    return JsonResponse({'status': 'No Get'}, safe=False)


def GroupsUsersApi(request):
    if request.method == "GET":
        group_id = request.GET.get('group_id', None)
        try:
            group_obj = UserGroup.objects.get(id=group_id)
            users_list = []
            for user in group_obj.users.all():
                users_list.append({
                    'id': user.id,
                    'first_name': user.first_name,
                    'last_name': user.last_name,
                    'email': user.email,
                    'image': user.image.url if user.image else '/static/img/avater.png',
                    'group_name': group_obj.name,
                })
            return JsonResponse(data=users_list, safe=False)
        except Exception as ex:
            print(ex)
            return JsonResponse(data={'status': 'group_error'}, safe=False)
    return JsonResponse({'status': 'No Get'}, safe=False)


def GroupsStationsApi(request):
    if request.method == "GET":
        group_id = request.GET.get('group_id', None)
        try:
            group_obj = UserGroup.objects.get(id=group_id)
            stations_list = []
            for station in group_obj.stations.select_related('fusion').all():
                stations_list.append({
                    'id': station.id,
                    'station_code': station.fusion.station_code,
                    'station_name': station.fusion.station_name,
                    'ip': station.fusion.ip,
                    'port': station.fusion.port,
                    'group_name': group_obj.name,
                })
            return JsonResponse(data=stations_list, safe=False)
        except Exception as ex:
            print(ex)
            return JsonResponse(data={'status': 'group_error'}, safe=False)
    return JsonResponse({'status': 'No Get'}, safe=False)


def GroupsUsersAllApi(request):
    if request.method == "GET":
        users = UserAccount.objects.all()
        users_list = [
            {
                "id": user.id,
                "first_name": user.first_name,
                "last_name": user.last_name,
                "email": user.email,
                "role": user.role.type,
            }
            for user in users
        ]
        return JsonResponse(data=users_list, safe=False)
    return JsonResponse({'status': 'No Get'}, safe=False)


def GroupsStationsAllApi(request):
    if request.method == "GET":
        stations = Station.objects.select_related('fusion').all()
        stations_list = [
            {
                "id": station.id,
                "station_code": station.fusion.station_code,
                "station_name": station.fusion.station_name,
                "ip": station.fusion.ip,
                "port": station.fusion.port,
            }
            for station in stations
        ]
        return JsonResponse(data=stations_list, safe=False)
    return JsonResponse({'status': 'No Get'}, safe=False)

@is_admin_login
def GroupsAddApi(request):
    admin_obj = Token.objects.get(
        token=request.session.get('admin_token')).user
    if request.method == "POST":
        group_name = request.POST.get('group_name', None)
        users_ids = request.POST.getlist('users_ids', None)
        stations_ids = request.POST.getlist('stations_ids', None)
        check_group = UserGroup.objects.filter(name=group_name)
        if check_group.exists():
            return JsonResponse(data={'status': 'exists'}, safe=False)
        new_group = UserGroup.objects.create(
            name=group_name,
            creator=admin_obj,
        )
        
        for uid in users_ids:
            try:
                user_obj = UserAccount.objects.get(id=uid)
                new_group.users.add(user_obj)
            except UserAccount.DoesNotExist:
                print(f"UserAccount with id {uid} does not exist.")
                return JsonResponse(data={'status': 'user'}, safe=False)
            except Exception as e:
                print(f"An error occurred while adding user {uid}: {e}")
                return JsonResponse(data={'status': 'user'}, safe=False)

        for sid in stations_ids:
            try:
                station_obj = Station.objects.get(id=sid)
                new_group.stations.add(station_obj)
            except Station.DoesNotExist:
                print(f"Station with id {sid} does not exist.")
                return JsonResponse(data={'status': 'station'}, safe=False)
            except Exception as e:
                print(f"An error occurred while adding station {sid}: {e}")
                return JsonResponse(data={'status': 'station'}, safe=False)
        return JsonResponse(data={'status': 'added'}, safe=False)
    return JsonResponse(data={'status': 'No Post'}, safe=False)


def GroupsAllApi(request):
    if request.method == "GET":
        groups = UserGroup.objects.all()
        groups_list = [
            {
                "id": group.id,
                "name": group.name,
                "users": group.users.count(),
                "stations": group.stations.count(),
            }
            for group in groups
        ]
        return JsonResponse(data=groups_list, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)


def GroupsSingleApi(request):
    if request.method == "GET":
        group_id = request.GET.get('group_id', None)
        group = UserGroup.objects.get(id=group_id)
        groups_list = {
            "id": group.id,
            "name": group.name,
            "users": [user.id for user in group.users.all()],
            "stations": [station.id for station in group.stations.all()],
        }
        return JsonResponse(data=groups_list, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)


def GroupsEditApi(request):
    if request.method == "POST":
        group_id = request.POST.get('group_id', None)
        e_group_name = request.POST.get('e_group_name', None)
        e_users_ids = request.POST.getlist('e_users_ids', None)
        e_stations_ids = request.POST.getlist('e_stations_ids', None)
        
        check_group = UserGroup.objects.exclude(id=group_id).filter(name=e_group_name)
        if check_group.exists():
            return JsonResponse(data={'status': 'exists'}, safe=False)
        
        try:
            group_obj = UserGroup.objects.get(id=group_id)
            group_obj.name = e_group_name
            group_obj.save()
        except UserGroup.DoesNotExist:
            print(f"UserGroup with id {group_id} does not exist.")
            return JsonResponse(data={'status': 'group'}, safe=False)
        except Exception as e:
                print(f"An error occurred while editing group {group_id}: {e}")
                return JsonResponse(data={'status': 'group'}, safe=False)
            
        group_obj.users.clear()
        group_obj.stations.clear()
        
        for uid in e_users_ids:
            try:
                user_obj = UserAccount.objects.get(id=uid)
                group_obj.users.add(user_obj)
            except UserAccount.DoesNotExist:
                print(f"UserAccount with id {uid} does not exist.")
                return JsonResponse(data={'status': 'user'}, safe=False)
            except Exception as e:
                print(f"An error occurred while adding user {uid}: {e}")
                return JsonResponse(data={'status': 'user'}, safe=False)

        for sid in e_stations_ids:
            try:
                station_obj = Station.objects.get(id=sid)
                group_obj.stations.add(station_obj)
            except Station.DoesNotExist:
                print(f"Station with id {sid} does not exist.")
                return JsonResponse(data={'status': 'station'}, safe=False)
            except Exception as e:
                print(f"An error occurred while adding station {sid}: {e}")
                return JsonResponse(data={'status': 'station'}, safe=False)
        return JsonResponse(data={'status': 'updated'}, safe=False)
    return JsonResponse(data={'status': 'No Post'}, safe=False)


def GroupsDeleteApi(request):
    if request.method == "POST":
        groups_ids = request.POST.getlist('groups_ids', None)
        for gid in groups_ids:
            UserGroup.objects.filter(id=gid).delete()
        return JsonResponse(data={'status': 'deleted'}, safe=False)
    return JsonResponse(data={'status': 'No_Post'}, safe=False)



@is_admin_login
def ProductView(request):
    admin_obj = Token.objects.get(
        token=request.session.get('admin_token')).user
    # products = Product.objects.all()
    context = {
        'user': admin_obj,
        # 'products': products,
    }
    return render(request, 'adminpanal/AdminProduct.html', context)


def ProductAddApi(request):
    if request.GET:
        product_num = request.GET.get('product_num', None)
        product_name = request.GET.get('product_name', None)
        product_price = request.GET.get('product_price', None)
        check_product = Product.objects.filter(number=product_num)
        if check_product.exists():
            return JsonResponse(data={'status': 'exists'}, safe=False)
        new_product = Product.objects.create(
            number=product_num,
            name=product_name,
            price=float(product_price),
        )
        data = {
            'status': 'added',
            'id': new_product.id,
            'number': new_product.number,
            'name': new_product.name,
            'price': new_product.price,
            'timestamp': new_product.timestamp,
        }
        return JsonResponse(data=data, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)


def ProductViewApi(request):
    if request.method == "GET":
        page = int(request.GET.get('page', 1))  # Default to page 1
        size = int(request.GET.get('size', 10))  # Default to 10 items per page

        products = Product.objects.all()
        paginator = Paginator(products, size)
        current_page = paginator.page(
            page) if paginator.num_pages >= page else paginator.page(1)

        data = [
            {
                'id': product.id,
                'number': product.number,
                'name': product.name,
                'price': product.price,
                'timestamp': product.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
            }
            for product in current_page.object_list
        ]

        return JsonResponse({
            'data': data,
            'last_page': paginator.num_pages
        }, safe=False)
    return JsonResponse({'status': 'No Get'}, safe=False)


def ProductAllApi(request):
    if request.method == "GET":
        products = Product.objects.all()
        product_list = [
            {
                "id": product.id,
                "number": product.number,
                "name": product.name,
            }
            for product in products
        ]
        return JsonResponse(data=product_list, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)


def ProductSingleApi(request):
    if request.method == "GET":
        product_id = request.GET.get('product_id', None)
        product = Product.objects.get(id=product_id)
        product_details = {
            "id": product.id,
            "number": product.number,
            "name": product.name,
            "price": product.price,
        }
        return JsonResponse(data=product_details, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)


def ProductEditApi(request):
    if request.method == "POST":
        product_id = request.POST.get('product_id', None)
        number = request.POST.get('number', None)
        name = request.POST.get('name', None)
        price = request.POST.get('price', None)
        
        check_product = Product.objects.filter(number=number, name=name, price=price)
        if check_product.exists():
            return JsonResponse(data={'status': 'exists'}, safe=False)
        try:
            product_obj = Product.objects.get(id=product_id)
            product_obj.number = number
            product_obj.name = name
            product_obj.price = price
            product_obj.save()
            return JsonResponse(data={'status': 'updated'}, safe=False)
        except Exception as ex:
            print(ex)
            return JsonResponse(data={'status': 'error'}, safe=False)
    return JsonResponse(data={'status': 'No_Post'}, safe=False)


def ProductDeleteApi(request):
    if request.method == "POST":
        product_ids = request.POST.getlist('product_ids', None)
        product_current_ids = [n.product.id for n in Nozzle.objects.all()]
        product_to_delete = []
        product_cannot_delete = []
        for pid in product_ids:
            # print(fid)
            if pid not in product_current_ids:
                product_to_delete.append(pid)
                Product.objects.filter(id=pid).delete()
            else:
                product_cannot_delete.append(pid)

        if len(product_to_delete) > 0:
            if len(product_cannot_delete) > 0:
                return JsonResponse(data={'status': 'delete_exists', 'ids': product_cannot_delete}, safe=False)
            else:
                return JsonResponse(data={'status': 'deleted'}, safe=False)
        else:
            return JsonResponse(data={'status': 'exists', 'ids': product_cannot_delete}, safe=False)
    return JsonResponse(data={'status': 'No_Post'}, safe=False)



@is_admin_login
def FusionView(request):
    admin_obj = Token.objects.get(
        token=request.session.get('admin_token')).user
    context = {
        'user': admin_obj,
    }
    return render(request, 'adminpanal/AdminFusion.html', context)


def FusionViewApi(request):
    if request.method == "GET":
        page = int(request.GET.get('page', 1))  # Default to page 1
        size = int(request.GET.get('size', 10))  # Default to 10 items per page

        fusions = Fusion.objects.all()
        paginator = Paginator(fusions, size)
        current_page = paginator.page(
            page) if paginator.num_pages >= page else paginator.page(1)

        data = [
            {
                'id': fusion.id,
                'station_code': fusion.station_code,
                'station_name': fusion.station_name,
                'ip': fusion.ip,
                'port': fusion.port,
                'timestamp': fusion.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
            }
            for fusion in current_page.object_list
        ]

        return JsonResponse({
            'data': data,
            'last_page': paginator.num_pages
        }, safe=False)
    return JsonResponse({'status': 'No Get'}, safe=False)


def FusionAddApi(request):
    if request.method == "POST":
        station_code = request.POST.get('station_code', None)
        station_name = request.POST.get('station_name', None)
        fusion_ip = request.POST.get('fusion_ip', None)
        fusion_port = request.POST.get('fusion_port', None)

        check_fusion = Fusion.objects.filter(
            station_code=station_code,
            station_name=station_name,
        )

        if check_fusion.exists():
            return JsonResponse(data={'status': 'exists'}, safe=False)

        if station_code and station_name and fusion_ip and fusion_port:
            Fusion.objects.create(
                station_code=station_code,
                station_name=station_name,
                ip=fusion_ip,
                port=fusion_port
            )
            return JsonResponse(data={'status': 'added'}, safe=False)
        else:
            return JsonResponse(data={'status': 'missing_data'}, safe=False)
    return JsonResponse(data={'status': 'No Post Request'}, safe=False)


def FusionAddFileApi(request):
    if request.method == "POST":
        if request.FILES:
            file = request.FILES.get('filepond')
            print('File received:', request.FILES.get('filepond'))
            excel_file = FusionFileHandler.objects.create(file=file)
            fusion_station_codes = [int(f.station_code)
                                    for f in Fusion.objects.all()]
            try:
                fusions_list = []
                fusions_exists = []
                df = pd.read_excel(excel_file.file, engine='openpyxl')
                for index, row in df.iterrows():
                    # print(row['station'], row['fusion_ip'], row['fusion_port'])
                    if int(row['station_code']) not in fusion_station_codes:
                        fusions_list.append(
                            Fusion(
                                station_code=row['station_code'],
                                station_name=row['station_name'],
                                ip=row['fusion_ip'],
                                port=row['fusion_port']
                            )
                        )
                    else:
                        fusions_exists.append(row['station_code'])
                Fusion.objects.bulk_create(fusions_list)
                if len(fusions_list) > 0:
                    if len(fusions_exists) > 0:
                        return JsonResponse(data={'status': 'new_exists', 'codes': fusions_exists}, safe=False)
                    else:
                        return JsonResponse(data={'status': 'added'}, safe=False)
                else:
                    return JsonResponse(data={'status': 'exists', 'codes': fusions_exists}, safe=False)
            except Exception as e:
                print("Error reading Excel file:", e)
                return JsonResponse(data={'status': 'invalid_excel'}, safe=False)
        return JsonResponse(data={'status': 'No_Post_Files'}, safe=False)
    return JsonResponse(data={'status': 'No_Post_Request'}, safe=False)


def FusionAllApi(request):
    if request.method == "GET":
        fusions = Fusion.objects.all()
        fusions_list = [
            {
                "id": fusion.id,
                "station_code": fusion.station_code,
                "station_name": fusion.station_name,
                "ip": fusion.ip,
                "port": fusion.port,
            }
            for fusion in fusions
        ]
        return JsonResponse(data=fusions_list, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)


def FusionSingleApi(request):
    if request.method == "GET":
        fusion_id = request.GET.get('fusion_id', None)
        fusion = Fusion.objects.get(id=fusion_id)
        fusion_details = {
            "id": fusion.id,
            "station_code": fusion.station_code,
            "station_name": fusion.station_name,
            "ip": fusion.ip,
            "port": fusion.port,
        }
        return JsonResponse(data=fusion_details, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)


def FusionEditApi(request):
    if request.method == "POST":
        fusion_id = request.POST.get('fusion_id', None)
        station_code = request.POST.get('station_code', None)
        station_name = request.POST.get('station_name', None)
        ip = request.POST.get('ip', None)
        port = request.POST.get('port', None)
        
        check_fusion = Fusion.objects.filter(station_code=station_code, station_name=station_name, ip=ip, port=port)
        if check_fusion.exists():
            return JsonResponse(data={'status': 'exists'}, safe=False)
        try:
            fusion_obj = Fusion.objects.get(id=fusion_id)
            fusion_obj.station_code = station_code
            fusion_obj.station_name = station_name
            fusion_obj.ip = ip
            fusion_obj.port = port
            fusion_obj.save()
            return JsonResponse(data={'status': 'updated'}, safe=False)
        except Exception as ex:
            print(ex)
            return JsonResponse(data={'status': 'error'}, safe=False)
    return JsonResponse(data={'status': 'No_Post'}, safe=False)


def FusionDeleteApi(request):
    if request.method == "POST":
        f_st_codes = request.POST.getlist('f_st_codes', None)
        # print(f_st_codes)
        fusion_current_codes = [s.number for s in Station.objects.all()]
        fusion_to_delete = []
        fusion_cannot_delete = []
        for fsc in f_st_codes:
            # print(fid)
            if fsc not in fusion_current_codes:
                fusion_to_delete.append(fsc)
                Fusion.objects.filter(station_code=fsc).delete()
            else:
                fusion_cannot_delete.append(fsc)

        if len(fusion_to_delete) > 0:
            if len(fusion_cannot_delete) > 0:
                return JsonResponse(data={'status': 'delete_exists', 'codes': fusion_cannot_delete}, safe=False)
            else:
                return JsonResponse(data={'status': 'deleted'}, safe=False)
        else:
            return JsonResponse(data={'status': 'exists', 'codes': fusion_cannot_delete}, safe=False)
    return JsonResponse(data={'status': 'No_Post'}, safe=False)



@is_admin_login
def StationView(request):
    admin_obj = Token.objects.get(
        token=request.session.get('admin_token')).user
    context = {
        'user': admin_obj,
    }
    return render(request, 'adminpanal/AdminStation.html', context)


def StationViewApi(request):
    if request.method == "GET":
        page = int(request.GET.get('page', 1))  # Default to page 1
        size = int(request.GET.get('size', 10))  # Default to 10 items per page

        stations = Station.objects.select_related('fusion').all()
        paginator = Paginator(stations, size)
        current_page = paginator.page(
            page) if paginator.num_pages >= page else paginator.page(1)

        data = [
            {
                'id': station.id,
                'station_code': station.fusion.station_code,
                'station_name': station.fusion.station_name,
                'ip': station.fusion.ip,
                'port': station.fusion.port,
                'long': station.long if station.long else 'No Data',
                'lat': station.lat if station.lat else 'No Data',
                'last_connection': station.last_connection.strftime("%Y-%m-%d %H:%M:%S"),
                'governorate': station.governorate.name if station.governorate else 'No Data',
                'central_area': station.central_area.name if station.central_area else 'No Data',
                'timestamp': station.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
            }
            for station in current_page.object_list
        ]

        return JsonResponse({
            'data': data,
            'last_page': paginator.num_pages
        }, safe=False)
    return JsonResponse({'status': 'No Get'}, safe=False)


def StationFusionsCodeApi(request):
    if request.method == "GET":
        stations = Station.objects.values_list('fusion_id', flat=True)
        fusions = Fusion.objects.exclude(id__in=stations)
        fusions_list = [
            {
                "id": fusion.id,
                "station_code": fusion.station_code,
                "station_name": fusion.station_name,
                "ip": fusion.ip,
                "port": fusion.port,
            }
            for fusion in fusions
        ]
        return JsonResponse(data=fusions_list, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)


def StationGetStationDataApi(request):
    if request.method == "GET":
        fusion_id = request.GET.get('fusion_id', None)
        station = Fusion.objects.get(id=fusion_id)
        station_details = {
            "id": station.id,
            "station_name": station.station_name,
            "ip": station.ip,
            "port": station.port,
        }
        return JsonResponse(data=station_details, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)


def StationCentralAreaApi(request):
    if request.method == "GET":
        central_areas = CentralArea.objects.all()
        central_areas_list = [
            {
                "id": ca.id,
                "name": ca.name
            }
            for ca in central_areas
        ]
        return JsonResponse(data=central_areas_list, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)


def StationGovernorateApi(request):
    if request.method == "GET":
        central_area_id = request.GET.get('central_area_id', None)
        governorates = Governorate.objects.filter(centralArea_id=central_area_id)
        governorates_list = [
            {
                "id": gov.id,
                "name": gov.name
            }
            for gov in governorates
        ]
        return JsonResponse(data=governorates_list, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)


def StationCheckStationDataApi(request):
    if request.method == "GET":
        station_code = request.GET.get('station_code', None)
        check_fusion = Fusion.objects.filter(station_code=station_code)
        if not check_fusion.exists():
            return JsonResponse(data={'status': 'not_found'}, safe=False)
        else:
            check_station = Station.objects.filter(fusion=check_fusion.first())
            if check_station.exists():
                return JsonResponse(data={'status': 'exists'}, safe=False)
            station_details = {
                "id": check_fusion.first().id,
                "station_code": check_fusion.first().station_code,
                "station_name": check_fusion.first().station_name,
                "ip": check_fusion.first().ip,
                "port": check_fusion.first().port,
            }
            return JsonResponse(data={'status': 'found', 'data': station_details}, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)


def StationAddApi(request):
    if request.method == "POST":
        station_codes = request.POST.get('station_codes', None)
        station_name = request.POST.get('station_name', None)
        fusion_ip = request.POST.get('fusion_ip', None)
        fusion_port = request.POST.get('fusion_port', None)
        central_area = request.POST.get('central_area', None)
        governorate = request.POST.get('governorate', None)
        long = request.POST.get('long', None)
        lat = request.POST.get('lat', None)

        check_station = Station.objects.filter(
            fusion=station_codes,
        )

        if check_station.exists():
            return JsonResponse(data={'status': 'exists'}, safe=False)

        if station_codes and station_name and fusion_ip and fusion_port:
            Station.objects.create(
                fusion_id=station_codes,
                long=long,
                lat=lat,
                last_connection=datetime.now(),
                governorate=governorate if governorate else None,
                central_area=central_area if central_area else None,
            )
            return JsonResponse(data={'status': 'added'}, safe=False)
        else:
            return JsonResponse(data={'status': 'missing_data'}, safe=False)
    return JsonResponse(data={'status': 'No Post Request'}, safe=False)


def StationAddFileApi(request):
    if request.method == "POST":
        uf_station_code = request.POST.get('uf_station_code', None)
        uf_station_name = request.POST.get('uf_station_name', None)
        uf_fusion_ip = request.POST.get('uf_fusion_ip', None)
        uf_fusion_port = request.POST.get('uf_fusion_port', None)
        uf_central_area = request.POST.get('uf_central_area', None)
        uf_governorate = request.POST.get('uf_governorate', None)
        uf_long = request.POST.get('uf_long', None)
        uf_lat = request.POST.get('uf_lat', None)

        fusion_obj = Fusion.objects.get(station_code=uf_station_code)
        check_station = Station.objects.filter(
            fusion=fusion_obj,
        )

        if check_station.exists():
            return JsonResponse(data={'status': 'exists'}, safe=False)

        if uf_station_code and uf_station_name and uf_fusion_ip and uf_fusion_port:
            station_obj = Station.objects.create(
                fusion=fusion_obj,
                long=uf_long,
                lat=uf_lat,
                last_connection=datetime.now(),
                governorate_id=uf_governorate if uf_governorate else None,
                central_area_id=uf_central_area if uf_central_area else None,
            )
            
            if request.FILES:
                file = request.FILES.get('filepond')
                print('File received:', request.FILES.get('filepond'))
                xml_file = StationFileHandler.objects.create(
                    file=file,
                    station=station_obj
                )
                tree = ET.parse(xml_file.file)
                root = tree.getroot().find('pump')
                # Iterate over each 'pump_def' element within 'pump'
                print(root.findall('pump_def'))
                # Iterate over each 'pump_def' element
                for pump_def in root.findall('pump_def'):
                    pump_id = pump_def.get('ID')
                    hose_ids = []
                    pump_obj = Pump.objects.create(
                        number=pump_id,
                        station=station_obj
                    )
                    # Find all elements with tag name starting with 'hose'
                    for hose in pump_def:
                        if re.match(r'^hose\d+$', hose.tag):
                            grade = hose.find('grade').text
                            real_id = hose.find('real_id').text
                            hose_ids.append(real_id)
                            product_id = 0
                            if grade == 'Gasoline95':
                                product_id = 1
                            if grade == 'Gasoline92':
                                product_id = 2
                            if grade == 'Gasoline80':
                                product_id = 3
                            if grade == 'Diesel':
                                product_id = 4
                            if grade == 'CNG':
                                product_id = 5
                            Nozzle.objects.create(
                                number=real_id,
                                product_id=product_id,
                                pump=pump_obj,
                                station=station_obj
                            )
                    print(f'Pump ID: {pump_id}, Hose Real IDs: {hose_ids}')
                    # You can further process or store this information as needed
            return JsonResponse(data={'status': 'added'}, safe=False)
        else:
            return JsonResponse(data={'status': 'missing_data'}, safe=False)
    return JsonResponse(data={'status': 'No Post Request'}, safe=False)


def StationAllApi(request):
    if request.method == "GET":
        stations = Station.objects.select_related('fusion').only('id', 'fusion__station_code', 'fusion__station_name')
        stations_list = [
            {
                "id": station.id,
                "station_code": station.fusion.station_code,
                "station_name": station.fusion.station_name,
            }
            for station in stations
        ]
        return JsonResponse(data=stations_list, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)


def StationSingleApi(request):
    if request.method == "GET":
        station_id = request.GET.get('station_id', None)
        station = Station.objects.select_related('central_area', 'governorate').get(id=station_id)
        station_details = {
            "id": station.id,
            "central_area": station.central_area.id if station.central_area else '',
            "governorate": station.governorate.id if station.governorate else '',
            "long": station.long if station.long else 'No Data',
            "lat": station.lat if station.lat else 'No Data',
            "all_ca": [
                {
                    "id": ca.id,
                    "name": ca.name,
                }
                for ca in CentralArea.objects.all()
            ],
            "all_gov": [
                {
                    "id": gov.id,
                    "name": gov.name,
                }
                for gov in Governorate.objects.filter(centralArea=station.central_area)
            ],
        }
        return JsonResponse(data=station_details, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)


def StationEditApi(request):
    if request.method == "POST":
        station_id = request.POST.get('station_id', None)
        e_central_area = request.POST.get('e_central_area', None)
        e_governorate = request.POST.get('e_governorate', None)
        e_long = request.POST.get('e_long', None)
        e_lat = request.POST.get('e_lat', None)
        
        check_station = Station.objects.exclude(id=station_id).filter(long= e_long, lat=e_lat)
        if check_station.exists():
            return JsonResponse(data={'status': 'exists'}, safe=False)
        try:
            station_obj = Station.objects.get(id=station_id)
            station_obj.long = e_long
            station_obj.lat = e_lat
            station_obj.governorate_id = e_governorate
            station_obj.central_area_id = e_central_area
            station_obj.save()
            return JsonResponse(data={'status': 'updated'}, safe=False)
        except Exception as ex:
            print(ex)
            return JsonResponse(data={'status': 'error'}, safe=False)
    return JsonResponse(data={'status': 'No_Post'}, safe=False)


def StationDeleteApi(request):
    if request.method == "POST":
        station_ids = request.POST.getlist('station_ids', None)
        print(station_ids)
        Station.objects.filter(id__in=station_ids).delete()
        return JsonResponse(data={'status': 'deleted'}, safe=False)
    return JsonResponse(data={'status': 'No_Post'}, safe=False)



@is_admin_login
def PumpsView(request):
    admin_obj = Token.objects.get(
        token=request.session.get('admin_token')).user
    # products = Product.objects.all()
    context = {
        'user': admin_obj,
        # 'products': products,
    }
    return render(request, 'adminpanal/AdminPump.html', context)


def PumpsViewApi(request):
    if request.method == "GET":
        page = int(request.GET.get('page', 1))  # Default to page 1
        size = int(request.GET.get('size', 10))  # Default to 10 items per page

        pumps = Pump.objects.select_related('station', 'station__fusion').all()
        paginator = Paginator(pumps, size)
        current_page = paginator.page(
            page) if paginator.num_pages >= page else paginator.page(1)

        data = [
            {
                'id': pump.id,
                'pump_number': pump.number,
                'station_code': pump.station.fusion.station_code,
                'station_name': pump.station.fusion.station_name,
                'timestamp': pump.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
            }
            for pump in current_page.object_list
        ]

        return JsonResponse({
            'data': data,
            'last_page': paginator.num_pages
        }, safe=False)
    return JsonResponse({'status': 'No Get'}, safe=False)


def PumpsStationsAllApi(request):
    if request.method == "GET":
        stations = Station.objects.select_related('fusion').all()
        stations_list = [
            {
                "id": station.id,
                "station_code": station.fusion.station_code,
                "station_name": station.fusion.station_name,
            }
            for station in stations
        ]
        return JsonResponse(data=stations_list, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)


def PumpsStationsSingleApi(request):
    if request.method == "GET":
        station_id = request.GET.get('station_id', None)
        pumps = Pump.objects.filter(station_id=station_id)
        if not pumps.exists():
            return JsonResponse(data={'status': 'not_exists'}, safe=False)
        pumps_details = [
            {
            "id": pump.id,
            "number": f"Pump {pump.number}",
            "timestamp": pump.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
            }
            for pump in pumps
        ]
        return JsonResponse(data=pumps_details, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)


def PumpsAddApi(request):
    if request.method == "POST":
        station_id = request.POST.get('station_id', None)
        pumps = request.POST.getlist('pumps', None)
        temp_list = []
        for pump in pumps:
            temp_list.append(Pump(number=pump, station_id=station_id))
        Pump.objects.bulk_create(temp_list)
        return JsonResponse(data={'status': 'added'}, safe=False)
    return JsonResponse(data={'status': 'No Post'}, safe=False)


def PumpsDeleteApi(request):
    if request.method == "POST":
        pumps_ids = request.POST.getlist('pumps_ids', None)
        Pump.objects.filter(id__in=pumps_ids).delete()
        return JsonResponse(data={'status': 'deleted'}, safe=False)
    return JsonResponse(data={'status': 'No_Post'}, safe=False)



@is_admin_login
def NozzlesView(request):
    admin_obj = Token.objects.get(
        token=request.session.get('admin_token')).user
    # products = Product.objects.all()
    context = {
        'user': admin_obj,
        # 'products': products,
    }
    return render(request, 'adminpanal/AdminNozzle.html', context)


def NozzlesViewApi(request):
    if request.method == "GET":
        page = int(request.GET.get('page', 1))  # Default to page 1
        size = int(request.GET.get('size', 10))  # Default to 10 items per page

        nozzles = Nozzle.objects.select_related('station', 'station__fusion', 'pump', 'product').all()
        paginator = Paginator(nozzles, size)
        current_page = paginator.page(
            page) if paginator.num_pages >= page else paginator.page(1)

        data = [
            {
                'id': nozzle.id,
                'nozzle_number': f"Nozzle {nozzle.number}",
                'product_name': nozzle.product.name,
                'pump_number': f"Pump {nozzle.pump.number}",
                'station_code': nozzle.station.fusion.station_code,
                'station_name': nozzle.station.fusion.station_name,
                'timestamp': nozzle.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
            }
            for nozzle in current_page.object_list
        ]

        return JsonResponse({
            'data': data,
            'last_page': paginator.num_pages
        }, safe=False)
    return JsonResponse({'status': 'No Get'}, safe=False)


def NozzlesStationsAllApi(request):
    if request.method == "GET":
        stations = Station.objects.filter(stationPump__isnull=False).distinct()
        print(stations)
        stations_list = [
            {
                "id": station.id,
                "station_code": station.fusion.station_code,
                "station_name": station.fusion.station_name,
            }
            for station in stations
        ]
        return JsonResponse(data=stations_list, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)


def NozzlesStationsSingleApi(request):
    if request.method == "GET":
        station_id = request.GET.get('station_id', None)
        pumps = Pump.objects.filter(station_id=station_id)
        if not pumps.exists():
            return JsonResponse(data={'status': 'not_exists'}, safe=False)
        pumps_details = [
            {
            "id": pump.id,
            "number": f"Pump {pump.number}",
            }
            for pump in pumps
        ]
        return JsonResponse(data=pumps_details, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)


def NozzlesPumpsSingleApi(request):
    if request.method == "GET":
        pump_id = request.GET.get('pump_id', None)
        station_id = request.GET.get('station_id', None)
        nozzles = Nozzle.objects.select_related('product').filter(pump_id=pump_id, station_id=station_id)
        if not nozzles.exists():
            return JsonResponse(data={'status': 'not_exists'}, safe=False)
        nozzles_details = [
            {
                "id": nozzle.id,
                "nozzle_number": f"Nozzle {nozzle.number}",
                "product_name": nozzle.product.name,
                "product_number": nozzle.product.id,
                "timestamp": nozzle.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
            }
            for nozzle in nozzles
        ]
        return JsonResponse(data=nozzles_details, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)


def NozzlesProductsAllApi(request):
    if request.method == "GET":
        products = Product.objects.all()
        products_list = [
            {
                "id": product.id,
                "name": product.name,
                "price": product.price,
            }
            for product in products
        ]
        return JsonResponse(data=products_list, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)

def NozzlesAddApi(request):
    if request.method == "POST":
        station_id = request.POST.get('station_id', None)
        pump_id = request.POST.get('pump_id', None)
        pumps_products = request.POST.getlist('pumps_products', None)
        print(pumps_products)
        temp_list = []
        for pump_product in pumps_products:
            pump_number = pump_product.split('-')[0]
            product_id = pump_product.split('-')[1]
            temp_list.append(
                Nozzle(
                    number=pump_number,
                    product_id=product_id,
                    pump_id=pump_id,
                    station_id=station_id,
                )
            )
        Nozzle.objects.bulk_create(temp_list)
        return JsonResponse(data={'status': 'added'}, safe=False)
    return JsonResponse(data={'status': 'No Post'}, safe=False)


def NozzlesEditApi(request):
    if request.method == "POST":
        station_id = request.POST.get('station_id', None)
        pump_id = request.POST.get('pump_id', None)
        nozzle_id = request.POST.get('nozzle_id', None)
        product_id = request.POST.get('product_id', None)
        Nozzle.objects.filter(id=nozzle_id, station_id=station_id, pump_id=pump_id).update(
            product_id=product_id
        )
        return JsonResponse(data={'status': 'updated'}, safe=False)
    return JsonResponse(data={'status': 'No Post'}, safe=False)


def NozzlesDeleteApi(request):
    if request.method == "POST":
        nozzles_ids = request.POST.getlist('nozzles_ids', None)
        Nozzle.objects.filter(id__in=nozzles_ids).delete()
        return JsonResponse(data={'status': 'deleted'}, safe=False)
    return JsonResponse(data={'status': 'No_Post'}, safe=False)





@is_admin_login
def POSView(request):
    admin_obj = Token.objects.get(
        token=request.session.get('admin_token')).user
    # products = Product.objects.all()
    context = {
        'user': admin_obj,
        # 'products': products,
    }
    return render(request, 'adminpanal/AdminPOS.html', context)


def POSViewApi(request):
    if request.method == "GET":
        page = int(request.GET.get('page', 1))  # Default to page 1
        size = int(request.GET.get('size', 10))  # Default to 10 items per page

        nozzles = Pos.objects.select_related('station', 'station__fusion').all()
        paginator = Paginator(nozzles, size)
        current_page = paginator.page(
            page) if paginator.num_pages >= page else paginator.page(1)

        data = [
            {
                'id': pos.id,
                'android_id': pos.android_id,
                'status': 'created' if pos.status == 'c' else 'offline' if pos.status == 'off' else 'online',
                'last_connection': pos.last_connection.strftime("%Y-%m-%d %H:%M:%S"),
                'pump': pos.id,
                'station_code': pos.station.fusion.station_code,
                'station_name': pos.station.fusion.station_name,
                'timestamp': pos.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
            }
            for pos in current_page.object_list
        ]

        return JsonResponse({
            'data': data,
            'last_page': paginator.num_pages
        }, safe=False)
    return JsonResponse({'status': 'No Get'}, safe=False)


def POSPumpsApi(request):
    if request.method == "GET":
        pos_id = request.GET.get('pos_id', None)
        try:
            pos_obj = Pos.objects.select_related('station__fusion').get(id=pos_id)
            pumps_list = []
            for pump in pos_obj.pumps.all():
                pumps_list.append({
                    'id': pump.id,
                    'number': f'Pump {pump.number}',
                    'timestamp': pump.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
                })
            data = {
                'pumps': pumps_list,
                'android_id': pos_obj.android_id,
                'station_code': pos_obj.station.fusion.station_code,
            }
            return JsonResponse(data=data, safe=False)
        except Exception as ex:
            print(ex)
            return JsonResponse(data={'status': 'pos_error'}, safe=False)
    return JsonResponse({'status': 'No Get'}, safe=False)

def POSStationsAllApi(request):
    if request.method == "GET":
        stations = Station.objects.filter(stationPump__isnull=False).distinct()
        print(stations)
        stations_list = [
            {
                "id": station.id,
                "station_code": station.fusion.station_code,
                "station_name": station.fusion.station_name,
            }
            for station in stations
        ]
        return JsonResponse(data=stations_list, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)


def POSStationsSingleApi(request):
    if request.method == "GET":
        station_id = request.GET.get('station_id', None)
        pumps = Pump.objects.filter(station_id=station_id)
        if not pumps.exists():
            return JsonResponse(data={'status': 'not_exists'}, safe=False)
        pumps_details = [
            {
                "id": pump.id,
                "number": f"Pump {pump.number}",
            }
            for pump in pumps
        ]
        return JsonResponse(data=pumps_details, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)


def POSAddApi(request):
    if request.method == "POST":
        android_id = request.POST.get('android_id', None)
        station_id = request.POST.get('station_id', None)
        pumps_ids = request.POST.getlist('pumps_ids', None)
        
        print(pumps_ids)
        
        check_pos = Pos.objects.filter(android_id=android_id)
        if check_pos.exists():
            return JsonResponse(data={'status': 'exists'}, safe=False)
        
        pos_obj = Pos.objects.create(
            android_id=android_id,
            station_id=station_id,
            status= pos_status[0][0],
            last_connection= datetime.now(),
        )
        
        # add pumps to the pos object based on the list of pump ids
        # the * operator unpacks the list of pump ids into separate arguments
        # to the add method, which adds each pump to the pos object's many-to-many
        # field pumps
        pos_obj.pumps.add(*Pump.objects.filter(id__in=pumps_ids))
        return JsonResponse(data={'status': 'added'}, safe=False)
    return JsonResponse(data={'status': 'No Post'}, safe=False)


def POSAllApi(request):
    if request.method == "GET":
        station_id = request.GET.get('station_id', None)
        poses = Pos.objects.filter(station_id=station_id)
        pumps = Pump.objects.filter(station_id=station_id)
        if not poses.exists():
            return JsonResponse(data={'status': 'not_exists'}, safe=False)
        poses_details = [
            {
                "id": pos.id,
                "android_id": pos.android_id,
                "status": "created" if pos.status == 'c' else 'offline' if pos.status == 'off' else 'online',
                "pumps": pos.pumps.count(),
            }
            for pos in poses
        ]
        
        data = {
            'poses': poses_details,
            'pumps': [
                {
                    'id': pump.id,
                    'number': f'Pump {pump.number}',
                }
                for pump in pumps
            ],
        }
        return JsonResponse(data=data, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)


def POSPumpsSingleApi(request):
    if request.method == "GET":
        pos_id = request.GET.get('pos_id', None)
        station_id = request.GET.get('station_id', None)
        pos_obj = Pos.objects.get(id=pos_id, station_id=station_id)
        pos_details = {
            "id": pos_obj.id,
            "android_id": pos_obj.android_id,
            "pumps": [f'{pump.id}' for pump in pos_obj.pumps.all()]
        }
        return JsonResponse(data=pos_details, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)


def POSEditApi(request):
    if request.method == "POST":
        station_id = request.POST.get('station_id', None)
        pos_id = request.POST.get('pos_id', None)
        android_id = request.POST.get('android_id', None)
        pumps_ids = request.POST.getlist('pumps_ids', None)
        pos_obj = Pos.objects.get(id=pos_id, station_id=station_id)
        pos_obj.android_id = android_id
        pos_obj.save()
        pos_obj.pumps.clear()
        pos_obj.pumps.add(*Pump.objects.filter(id__in=pumps_ids))
        return JsonResponse(data={'status': 'updated'}, safe=False)
    return JsonResponse(data={'status': 'No Post'}, safe=False)


def POSDeleteApi(request):
    if request.method == "POST":
        poses_ids = request.POST.getlist('poses_ids', None)
        Pos.objects.filter(id__in=poses_ids).delete()
        return JsonResponse(data={'status': 'deleted'}, safe=False)
    return JsonResponse(data={'status': 'No_Post'}, safe=False)



def POSGetTokenApi(request):
    if request.method == "GET":
        csrf_token = get_token(request)
        android_id = request.GET.get('android_id', None)
        print(android_id)
        try:
            pos_obj = Pos.objects.get(android_id=android_id)
            pos_token = PosToken.objects.select_related('pos').get(pos=pos_obj)
            return JsonResponse(data={'status': 'success', 'token': pos_token.token, 'csrf_token': csrf_token}, safe=False)
        except Pos.DoesNotExist:
            return JsonResponse(data={'status': 'error', 'message': 'pos not exists'}, safe=False)
        except PosToken.DoesNotExist:
            return JsonResponse(data={'status': 'error', 'message': 'pos token not exists'}, safe=False)
        except Exception as ex:
            print('exception', ex)
            return JsonResponse(data={'status': 'error', 'message': str(ex)}, safe=False)
    return JsonResponse(data={'status': 'No Get request'}, safe=False)


def POSConfigApi(request):
    if request.method == "POST":
        data = json.loads(request.body)
        pos_token = data.get('pos_token', None)
        try:
            android_id = PosToken.objects.select_related('pos').get(token=pos_token).pos.android_id
            pos_obj = Pos.objects.select_related('station', 'station__fusion').get(android_id=android_id)
            # print(pos_obj)
            group_obj = UserGroup.objects.get(stations=pos_obj.station)
            # print(group_obj.name)
            seller_obj = Tax.objects.filter(group=group_obj).first()
            # print(seller_obj)
            data = {
                'station_code': pos_obj.station.fusion.station_code,
                'station_name': pos_obj.station.fusion.station_name,
                'pumps_count': pos_obj.pumps.count(),
                'pumps': [
                    {
                        'pump_number': pump.number,
                        'nozzles_count': Nozzle.objects.filter(pump_id=pump.id).count(),
                        'nozzles': [
                            {
                                'nozzle_number': nozzle.number,
                                'product_name': nozzle.product.name,
                                'product_number': nozzle.product.number,
                                'pump': pump.number,
                            }
                            for nozzle in Nozzle.objects.select_related('product').filter(pump_id=pump.id)
                        ]
                    }
                    for pump in pos_obj.pumps.all()
                ],
                'seller': {
                    "rin": seller_obj.rin,
                    "companyTradeName": seller_obj.companyTradeName,
                    "branchCode": seller_obj.branchCode,
                    "branchAddress": {
                        "country": seller_obj.branchAddress_country,
                        "governate": seller_obj.branchAddress_governate,
                        "regionCity": seller_obj.branchAddress_regionCity,
                        "street": seller_obj.branchAddress_street,
                        "buildingNumber": seller_obj.branchAddress_buildingNumber
                    },
                    "deviceSerialNumber": seller_obj.deviceSerialNumber,
                    "syndicateLicenseNumber": seller_obj.syndicateLicenseNumber,
                    "activityCode": seller_obj.activityCode
                }
            }
            return JsonResponse(data=data, safe=False)
        except PosToken.DoesNotExist:
            return JsonResponse(data={'status': 'error', 'message': 'pos token exists'}, safe=False)
        except Pos.DoesNotExist:
            return JsonResponse(data={'status': 'error', 'message': 'pos not exists'}, safe=False)
        except UserGroup.DoesNotExist:
            return JsonResponse(data={'status': 'error', 'message': 'user group not exists'}, safe=False)
        except Tax.DoesNotExist:
            return JsonResponse(data={'status': 'error', 'message': 'taxes not exists'}, safe=False)
        except Exception as ex:
            print('exception', ex)
            return JsonResponse(data={'status': 'error', 'message': ex}, safe=False)
    return JsonResponse(data={'status': 'No Post request'}, safe=False)



@is_admin_login
def TaxView(request):
    admin_obj = Token.objects.get(
        token=request.session.get('admin_token')).user
    # products = Product.objects.all()
    context = {
        'user': admin_obj,
        # 'products': products,
    }
    return render(request, 'adminpanal/AdminTax.html', context)


def TaxViewApi(request):
    if request.method == "GET":
        page = int(request.GET.get('page', 1))  # Default to page 1
        size = int(request.GET.get('size', 10))  # Default to 10 items per page

        taxes = Tax.objects.select_related('group').all()
        paginator = Paginator(taxes, size)
        current_page = paginator.page(
            page) if paginator.num_pages >= page else paginator.page(1)

        data = [
            {
                'id': tax.id,
                'group': tax.group.name,
                'rin': tax.rin,
                'companyTradeName': tax.companyTradeName,
                'branchCode': tax.branchCode,
                'branchAddress_country': tax.branchAddress_country,
                'branchAddress_governate': tax.branchAddress_governate,
                'branchAddress_regionCity': tax.branchAddress_regionCity,
                'branchAddress_street': tax.branchAddress_street,
                'branchAddress_buildingNumber': tax.branchAddress_buildingNumber,
                'deviceSerialNumber': tax.deviceSerialNumber,
                'syndicateLicenseNumber': tax.syndicateLicenseNumber,
                'activityCode': tax.activityCode,
                'timestamp': tax.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
            }
            for tax in current_page.object_list
        ]

        return JsonResponse({
            'data': data,
            'last_page': paginator.num_pages
        }, safe=False)
    return JsonResponse({'status': 'No Get'}, safe=False)


def TaxGroupsAllApi(request):
    if request.method == "GET":
        groups = UserGroup.objects.all()
        groups_list = [
            {
                "id": group.id,
                "name": group.name,
            }
            for group in groups
        ]
        return JsonResponse(data=groups_list, safe=False)
    return JsonResponse({'status': 'No Get'}, safe=False)


def TaxAddApi(request):
    if request.method == "POST":
        groups_list = request.POST.get('groups_list', None)
        rin = request.POST.get('rin', None)
        companyTradeName = request.POST.get('companyTradeName', None)
        branchCode = request.POST.get('branchCode', None)
        branchAddress_country = request.POST.get('branchAddress_country', None)
        branchAddress_governate = request.POST.get('branchAddress_governate', None)
        branchAddress_regionCity = request.POST.get('branchAddress_regionCity', None)
        branchAddress_street = request.POST.get('branchAddress_street', None)
        branchAddress_buildingNumber = request.POST.get('branchAddress_buildingNumber', None)
        deviceSerialNumber = request.POST.get('deviceSerialNumber', None)
        syndicateLicenseNumber = request.POST.get('syndicateLicenseNumber', None)
        activityCode = request.POST.get('activityCode', None)
        
        check_tax = Tax.objects.filter(deviceSerialNumber=deviceSerialNumber, group_id=groups_list)
        if check_tax.exists():
            return JsonResponse(data={'status': 'exists'}, safe=False)
        
        Tax.objects.create(
            group_id = groups_list,
            rin = rin,
            companyTradeName = companyTradeName,
            branchCode = branchCode,
            branchAddress_country = branchAddress_country,
            branchAddress_governate = branchAddress_governate,
            branchAddress_regionCity = branchAddress_regionCity,
            branchAddress_street = branchAddress_street,
            branchAddress_buildingNumber = branchAddress_buildingNumber,
            deviceSerialNumber = deviceSerialNumber,
            syndicateLicenseNumber = syndicateLicenseNumber,
            activityCode = activityCode,
        )
        return JsonResponse(data={'status': 'added'}, safe=False)
    return JsonResponse(data={'status': 'No Post'}, safe=False)


def TaxAllApi(request):
    if request.method == "GET":
        station_id = request.GET.get('station_id', None)
        poses = Pos.objects.filter(station_id=station_id)
        pumps = Pump.objects.filter(station_id=station_id)
        if not poses.exists():
            return JsonResponse(data={'status': 'not_exists'}, safe=False)
        poses_details = [
            {
                "id": pos.id,
                "android_id": pos.android_id,
                "status": "created" if pos.status == 'c' else 'offline' if pos.status == 'off' else 'online',
                "pumps": pos.pumps.count(),
            }
            for pos in poses
        ]
        
        data = {
            'poses': poses_details,
            'pumps': [
                {
                    'id': pump.id,
                    'number': f'Pump {pump.number}',
                }
                for pump in pumps
            ],
        }
        return JsonResponse(data=data, safe=False)
    return JsonResponse(data={'status': 'No Get'}, safe=False)


def TaxSellersAllApi(request):
    if request.method == "GET":
        taxes = Tax.objects.select_related('group').all()
        taxes_list = [
            {
                "id": tax.id,
                "rin": tax.rin,
                "group": tax.group.name,
            }
            for tax in taxes
        ]
        return JsonResponse(data=taxes_list, safe=False)
    return JsonResponse({'status': 'No Get'}, safe=False)


def TaxSellersSingleApi(request):
    if request.method == "GET":
        seller_id = request.GET.get('seller_id')
        seller_obj = Tax.objects.select_related('group').get(id=seller_id)
        seller_details = {
            'id': seller_obj.id,
            'group': seller_obj.group.id,
            'rin': seller_obj.rin,
            'companyTradeName': seller_obj.companyTradeName,
            'branchCode': seller_obj.branchCode,
            'branchAddress_country': seller_obj.branchAddress_country,
            'branchAddress_governate': seller_obj.branchAddress_governate,
            'branchAddress_regionCity': seller_obj.branchAddress_regionCity,
            'branchAddress_street': seller_obj.branchAddress_street,
            'branchAddress_buildingNumber': seller_obj.branchAddress_buildingNumber,
            'deviceSerialNumber': seller_obj.deviceSerialNumber,
            'syndicateLicenseNumber': seller_obj.syndicateLicenseNumber,
            'activityCode': seller_obj.activityCode,
        }
        return JsonResponse(data=seller_details, safe=False)
    return JsonResponse({'status': 'No Get'}, safe=False)


def TaxEditApi(request):
    if request.method == "POST":
        seller_id = request.POST.get('seller_id', None)
        group_id = request.POST.get('group_id', None)
        e_rin = request.POST.get('e_rin', None)
        e_companyTradeName = request.POST.get('e_companyTradeName', None)
        e_branchCode = request.POST.get('e_branchCode', None)
        e_branchAddress_country = request.POST.get('e_branchAddress_country', None)
        e_branchAddress_governate = request.POST.get('e_branchAddress_governate', None)
        e_branchAddress_regionCity = request.POST.get('e_branchAddress_regionCity', None)
        e_branchAddress_street = request.POST.get('e_branchAddress_street', None)
        e_branchAddress_buildingNumber = request.POST.get('e_branchAddress_buildingNumber', None)
        e_deviceSerialNumber = request.POST.get('e_deviceSerialNumber', None)
        e_syndicateLicenseNumber = request.POST.get('e_syndicateLicenseNumber', None)
        e_activityCode = request.POST.get('e_activityCode', None)
        check_seller = Tax.objects.exclude(id=seller_id).filter(deviceSerialNumber=e_deviceSerialNumber, group_id=group_id)
        if check_seller.exists():
            return JsonResponse(data={'status': 'exists'}, safe=False)
        try:
            seller_obj = Tax.objects.get(id=seller_id)
            seller_obj.group_id = group_id
            seller_obj.rin = e_rin
            seller_obj.companyTradeName = e_companyTradeName
            seller_obj.branchCode = e_branchCode
            seller_obj.branchAddress_country = e_branchAddress_country
            seller_obj.branchAddress_governate = e_branchAddress_governate
            seller_obj.branchAddress_regionCity = e_branchAddress_regionCity
            seller_obj.branchAddress_street = e_branchAddress_street
            seller_obj.branchAddress_buildingNumber = e_branchAddress_buildingNumber
            seller_obj.deviceSerialNumber = e_deviceSerialNumber
            seller_obj.syndicateLicenseNumber = e_syndicateLicenseNumber
            seller_obj.activityCode = e_activityCode
            seller_obj.save()
            return JsonResponse(data={'status': 'updated'}, safe=False)
        except Exception as ex:
            print('exception', ex)
            return JsonResponse(data={'status': 'error', 'message': ex}, safe=False)
    return JsonResponse(data={'status': 'No Post request'}, safe=False)


def TaxDeleteApi(request):
    if request.method == "POST":
        sellers_ids = request.POST.getlist('sellers_ids', None)
        Tax.objects.filter(id__in=sellers_ids).delete()
        return JsonResponse(data={'status': 'deleted'}, safe=False)
    return JsonResponse(data={'status': 'No_Post'}, safe=False)


@is_admin_login
def SalesView(request):
    admin_obj = Token.objects.get(
        token=request.session.get('admin_token')).user
    # products = Product.objects.all()
    context = {
        'user': admin_obj,
        # 'products': products,
    }
    return render(request, 'adminpanal/AdminSales.html', context)


def SalesViewApi(request):
    if request.method == "GET":
        page = int(request.GET.get('page', 1))  # Default to page 1
        size = int(request.GET.get('size', 10))  # Default to 10 items per page

        transactions = Transaction.objects.select_related('station', 'pump', 'nozzle', 'product').all()
        paginator = Paginator(transactions, size)
        current_page = paginator.page(
            page) if paginator.num_pages >= page else paginator.page(1)

        data = [
            {
                'id': trx.id,
                'seq_no': trx.seq_no,
                'fusion_sale': trx.fusion_sale,
                'volume': trx.volume,
                'unit_price': trx.unit_price,
                'amount': trx.amount,
                'unit_measure': trx.unit_measure,
                'tips': trx.tips,
                'date': trx.date.strftime("%Y-%m-%d %H:%M:%S"),
                'payment_type': trx.payment_type,
                'is_taxed': trx.is_taxed,
                'pos': trx.pos.android_id,
                'product': trx.product.name,
                'nozzle': f'Nozzle {trx.nozzle.number}',
                'pump': f'Pump {trx.pump.number}',
                'station': f'{trx.station.fusion.station_code}-{trx.station.fusion.station_name}',
                'timestamp': trx.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
            }
            for trx in current_page.object_list
        ]

        return JsonResponse({
            'data': data,
            'last_page': paginator.num_pages
        }, safe=False)
    return JsonResponse({'status': 'No Get'}, safe=False)

